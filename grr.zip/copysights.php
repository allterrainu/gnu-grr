<?php 
 
global $conf, $dbm;
global ${$conf["APP.SESSION.sign"]};
 
$baseVarsTable=$conf["baseVars"]; 
$baseProduct=$conf["productName"]; 
 
 
//relevant comment seek implementation 
//getBaseVar("tax1", "caption", getBaseVar("taxDeclarations", "varId", false));
$res=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyname';"); 
if($res){ 
	$row=mysqli_fetch_array($res, MYSQLI_ASSOC); 
	$mok=$row["value"]; 
} 
$preclude=file_get_contents("./LICENSE_TEMPLATE.txt"); 
 
$include = str_ireplace("#CMTHOLDER#", $baseProduct, $preclude); 
$include = str_ireplace("#MOK#", $mok, $include); 
//echo $include; 
?>
