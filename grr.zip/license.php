<?php
error_reporting(E_ERROR);
ini_set('display_errors', FALSE);
//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);
ini_set('session.use_cookies', 0);
ini_set('session.use_only_cookies', 0);
ini_set('session.use_trans_sid', 0);
global $terransUniteSession, $conf, $sid;
include_once("./base/conf/app_silent.inc.php");
include_once("./base/conf/db.conf.php");
include_once("./base/lang/perlmut.lang.php");
include_once("./base/conf/perlmut.conf.php");
include_once("./vcnnative/lib/functions/perlmut.functions.php");
include_once("./vcnnative/lib/classes/perlmut.classes.php");

require("./base/conf/reqVars.php");
${$conf["APP.SESSION.sign"]}=new AuthSession($conf, $dbm);
$sid=session_initialize(${$conf["APP.SESSION.sign"]}); //may be obsolente cause sid is never needed to be handled
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");
include_once("./copysights.php");
$include = str_ireplace("<", "&lt;", $include);
$include = str_ireplace("<", "&gt;", $include);
$include = str_ireplace("\n", "<BR>", $include);
$include = str_ireplace("#CMTIN#", "<TT>", $include);
$include = str_ireplace("#CMTOUT#", "</TT>", $include);
include_once("./copysights.php");
echo $include;
session_write_close();
exit();
?>
