<?php 
error_reporting(E_ERROR); 
ini_set('display_errors', FALSE); 
//error_reporting(E_ALL); 
//ini_set('display_errors', TRUE);
require("./base/conf/app_silent.inc.php");
require("./base/conf/perlmut.conf.php"); 
$_SESSION["aquired"]=uniqid(); 
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 
 
<html lang="<?php echo $terransUniteSession->lang; ?>"> 
 
<HEAD> 
<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1"> 
<TITLE> 
<?php 
echo $conf["siteTitle"] /*. $lang["subtitles"]["map"][0]["frames"][2][$terransUniteSession->lang] */; 
?> 
</TITLE> 
<?php 
	require("./base/res/includes/jsimports.inc.php"); 
?>
<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=tokenize.js">
</SCRIPT>
<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=nibblesNbytes.js">
</SCRIPT>
<SCRIPT language="JavaScript" type="text/JavaScript"> 
	var itsFrameInfo=null; 
	var ready=false;
	
	function urgent(e){
		e=event?event:e;
		try{
			lol.check_out(e); 
			ready=true;
			makePing();
		}catch(err){

		}finally{
				itsFrameInfo.makeVisible(true); 
		}
	}
	 
	function _init(_itsWidth){
		itsFrameInfo=new FrameInfo(); 
		itsFrameInfo.init(false, false); 
		itsFrameInfo.setSize(getScreenWidth(), getScreenHeight()); 
		itsFrameInfo.setPreferedSize(getScreenWidth(), getScreenHeight()); 
		itsFrameInfo.setMinimumSize(getScreenWidth(), getScreenHeight()); 
		document.body.appendChild(itsFrameInfo.getIFrameNode("./req.php?tsa=formbuild.php&width=" + _itsWidth + "&scrRatio=" + urlGet("scrRatio"), true, 101, 0, 80));
		var itsLOLframeInfo=new FrameInfo(); 
		itsLOLframeInfo.init(false, false); 
		itsLOLframeInfo.setSize(getScreenWidth(), getScreenHeight()); 
		itsLOLframeInfo.setPreferedSize(getScreenWidth(), getScreenHeight()); 
		itsLOLframeInfo.setMinimumSize(getScreenWidth(), getScreenHeight()); 
		document.body.appendChild(itsLOLframeInfo.getIFrameNode("./req.php?tsa=dc.htm", false, 99)); 
		lol=itsLOLframeInfo.getWindow(); 
		lol.onload=urgent;
		disp();
	}

	function disp(){ 
		a=urlGet("scrRatio"); 
		var backgroundNode=document.createElement("DIV"); 
		backgroundNode.style.position="absolute"; 
		backgroundNode.style.zIndex=1; 
		backgroundNode.style.backgroundColor="#777777"; 
		backgroundNode.style.left="" + 0 + "px"; 
		backgroundNode.style.top="" + 0 + "px"; 
		backgroundNode.style.width=694*a +  "px"; 
		backgroundNode.style.height=985*a +  "px"; 
		setOpacity(backgroundNode.style, 98); 
		document.body.appendChild(backgroundNode); 
		var imgNodeCloseCross=document.createElement("IMG"); 
		imgNodeCloseCross.src="./base/res/images/thex.png"; 
		imgNodeCloseCross.style.width=(64*a) + "px"; 
		imgNodeCloseCross.style.height=(64*a) + "px"; 
		imgNodeCloseCross.setAttribute("onmouseup", "closeView();"); 
		var layerNodeCloseCross=document.createElement("DIV"); 
		layerNodeCloseCross.style.position="absolute"; 
		layerNodeCloseCross.style.left=((694-25-64)*a) + "px"; 
		layerNodeCloseCross.style.top=(25*a) + "px"; 
		layerNodeCloseCross.style.width==(84*a) + "px"; 
		layerNodeCloseCross.style.height==(84*a) + "px"; 
		layerNodeCloseCross.style.zIndex=999; 
		layerNodeCloseCross.appendChild(imgNodeCloseCross); 
		document.body.appendChild(layerNodeCloseCross); 
		itsFrameInfo.makeVisible(true);
	} 

	 
	var CONTACT_LOCATION_PHP_XML_RESPONSE_LIB_LINK="./lib/search/contact_location.php"; 
	var POLLING_TME=1000; 
	var lasturl=""; 
	 
	function SearchQuery(zipcode, country){
		this.zipcode=zipcode; 
		this.country=country; 
		this.getSearchQueryString=function(){
			var str="?zipcode=" + this.zipcode + "&country=" + this.country; 
			return str; 
		} 
		this.updateCountry=function(country){ 
			this.country=country; 
		} 
	}
	
	function lift(val){
		var delim=new Array();
		delim[0]="%";
		var retval="";
		var was=false;
		var has=false;
		var tokens=tokenize(val, delim, true);
		for(var v=0; v < tokens.length&&!has; v++){	
			var ischaruni="";
			if(tokens[v]=="%"){
				has=was?true:false;
				was=!has?true:false;
			}else{
				was=false;
				has=false;
				var d=-1;
				if(tokens[v].length==2){
					d=hex2int(tokens[v]);
					ischaruni=document.createTextNode("&#" + d<10?"00"+d:(d<100?"0"+d :d) + ";");
				}else{
					ischaruni=document.createTextNode(tokens[v]);
				}
			}
			retval=retval + ischaruni;
		}
		return retval;
	}

	function fetch(){ 
		var retval=false; 
		if(req!=null){ 
			if(req.readyState == 4){ 
				if(req.status == 200){ 
					response  = req.responseXML.documentElement; 
					cityname=false; 
					for(var d=0; d < response.getElementsByTagName('result').length; d++){ 
						result = response.getElementsByTagName('result')[d]; 
						try{
							cityname=result.getElementsByTagName('cityname')[0].firstChild.data;
						}catch(e){
							;
						}finally{
							;
						}
					} 
					retval=cityname; 
					 
				}else setFetchTimer(POLLING_TME); 
			} 
		}else{ 
			setFetchTimer(POLLING_TME); 
		}
		return retval; 
	} 
	 
	function setFetchTimer(millis){ 
		setTimeout("loadXMLDoc(false);", millis); 
	} 
		 
		function loadXMLDoc(url){ 
			url=url?url:lasturl; 
			lasturl=url; 
			if(lasturl!="") 
			if (window.XMLHttpRequest) { 
				req = new XMLHttpRequest(); 
				req.onreadystatechange = writeIt; 
				req.open("GET", url, true); 
				req.send(null); 
			}else if (window.ActiveXObject) { 
				req = new ActiveXObject("Microsoft.XMLHTTP"); 
				if (req) { 
					req.onreadystatechange = writeIt; 
					req.open("GET", url, true); 
					req.send(); 
				} 
			} 
		} 
 
		 
		function evaluate(){ 
			if(ping!=null){ 
				if(ping.readyState == 4){ 
					if(ping.status == 200){ 
						setTimeout("SecurityPoll()", POLLING_TME); 
						return true; 
					} 
					setTimeout("SecurityPoll();", POLLING_TME); 
					return false; 
				} 
				setTimeout("SecurityPoll();", POLLING_TME); 
				return false; 
			} 
			//no 
		} 
	 
		var ping=null; 
	 
		function getPingResponse(url){ 
			if(lasturl!="") 
			if (window.XMLHttpRequest) { 
				ping = new XMLHttpRequest(); 
				ping.onreadystatechange = evaluate; 
				ping.open("GET", url, true); 
				ping.send(null); 
			}else if (window.ActiveXObject) { 
				ping = new ActiveXObject("Microsoft.XMLHTTP"); 
				if (ping) { 
					ping.onreadystatechange = evaluate; 
					ping.open("GET", url, true); 
					ping.send(); 
				} 
			} 
		} 
	 
	var itsSearchQuery=null; 
	var lastSearchZipCode=""; 
	var lastSearchCountry=""; 
 
	function makeSearchReq(zipcode, country){ 
		lastSearchZipCode=zipcode; 
		lastSearchCountry=country; 
		itsSearchQuery=new SearchQuery(zipcode, country); 
		loadXMLDoc(CONTACT_LOCATION_PHP_XML_RESPONSE_LIB_LINK + itsSearchQuery.getSearchQueryString()); 
	} 
	 
	function makePing(){ 
		getPingResponse("./lib/ping/index.php"); 
	} 
	 
	function SecurityPoll(){
		setTimeout("makeSearchReq(lastSearchZipCode, lastSearchCountry);", 1); 
	}
	 
	function updateSearchReq(country){ 
		itsSearchQuery=itsSearchQuery==null?new SearchQuery(zipcode, country):itsSearchQuery; 
		itsSearchQuery.updateCountry(country); 
		loadXMLDoc(CONTACT_LOCATION_PHP_XML_RESPONSE_LIB_LINK + itsSearchQuery.getSearchQueryString()); 
	} 
	 
	function writeIt(){ 
		var cityname=false; 
		if(cityname=fetch()){
			itsFrameInfo.getWindow().setCityname((cityname)); 
		} 
	}
</SCRIPT>
</HEAD>
<BODY onload="/*iniScrollBarSizes(urlGet('scrRatio'); */_init(urlGet('formWidth')!=-1?urlGet('formWidth'):694);" style="margin-bottom: 0px; background-color: transparent; ">
</BODY> 
</HTML>
