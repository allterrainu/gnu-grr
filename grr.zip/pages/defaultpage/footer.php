<?php 
 
	error_reporting(E_ERROR); 
 
	ini_set('display_errors', FALSE); 
 
	//error_reporting(E_ALL); 
 
	//ini_set('display_errors', TRUE); 
 
	require("./base/conf/app_silent.inc.php"); 
 
	require_once("./base/lang/perlmut.lang.php"); 
 
	require("./base/conf/perlmut.conf.php"); 
 
	 
	global ${$conf["APP.SESSION.sign"]}, $conf; 
	 
	require("./base/lang/perlmut.lang.php");
$baseVarsTable=$conf["baseVars"];
$baseProduct=$conf["productName"];

	header('Content-Type: text/html');
	
	$resT=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'adress';");
if($resT){
	$row=mysqli_fetch_array($resT, MYSQLI_ASSOC);
	$mokTitleName=$row["caption"];
	$mokTitleSlogan=$row["description"];

}

?><?php
	$dateFrozen=isSet($_SESSION["viewDate"])?$_SESSION["viewDate"]:getDate();
	$gts=$terransUniteSession->formatDate($dateFrozen , "DD. MN YYYY", false);
	$dateFrozenh=$terransUniteSession->getDate($dateFrozen, true);
	$hts=$terransUniteSession->formatDate($dateFrozenh , "DD. MN YYYY", true);

//relevant comment seek implementation

$res1=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyname';");
if($res1){
	$row=mysqli_fetch_array($res1, MYSQLI_ASSOC);
	$mokCompanyName=$row["value"];
	$mokCompanySlogan=$row["description"];
}

$res2=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'phone';");
if($res2){
	$row=mysqli_fetch_array($res2, MYSQLI_ASSOC);
	$mokPhoneNumber=$row["value"];
	$mokPhoneEntry=$row["caption"];
	$mokPhoneText=$row["description"];
}

$res3=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'adress';");
if($res3){
	$row=mysqli_fetch_array($res3, MYSQLI_ASSOC);-
	$mokAdress=$row["value"];
}

$res4=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyId';");
if($res4){
	$row=mysqli_fetch_array($res4, MYSQLI_ASSOC);
	$mokVAT=$row["caption"];
	$mokId=$row["value"];
	$mokImprint=$row["description"];
}


$res5=${$conf["APP.SESSION.sign"]}->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyLocals';");
if($res5){
	$row=mysqli_fetch_array($res5, MYSQLI_ASSOC);
	$mokCourt=$row["value"];
	$mokLaw=$row["caption"];
}

?>
<HTML> 
<HEAD> 
<TITLE>sliced Animation</TITLE> 
<META name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">  
<SCRIPT language="JavaScript" type="text/JavaScript"> 
 
function Frame(src, width, height){ 
	this.itsImage=new Image(width, height); 
	this.itsImage.src=src; 
	this.itsFunc=""; 
	 
	this.setFunction=function(to){ 
	this.itsFunc=to; 
	} 
	 
	this.spoolTo=function(id){ 
		if(this.itsFunc!="") eval(this.itsFunc); 
		document.getElementById(id).style.backgroundImage="url(" + this.itsImage.src + ")"; 
	} 
} 
 
var thread=null; 
var seq1=null; 
 
function Sequence(invoke, srcbase, max, suffix, width, height, fps, id){ 
	this.invoke=invoke; 
	this.id=id; 
	this.max=max; 
	this.fps=fps; 
	this.i=1; 
	this.holder=new Array(); 
	this.once=false; 
	for(var v=1; v <= max; v++){ 
		this.holder.push(new Frame(srcbase + (max<100?(v<10?"0"+v:v):(max<1000?(v<10?"00"+v:(v<100?"0"+v:v)):v)) + "." + suffix, width, height)); 
	} 
	 
	this.setShutdownFunction=function(to){ 
		this.holder[this.holder.length-1].setFunction(to); 
	} 
	 
	this.append=function(srcbase, max, suffix, width, height){ 
		var m=this.max+max; 
		for(var v=1; v <= max; v++){ 
		this.holder.push(new Frame(srcbase + (max<100?(v<10?"0"+v:v):(max<1000?(v<10?"00"+v:(v<100?"0"+v:v)):v)) + "." + suffix, width, height)); 
		} 
		this.max=m; 
	 
	} 
	 
	this.run=function(once){ 
	this.once=once; 
	if(this.i==this.max-1){ this.i=0; if(this.once){this.i=this.max-1; clearTimeout(thread); } else 
	thread=setTimeout(this.invoke + ".run(" + this.once + ")", 1000/this.fps);} else thread=setTimeout(this.invoke + ".run(" + this.once + ")", 1000/this.fps);; 
		this.holder[this.i++].spoolTo(this.id); 
	} 
} 
 
var tap=false; 
 
function hide(){
document.getElementById("not").style.visibility="hidden";
document.getElementById("apply").style.visibility="visible";
}

function show(){
document.getElementById("not").style.visibility="visible";
document.getElementById("apply").style.visibility="hidden";
}

function _init(){ 
	tap=true; 
	clearTimeout(thread); seq1=new Sequence('seq1', escape('./res/gfx/footer/normal/footer_step1_v '), 42, 'png', 240, 38, 19, '_itsPlayZone'); seq1.run(false); 
} 
 
function _init2(){ 
hide();
	tap=false; 
	seq1.append(escape('./res/gfx/footer/aktiv/footer_step2_v '), 37, 'png', 1080, 171); clearTimeout(thread); seq1.run(true); 
//seq1.setShutdowFunction("hide();")
} 
 
function _init3(){ 
	if(!tap){
show();
		seq1.append(escape('./res/gfx/footer/inaktiv/footer_step3_v '), 43, 'png', 1080, 171);  clearTimeout(thread); seq1.run(true); seq1.setShutdownFunction('_init();'); 
	} 
} 

function _initBuffers(){
seq1=new Sequence('seq1', escape('./res/gfx/footer/normal/footer_step1_v '), 42, 'png', 240, 38, 19, '_itsPlayZone');
seq1.append(escape('./res/gfx/footer/aktiv/footer_step2_v '), 37, 'png', 1080, 171);
seq1.append(escape('./res/gfx/footer/inaktiv/footer_step3_v '), 43, 'png', 1080, 171);
seq1=null;
}

 
</SCRIPT> 
</HEAD> 
<BODY style="margin: 0px; " onload="_initBuffers(); _init();" onunload="clearTimeout(thread);">
<DIV onmouseover="_init2();" onmouseout="_init3();" style="width: 1080px; height: 171px; background-image: url(./res/gfx/footer/normal/footer_step1_v%2001.png); background-repeat: norepeat; background-attachement: fixed; border-style: none; " id="_itsPlayZone"><DIV style="height: 94px; "></DIV><DIV style="flow: left; color: blue; text-decoration: none; "><A href="./req.php?tsa=imprint.php" target="_new">Impressum &gt;&gt;</A></DIV><MARQUEE><SPAN style="visibility: hidden; " id="apply"><SPAN class="companySlogan"><?php echo $mokTitleSlogan; ?>
</SPAN>
		<SPAN class="subtext"><?php echo $mokImprint; ?></SPAN><BR>
		<SPAN class="subtext"><?php echo $mokVAT; ?></SPAN>
		<SPAN class="subtext"><?php echo $mokId; ?></SPAN>
		<SPAN class="subtext"><?php echo $mokLaw; ?></SPAN>
		<SPAN class="subtext"><?php echo $mokCourt; ?></SPAN>
		<SPAN class="subtext"><?php echo $mokCompanyName; ?></SPAN>
		<SPAN class="subtext"><?php echo $mokAdress; ?></SPAN></SPAN><SPAN id="not" style="visibility: hidden; "><SPAN class="companyNamePlain"><?php echo $mokCompanyName; ?></SPAN></SPAN></MARQUEE><SPAN style="width: 400px; ">&nbsp;</SPAN></DIV></BODY></HTML>
