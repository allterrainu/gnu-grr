<?php 
require_once("./base/lang/app_silent.inc.php");

	global ${$conf["APP.SESSION.sign"]};
 	require_once("./base/lang/perlmut.lang.php");
	header('Content-Type: text/html'); 
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 
<html lang="en"> 
<HEAD> 
<TITLE>This Site appears and the problem has been solved.</TITLE> 
<link rel="styleSheet" href="./base/res/styles/default.css" type="text/css"> 
<?php 
include("./base/res/includes/jsimports.inc.php"); 
?>
</HEAD> 
<BODY onload="" style="background-color: transparent; overflow: hidden; margin: 0 0 0 0; color: #FFFFFF; "> 
<?php 
${$conf["APP.SESSION.sign"]}->virtualcookie_write(uniqid());
/*	$dateFrozen=isSet($_SESSION["viewDate"])?$_SESSION["viewDate"]:getDate(); 
	$gts=$terransUniteSession->formatDate($dateFrozen , "DD. MN YYYY", false); 
	$dateFrozenh=$terransUniteSession->getDate($dateFrozen, true); 
	$hts=$terransUniteSession->formatDate($dateFrozenh , "DD. MN YYYY", true); 
	echo "<TT style=\"color: #FFFFFF; \">"; 
	require_once("./vcnnative/lib/classes/perlmut.dateValve.php"); 
	echo "</TT><BR>"; 
	echo "<TT style=\"color: #FFFFFF; \">" . "@" . $gts . "</TT><BR>"; 
	echo "<TT style=\"color: #FFFFFF; \">" . "@" . $hts . "</TT><BR>"; 
	$nrt=getMoonPhase($dateFrozen, 180); 
	$nrt=1*$nrt; 
	$imgsrc="mooncan " . ($nrt<10?"00":(($nrt<100)?"0":"")) . $nrt . ".png"; 
	$imgpath="./base/res/gfx/"; 
	$tagsrc="" . $imgpath . "" . $imgsrc; 
	echo "<IMG class=\"moonIMG\" src=\"" . $tagsrc . "\" title=\"\" alt=\"\">               "; 
*/
?>
</BODY> 
</HTML>
