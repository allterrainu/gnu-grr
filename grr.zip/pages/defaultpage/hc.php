<?php
error_reporting(E_ERROR);
ini_set('display_errors', FALSE);
//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);
require("./base/conf/app_silent.inc.php");
require("./base/conf/perlmut.conf.php");
$formMaxRequest=3;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<HEAD>
<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1">
<TITLE>
<?php
echo $conf["siteTitle"] . " - AnitMailBombControl";	
?>
</TITLE>

<SCRIPT language="JavaScript" type="text/JavaScript">

<?php

	

?>

	function count(){
		return ws;
	}

	function _init2(){
		<?php
		$_SESSION["clearancy"]=$_SESSION["aquired"];
		if(isSet($_SESSION["crtl"])) echo "var ws=" . (isSet($_SESSION["crtl"])?$_SESSION["crtl"]:$formMaxRequest) . ";"; else echo "var ws=1;";
		if($_SESSION["crtl"]>$formMaxRequest){
			//security fetch
			//<ATM>
			//</ATM>
		}
		echo "if(ws>" . $formMaxRequest . ")";
		?>
		{
			alert("Leider kannst Du im Moment keine weiteren Anfragen an uns schicken.");
		}

	}
</SCRIPT>
<SCRIPT language="JavaScript" type="text/JavaScript">
</SCRIPT>
</HEAD>
<BODY onload="_init2();">
</BODY>
</HTML>
<?php

?>