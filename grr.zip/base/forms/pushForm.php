<?php
	echo "<input type=\"hidden\" name=\"send\" value=\"\">"; //then a variable
	echo "<input type=\"hidden\" name=\"toNickname\" value=\"" . $to . "\">";//are u private
	echo "<input type=\"hidden\" name=\"formatedEvent\" value=\"\">";//that'S it
	echo "<input style=\"font-size: 18;\" type=\"text\" size=\"50\" maxlength=\"254\" name=\"unformatedEvent\" value=\"\">";
	echo "<input type=\"hidden\" name=\"sid\" value=\"$pcsid\">";
	echo "<input type=\"submit\" name=\"nailThough\" value=\"{$lang["buttons"]["send"]["caption"]["de"]}\">";
?>
