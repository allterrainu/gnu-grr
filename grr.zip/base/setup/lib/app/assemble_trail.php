</BODY>
<?php
//[UPSIDE]normal plot above stdsystem 
//human
//################################
//robots usually below
//[DOWNSIDE]robot or human without cookies 
//some erros while loading may be switched

$already=true;

?>
</HTML>