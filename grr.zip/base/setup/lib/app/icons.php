<DIV><IFRAME frameborder="0" style="width: 100%; height: 100px; background-color: #00DD44; " name="head" src="./progressBar.php"></IFRAME></DIV>
<DIV><IFRAME frameborder="0" name="main" style="width: 100%; height: 430px; background-color: #FFFFFF; " src="./presents.php"></IFRAME></DIV>
<DIV><IFRAME frameborder="0" name="footer" style="width: 100%; height: 100px; background-color: #EEEEEE; " src="./toolBar.php"></IFRAME></DIV>
