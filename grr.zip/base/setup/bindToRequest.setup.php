<?php

/*
	Copyright �2007-2013 Daniel Wiesen�cker

    
    This file is part of AngelTrack.

    AngelTrack is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    AngelTrack is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AngelTrack. If not, see <http://www.gnu.org/licenses/>.


*/

	require("./../conf/db.conf.php");

	require("./../conf/perlmut.conf.php");
	
	require("./../conf/reqVars.php");

	require("./../lang/perlmut.lang.php");

	require("./../../vcnnative/lib/functions/perlmut.functions.php");

	require("./../../vcnnative/lib/classes/perlmut.classes.php");

		
	$security_stunt=$conf["securityStunt"];
	
	$stunt_request_invoke=$conf["stunt_request_invoke"];
	
	$security_request_invoke=$conf["security_request_invoke"];

	//connect
	$what_dbhost=$dbm["what_dbhost"];
	$what_dblogin=$dbm["what_dblogin"];
	$what_dbpwd=$dbm["what_dbpass"];
	$what_dbname=$dbm["what_dbname"];

	
header('Content-Type: text/html');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" >
<HTML>
<HEAD>
<TITLE>
	RequestBinding - version 0.02.qira.6603.66
</TITLE>
</HEAD>
<BODY onload="if(document.forms['chooser']) document.forms['chooser'].submit();">
<?php
	$a=0;
	$sql[$a++]="TRUNCATE TABLE `$stunt_request_invoke`;";
?>
<?php
$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname);

if ($what_db->connect_error) {
    die('Connect Error (' . $what_db->connect_errno . ') '
            . $what_db->connect_error);
}else $error=false;
	$a=0;
 	for($i=0; $i < sizeof($sql); $i++){

	
		$override=false;
	
		if(!$override){
			$result=mysqli_query($what_db, $sql[$i]);

			if(!$result){


				echo mysqli_error($what_db);

				$error=true;

			}else{
				
				echo "<P>Specific table \"" . $stunt_request_invoke . "\" empty. ok. ready.</P>";
				
			}
		}
	}

	mysqli_close($what_db);
	if(!$error){
?>
		<P><BIG><TT>Freeing of Access ready.</BIG></TT></P>
		
<?php
	}
	$a=0;
	for($v=0; $v < sizeof($REQUESTVAR); $v++){
		$sqlPre[$a++]="SELECT DISTINCT `passThroughId` FROM `$security_stunt` WHERE `fileName`='" . $REQUESTVAR[$v][$TILE_SEGMENT_ACCESS] . "' AND `path`='" . $REQUESTVAR[$v][$DATA_SEGMENT_CONTROL] . "';";
	}
?>
<?php
$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname);

if ($what_db->connect_error) {
    die('Connect Error (' . $what_db->connect_errno . ') '
            . $what_db->connect_error);
}else $error=false;
	$a=0;
 	for($i=0; $i < sizeof($sqlPre); $i++){

	
		$override=false;
	
		if(!$override){
			$result=mysqli_query($what_db, $sqlPre[$i]);

			if(!$result){


				echo mysql_error();

				$error=true;

			}else{
				if($result->num_rows>0){
					$enRow=mysqli_fetch_array($result, MYSQLI_NUM);
					$ptId[$a++]=$enRow[0];
				}else{
				?>
					<TT>Fehler aufgetreten. Datei <BIG><I>
				<?php
					$REQUESTVAR[$v][$TILE_SEGMENT_ACCESS]
				?>
					</I></BIG><TT>scheint nicht vorhanden zu sein.</TT><BR>
				<?php
				}
			}
		}
	}

	mysqli_close($what_db);
	if(!$error){
?>
		<P><BIG><TT>Gathering Of requestFileData ready.</BIG></TT></P>
		
<?php
}else echo "<P color=\"red\">failure [1468] occured contact administrator!</P>";
?>

<?php
	$a=0;
	for($v=0; $v < sizeof($REQUESTVAR); $v++){
		$sqlPost[$a++]="INSERT INTO `$stunt_request_invoke` (`passThroughId`, `REQUEST_INI`) VALUES('" . $ptId[$v] . "', '" . $REQUESTVAR[$v][$ACTION_REQUEST_INI] . "')";
	}
?>


<?php
$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname);

if ($what_db->connect_error) {
    die('Connect Error (' . $what_db->connect_errno . ') '
            . $what_db->connect_error);
}else $error=false;
	$a=0;
 	for($i=0; $i < sizeof($sqlPost); $i++){

	
		$override=false;
	
		if(!$override){
			$result=mysqli_query($what_db, $sqlPost[$i]);

			if(!$result){


				echo mysqli_error($what_db);

				$error=true;
				
				?>
					<TT>Fehler aufgetreten.</TT>
				<?php

			}else{
				?>
					<TT>.</TT>
				<?php
			}
		}
	}

	mysqli_close($what_db);
	if(!$error){
?>
		<P><BIG><TT>Binding Of requestFileData to requestActionPerform enabled.</BIG></TT></P>
		
<?php
}else echo "<P color=\"red\">failure [2500] occured contact administrator!</P>";
?>
</BODY>
</HTML>