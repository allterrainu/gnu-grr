<?php

/*

Quelle: NDW

Deutsche Welle Tel.: +49.228.429.4000

Kundenservice Fax: +49.228.429.154000

53110 Bonn E-mail: info@dw-world.de

*/





//***

$timezone[0]["country"]["de"]="Afghanistan";

$timezone[0]["utc"]["w"]="+4.25";

$timezone[0]["utc"]["s"]="+4.25";

//***

$timezone[1]["country"]["de"]="�gypten";

$timezone[1]["utc"]["w"]="+2";

$timezone[1]["utc"]["s"]="+3";

//***

$timezone[2]["country"]["de"]="Alaska";

$timezone[2]["utc"]["w"]="-9";

$timezone[2]["utc"]["s"]="-8";

//***

$timezone[3]["country"]["de"]="Algerien";

$timezone[3]["utc"]["w"]="+1";

$timezone[3]["utc"]["s"]="+1";

//***

$timezone[4]["country"]["de"]="Angola";

$timezone[4]["utc"]["w"]="+1";

$timezone[4]["utc"]["s"]="+1";

//***

$timezone[5]["country"]["de"]="Argentinien";

$timezone[5]["utc"]["w"]="-3";

$timezone[5]["utc"]["s"]="-3";

//***

$timezone[6]["country"]["de"]="Armenien";

$timezone[6]["utc"]["w"]="+4";

$timezone[6]["utc"]["s"]="+5";

//***

$timezone[7]["country"]["de"]="�thiopien";

$timezone[7]["utc"]["w"]="+3";

$timezone[7]["utc"]["s"]="+3";

//***

$timezone[8]["country"]["de"]="Australien: Sydney, Melbourne";

$timezone[8]["utc"]["w"]="+10";

$timezone[8]["utc"]["s"]="+11";

//***

$timezone[9]["country"]["de"]="Australien: Darwin";

$timezone[9]["utc"]["w"]="+9.5";

$timezone[9]["utc"]["s"]="+9.5";

//***

$timezone[10]["country"]["de"]="Australien: Perth";

$timezone[10]["utc"]["w"]="+8";

$timezone[10]["utc"]["s"]="+8";

//***

$timezone[11]["country"]["de"]="Azoren";

$timezone[11]["utc"]["w"]="-1";

$timezone[11]["utc"]["s"]="0";

//***

$timezone[12]["country"]["de"]="Bahrain";

$timezone[12]["utc"]["w"]="+3";

$timezone[12]["utc"]["s"]="+3";

//***

$timezone[13]["country"]["de"]="Bangladesh";

$timezone[13]["utc"]["w"]="+6";

$timezone[13]["utc"]["s"]="+6";

//***

$timezone[14]["country"]["de"]="Belize";

$timezone[14]["utc"]["w"]="-6";

$timezone[14]["utc"]["s"]="-6";

//***

$timezone[15]["country"]["de"]="Benin";

$timezone[15]["utc"]["w"]="+1";

$timezone[15]["utc"]["s"]="+1";

//***

$timezone[16]["country"]["de"]="Bolivien";

$timezone[16]["utc"]["w"]="-4";

$timezone[16]["utc"]["s"]="-4";

//***

$timezone[17]["country"]["de"]="Botswana";

$timezone[17]["utc"]["w"]="+2";

$timezone[17]["utc"]["s"]="+2";

//***

$timezone[18]["country"]["de"]="Brasilien: Rio, S. Paulo";

$timezone[18]["utc"]["w"]="-3";

$timezone[18]["utc"]["s"]="-2";

//***

$timezone[19]["country"]["de"]="Brasilien: Manaus";

$timezone[19]["utc"]["w"]="-4";

$timezone[19]["utc"]["s"]="-4";



$timezone[20]["country"]["de"]="Brunei";

$timezone[20]["utc"]["w"]="+8";

$timezone[20]["utc"]["s"]="+8";

//***

$timezone[21]["country"]["de"]="Bulgarien";

$timezone[21]["utc"]["w"]="+2";

$timezone[21]["utc"]["s"]="+3";

//***

$timezone[22]["country"]["de"]="Burundi";

$timezone[22]["utc"]["w"]="+2";

$timezone[22]["utc"]["s"]="+2";

//***

$timezone[23]["country"]["de"]="Chile";

$timezone[23]["utc"]["w"]="-4";

$timezone[23]["utc"]["s"]="-3";

//***

$timezone[24]["country"]["de"]="China";

$timezone[24]["utc"]["w"]="+8";

$timezone[24]["utc"]["s"]="+8";

//***

$timezone[25]["country"]["de"]="Cook Inseln";

$timezone[25]["utc"]["w"]="-10";

$timezone[25]["utc"]["s"]="-10";

//***

$timezone[26]["country"]["de"]="Costa Rica";

$timezone[26]["utc"]["w"]="-6";

$timezone[26]["utc"]["s"]="-6";

//***

$timezone[27]["country"]["de"]="Dschibuti";

$timezone[27]["utc"]["w"]="+3";

$timezone[27]["utc"]["s"]="+3";

//***

$timezone[28]["country"]["de"]="Ecuador";

$timezone[28]["utc"]["w"]="-5";

$timezone[28]["utc"]["s"]="-5";

//***

$timezone[29]["country"]["de"]="El Salvador";

$timezone[29]["utc"]["w"]="-6";

$timezone[29]["utc"]["s"]="-6";

//***

$timezone[30]["country"]["de"]="Estland";

$timezone[30]["utc"]["w"]="+2";

$timezone[30]["utc"]["s"]="+3";

//***

$timezone[31]["country"]["de"]="Eritrea";

$timezone[31]["utc"]["w"]="+3";

$timezone[31]["utc"]["s"]="+3";

//***

$timezone[32]["country"]["de"]="Fidschi";

$timezone[32]["utc"]["w"]="+12";

$timezone[32]["utc"]["s"]="+12";

//***

$timezone[33]["country"]["de"]="Finnland";

$timezone[33]["utc"]["w"]="+2";

$timezone[33]["utc"]["s"]="+3";

//***

$timezone[34]["country"]["de"]="Gabun";

$timezone[34]["utc"]["w"]="+1";

$timezone[34]["utc"]["s"]="+1";

//***

$timezone[35]["country"]["de"]="Georgien";

$timezone[35]["utc"]["w"]="+3";

$timezone[35]["utc"]["s"]="+4";

//***

$timezone[36]["country"]["de"]="Griechenland";

$timezone[36]["utc"]["w"]="+2";

$timezone[36]["utc"]["s"]="+3";

//***

$timezone[37]["country"]["de"]="Guatemala";

$timezone[37]["utc"]["w"]="-6";

$timezone[37]["utc"]["s"]="-6";

//***

$timezone[38]["country"]["de"]="Guyana";

$timezone[38]["utc"]["w"]="-4";

$timezone[38]["utc"]["s"]="-4";

//***

$timezone[39]["country"]["de"]="Hawaii";

$timezone[39]["utc"]["w"]="-10";

$timezone[39]["utc"]["s"]="-10";

//***

$timezone[40]["country"]["de"]="Honduras";

$timezone[40]["utc"]["w"]="-6";

$timezone[40]["utc"]["s"]="-6";

//***

$timezone[41]["country"]["de"]="Hong Kong";

$timezone[41]["utc"]["w"]="+8";

$timezone[41]["utc"]["s"]="+8";

//***

$timezone[42]["country"]["de"]="Indien";

$timezone[42]["utc"]["w"]="+5.5";

$timezone[42]["utc"]["s"]="+5.5";

//***

$timezone[43]["country"]["de"]="Indonesien: Java, Sumatra";

$timezone[43]["utc"]["w"]="+7";

$timezone[43]["utc"]["s"]="+7";

//***

$timezone[44]["country"]["de"]="Indonesien: Borneo, Bali";

$timezone[44]["utc"]["w"]="+8";

$timezone[44]["utc"]["s"]="+8";

//***

$timezone[45]["country"]["de"]="Indonesien: West Irian";

$timezone[45]["utc"]["w"]="+9";

$timezone[45]["utc"]["s"]="+9";

//***

$timezone[46]["country"]["de"]="Irak";

$timezone[46]["utc"]["w"]="+3";

$timezone[46]["utc"]["s"]="+4";

//***

$timezone[47]["country"]["de"]="Iran";

$timezone[47]["utc"]["w"]="+3.5";

$timezone[47]["utc"]["s"]="+4.5";

//***

$timezone[48]["country"]["de"]="Island";

$timezone[48]["utc"]["w"]="0";

$timezone[48]["utc"]["s"]="0";

//***

$timezone[49]["country"]["de"]="Israel";

$timezone[49]["utc"]["w"]="+2";

$timezone[49]["utc"]["s"]="+3";

//***

$timezone[50]["country"]["de"]="Japan";

$timezone[50]["utc"]["w"]="+9";

$timezone[50]["utc"]["s"]="+9";

//***

$timezone[51]["country"]["de"]="Jemen";

$timezone[51]["utc"]["w"]="+3";

$timezone[51]["utc"]["s"]="+3";

//***

$timezone[52]["country"]["de"]="Jordanien";

$timezone[52]["utc"]["w"]="+2";

$timezone[52]["utc"]["s"]="+3";

//***

$timezone[53]["country"]["de"]="Kambodscha";

$timezone[53]["utc"]["w"]="+7";

$timezone[53]["utc"]["s"]="+7";

//***

$timezone[54]["country"]["de"]="Kamerun";

$timezone[54]["utc"]["w"]="+1";

$timezone[54]["utc"]["s"]="+1";

//***

$timezone[55]["country"]["de"]="Kanada: Montreal";

$timezone[55]["utc"]["w"]="-5";

$timezone[55]["utc"]["s"]="-4";

//***

$timezone[56]["country"]["de"]="Kanada: Winnipeg";

$timezone[56]["utc"]["w"]="-6";

$timezone[56]["utc"]["s"]="-5";

//***

$timezone[57]["country"]["de"]="Kanada: Calgary";

$timezone[57]["utc"]["w"]="-7";

$timezone[57]["utc"]["s"]="-6";

//***

$timezone[58]["country"]["de"]="Kanada: Vancouver";

$timezone[58]["utc"]["w"]="-8";

$timezone[58]["utc"]["s"]="-7";

//***

$timezone[59]["country"]["de"]="Kapverd. Inseln";

$timezone[59]["utc"]["w"]="-1";

$timezone[59]["utc"]["s"]="-1";

//***

$timezone[60]["country"]["de"]="Antigua";

$timezone[60]["utc"]["w"]="-4";

$timezone[60]["utc"]["s"]="-4";

//***

$timezone[61]["country"]["de"]="Bahamas";

$timezone[61]["utc"]["w"]="-5";

$timezone[61]["utc"]["s"]="-4";

//***

$timezone[62]["country"]["de"]="Barbados";

$timezone[62]["utc"]["w"]="-4";

$timezone[62]["utc"]["s"]="-4";

//***

$timezone[63]["country"]["de"]="Bermuda";

$timezone[63]["utc"]["w"]="-4";

$timezone[63]["utc"]["s"]="-3";

//***

$timezone[64]["country"]["de"]="Dom. Republik";

$timezone[64]["utc"]["w"]="-4";

$timezone[64]["utc"]["s"]="-4";

//***

$timezone[65]["country"]["de"]="Guadaloupe";

$timezone[65]["utc"]["w"]="-4";

$timezone[65]["utc"]["s"]="-4";

//***

$timezone[66]["country"]["de"]="Haiti";

$timezone[66]["utc"]["w"]="-5";

$timezone[66]["utc"]["s"]="-5";

//***

$timezone[67]["country"]["de"]="Jamaica";

$timezone[67]["utc"]["w"]="-5";

$timezone[67]["utc"]["s"]="-5";

//***

$timezone[68]["country"]["de"]="Kuba";

$timezone[68]["utc"]["w"]="-5";

$timezone[68]["utc"]["s"]="-4";

//***

$timezone[69]["country"]["de"]="Martinique";

$timezone[69]["utc"]["w"]="-4";

$timezone[69]["utc"]["s"]="-4";

//***

$timezone[70]["country"]["de"]="Niederl. Antillen";

$timezone[70]["utc"]["w"]="-4";

$timezone[70]["utc"]["s"]="-4";

//***

$timezone[71]["country"]["de"]="Puerto Rico";

$timezone[71]["utc"]["w"]="-4";

$timezone[71]["utc"]["s"]="-4";

//***

$timezone[72]["country"]["de"]="Trinidad & Tobago";

$timezone[72]["utc"]["w"]="-4";

$timezone[72]["utc"]["s"]="-4";

//***

$timezone[73]["country"]["de"]="Kasachstan, Alma Ata";

$timezone[73]["utc"]["w"]="+6";

$timezone[73]["utc"]["s"]="+7";

//***

$timezone[74]["country"]["de"]="Kenia";

$timezone[74]["utc"]["w"]="+3";

$timezone[74]["utc"]["s"]="+3";

//***

$timezone[75]["country"]["de"]="Kolumbien";

$timezone[75]["utc"]["w"]="-5";

$timezone[75]["utc"]["s"]="-5";

//***

$timezone[76]["country"]["de"]="Kongo - Brazzaville";

$timezone[76]["utc"]["w"]="+1";

$timezone[76]["utc"]["s"]="+1";

//***

$timezone[77]["country"]["de"]="Kongo Rep: Kinshasa";

$timezone[77]["utc"]["w"]="+1";

$timezone[77]["utc"]["s"]="+1";

//***

$timezone[78]["country"]["de"]="Kongo Rep: Lubumbashi";

$timezone[78]["utc"]["w"]="+2";

$timezone[78]["utc"]["s"]="+2";

//***

$timezone[79]["country"]["de"]="Korea, Nord & S�d";

$timezone[79]["utc"]["w"]="+9";

$timezone[79]["utc"]["s"]="+9";

//***

$timezone[80]["country"]["de"]="Kuwait";

$timezone[80]["utc"]["w"]="+3";

$timezone[80]["utc"]["s"]="+3";

//***

$timezone[81]["country"]["de"]="Laos";

$timezone[81]["utc"]["w"]="+7";

$timezone[81]["utc"]["s"]="+7";

//***

$timezone[82]["country"]["de"]="Lettland";

$timezone[82]["utc"]["w"]="+2";

$timezone[82]["utc"]["s"]="+3";

//***

$timezone[83]["country"]["de"]="Libanon";

$timezone[83]["utc"]["w"]="+2";

$timezone[83]["utc"]["s"]="+3";

//***

$timezone[84]["country"]["de"]="Libyen";

$timezone[84]["utc"]["w"]="+2";

$timezone[84]["utc"]["s"]="+2";

//***

$timezone[85]["country"]["de"]="Litauen";

$timezone[85]["utc"]["w"]="+2";

$timezone[85]["utc"]["s"]="+3";

//***

$timezone[86]["country"]["de"]="Macau";

$timezone[86]["utc"]["w"]="+8";

$timezone[86]["utc"]["s"]="+8";

//***

$timezone[87]["country"]["de"]="Madagaskar";

$timezone[87]["utc"]["w"]="+3";

$timezone[87]["utc"]["s"]="+3";

//***

$timezone[88]["country"]["de"]="Malawi";

$timezone[88]["utc"]["w"]="+2";

$timezone[88]["utc"]["s"]="+2";

//***

$timezone[89]["country"]["de"]="Malaysia";

$timezone[89]["utc"]["w"]="+8";

$timezone[89]["utc"]["s"]="+8";

//***

$timezone[90]["country"]["de"]="Malediven";

$timezone[90]["utc"]["w"]="+5";

$timezone[90]["utc"]["s"]="+5";

//***

$timezone[91]["country"]["de"]="Mauritius";

$timezone[91]["utc"]["w"]="+4";

$timezone[91]["utc"]["s"]="+4";

//***

$timezone[92]["country"]["de"]="Mex.City, Canc�n, Acap.";

$timezone[92]["utc"]["w"]="-6";

$timezone[92]["utc"]["s"]="-5";

//***

$timezone[93]["country"]["de"]="Moldawien";

$timezone[93]["utc"]["w"]="+2";

$timezone[93]["utc"]["s"]="+3";

//***

$timezone[94]["country"]["de"]="Mongolei, Ulan Bator";

$timezone[94]["utc"]["w"]="+8";

$timezone[94]["utc"]["s"]="+8";

//***

$timezone[95]["country"]["de"]="Mosambik";

$timezone[95]["utc"]["w"]="+2";

$timezone[95]["utc"]["s"]="+2";

//***

$timezone[96]["country"]["de"]="Myanmar";

$timezone[96]["utc"]["w"]="+6.5";

$timezone[96]["utc"]["s"]="+6.5";

//***

$timezone[97]["country"]["de"]="Namibia";

$timezone[97]["utc"]["w"]="+2";

$timezone[97]["utc"]["s"]="+1";

//***

$timezone[98]["country"]["de"]="Nepal";

$timezone[98]["utc"]["w"]="+5.75";

$timezone[98]["utc"]["s"]="+5.75";

//***

$timezone[99]["country"]["de"]="Neuseeland";

$timezone[99]["utc"]["w"]="+12";

$timezone[99]["utc"]["s"]="+13";

//***

$timezone[100]["country"]["de"]="Nicaragua";

$timezone[100]["utc"]["w"]="-6";

$timezone[100]["utc"]["s"]="-6";

//***

$timezone[101]["country"]["de"]="Niger";

$timezone[101]["utc"]["w"]="+1";

$timezone[101]["utc"]["s"]="+1";

//***

$timezone[102]["country"]["de"]="Nigeria";

$timezone[102]["utc"]["w"]="+1";

$timezone[102]["utc"]["s"]="+1";

//***

$timezone[103]["country"]["de"]="Oman";

$timezone[103]["utc"]["w"]="+4";

$timezone[103]["utc"]["s"]="+4";

//***

$timezone[104]["country"]["de"]="Pakistan";

$timezone[104]["utc"]["w"]="+5";

$timezone[104]["utc"]["s"]="+6";

//***

$timezone[105]["country"]["de"]="Panama";

$timezone[105]["utc"]["w"]="-5";

$timezone[105]["utc"]["s"]="-5";

//***

$timezone[106]["country"]["de"]="Papua Neuguinea";

$timezone[106]["utc"]["w"]="+10";

$timezone[106]["utc"]["s"]="+10";

//***

$timezone[107]["country"]["de"]="Paraguay";

$timezone[107]["utc"]["w"]="-4";

$timezone[107]["utc"]["s"]="-3";

//***

$timezone[108]["country"]["de"]="Peru";

$timezone[108]["utc"]["w"]="-5";

$timezone[108]["utc"]["s"]="-5";

//***

$timezone[109]["country"]["de"]="Philippinen";

$timezone[109]["utc"]["w"]="+8";

$timezone[109]["utc"]["s"]="+8";

//***

$timezone[110]["country"]["de"]="Qatar";

$timezone[110]["utc"]["w"]="+3";

$timezone[110]["utc"]["s"]="+3";

//***

$timezone[111]["country"]["de"]="R�union";

$timezone[111]["utc"]["w"]="+4";

$timezone[111]["utc"]["s"]="+4";

//***

$timezone[112]["country"]["de"]="Ruanda";

$timezone[112]["utc"]["w"]="+2";

$timezone[112]["utc"]["s"]="+2";

//***

$timezone[113]["country"]["de"]="Rum�nien";

$timezone[113]["utc"]["w"]="+2";

$timezone[113]["utc"]["s"]="+3";

//***

$timezone[114]["country"]["de"]="Russland: Kaliningrad";

$timezone[114]["utc"]["w"]="+2";

$timezone[114]["utc"]["s"]="+3";

//***

$timezone[115]["country"]["de"]="Russland: Moskau";

$timezone[115]["utc"]["w"]="+3";

$timezone[115]["utc"]["s"]="+4";

//***

$timezone[116]["country"]["de"]="Russland: Jekaterinburg";

$timezone[116]["utc"]["w"]="+5";

$timezone[116]["utc"]["s"]="+6";

//***

$timezone[117]["country"]["de"]="Russland: Novosibirsk";

$timezone[117]["utc"]["w"]="+6";

$timezone[117]["utc"]["s"]="+7";

//***

$timezone[118]["country"]["de"]="Russland: Irkutsk";

$timezone[118]["utc"]["w"]="+8";

$timezone[118]["utc"]["s"]="+9";

//***

$timezone[119]["country"]["de"]="Russland: Petropavlosk";

$timezone[119]["utc"]["w"]="+12";

$timezone[119]["utc"]["s"]="+13";

//***

$timezone[120]["country"]["de"]="Sambia";

$timezone[120]["utc"]["w"]="+2";

$timezone[120]["utc"]["s"]="+2";

//***

$timezone[121]["country"]["de"]="Samoa";

$timezone[121]["utc"]["w"]="-11";

$timezone[121]["utc"]["s"]="-11";

//***

$timezone[122]["country"]["de"]="Saudi Arabien";

$timezone[122]["utc"]["w"]="+3";

$timezone[122]["utc"]["s"]="+3";

//***

$timezone[123]["country"]["de"]="Seyschellen";

$timezone[123]["utc"]["w"]="+4";

$timezone[123]["utc"]["s"]="+4";

//***

$timezone[124]["country"]["de"]="Simbabwe";

$timezone[124]["utc"]["w"]="+2";

$timezone[124]["utc"]["s"]="+2";

//***

$timezone[125]["country"]["de"]="Singapur";

$timezone[125]["utc"]["w"]="+8";

$timezone[125]["utc"]["s"]="+8";

//***

$timezone[126]["country"]["de"]="Somalia";

$timezone[126]["utc"]["w"]="+3";

$timezone[126]["utc"]["s"]="+3";

//***

$timezone[127]["country"]["de"]="Sri Lanka";

$timezone[127]["utc"]["w"]="+6";

$timezone[127]["utc"]["s"]="+6";

//***

$timezone[128]["country"]["de"]="S�dafrika";

$timezone[128]["utc"]["w"]="+2";

$timezone[128]["utc"]["s"]="+2";

//***

$timezone[129]["country"]["de"]="Sudan";

$timezone[129]["utc"]["w"]="+3";

$timezone[129]["utc"]["s"]="+3";

//***

$timezone[130]["country"]["de"]="Syrien";

$timezone[130]["utc"]["w"]="+2";

$timezone[130]["utc"]["s"]="+3";

//***

$timezone[131]["country"]["de"]="Tadschikistan";

$timezone[131]["utc"]["w"]="+5";

$timezone[131]["utc"]["s"]="+5";

//***

$timezone[132]["country"]["de"]="Tahiti";

$timezone[132]["utc"]["w"]="-10";

$timezone[132]["utc"]["s"]="-10";

//***

$timezone[133]["country"]["de"]="Taiwan";

$timezone[133]["utc"]["w"]="+8";

$timezone[133]["utc"]["s"]="+8";

//***

$timezone[134]["country"]["de"]="Tansania";

$timezone[134]["utc"]["w"]="+3";

$timezone[134]["utc"]["s"]="+3";

//***

$timezone[135]["country"]["de"]="Thailand";

$timezone[135]["utc"]["w"]="+7";

$timezone[135]["utc"]["s"]="+7";

//***

$timezone[136]["country"]["de"]="Tibet";

$timezone[136]["utc"]["w"]="+8";

$timezone[136]["utc"]["s"]="+8";

//***

$timezone[137]["country"]["de"]="Tonga";

$timezone[137]["utc"]["w"]="+13";

$timezone[137]["utc"]["s"]="+13";

//***

$timezone[138]["country"]["de"]="Tschad";

$timezone[138]["utc"]["w"]="+1";

$timezone[138]["utc"]["s"]="+1";

//***

$timezone[139]["country"]["de"]="T�rkei";

$timezone[139]["utc"]["w"]="+2";

$timezone[139]["utc"]["s"]="+3";

//***

$timezone[140]["country"]["de"]="Tunesien";

$timezone[140]["utc"]["w"]="+1";

$timezone[140]["utc"]["s"]="+1";

//***

$timezone[141]["country"]["de"]="Uganda";

$timezone[141]["utc"]["w"]="+3";

$timezone[141]["utc"]["s"]="+3";

//***

$timezone[142]["country"]["de"]="Ukraine";

$timezone[142]["utc"]["w"]="+2";

$timezone[142]["utc"]["s"]="+3";

//***

$timezone[143]["country"]["de"]="Uruguay";

$timezone[143]["utc"]["w"]="-3";

$timezone[143]["utc"]["s"]="-3";

//***

$timezone[144]["country"]["de"]="USA: N. York, Miami";

$timezone[144]["utc"]["w"]="-5";

$timezone[144]["utc"]["s"]="-4";

//***

$timezone[145]["country"]["de"]="USA: Indiana";

$timezone[145]["utc"]["w"]="-5";

$timezone[145]["utc"]["s"]="-5";

//***

$timezone[146]["country"]["de"]="USA: Chicago,Dallas";

$timezone[146]["utc"]["w"]="-6";

$timezone[146]["utc"]["s"]="-5";

//***

$timezone[147]["country"]["de"]="USA: Denver";

$timezone[147]["utc"]["w"]="-7";

$timezone[147]["utc"]["s"]="-6";

//***

$timezone[148]["country"]["de"]="USA: Arizona";

$timezone[148]["utc"]["w"]="-7";

$timezone[148]["utc"]["s"]="-7";

//***

$timezone[149]["country"]["de"]="USA: Los Angeles";

$timezone[149]["utc"]["w"]="-8";

$timezone[149]["utc"]["s"]="-7";

//***

$timezone[150]["country"]["de"]="Usbekistan";

$timezone[150]["utc"]["w"]="+5";

$timezone[150]["utc"]["s"]="+5";

//***

$timezone[151]["country"]["de"]="Venezuela";

$timezone[151]["utc"]["w"]="-4";

$timezone[151]["utc"]["s"]="-4";

//***

$timezone[152]["country"]["de"]="Ver. Arab.Emirate";

$timezone[152]["utc"]["w"]="+4";

$timezone[152]["utc"]["s"]="+4";

//***

$timezone[153]["country"]["de"]="Vietnam";

$timezone[153]["utc"]["w"]="+7";

$timezone[153]["utc"]["s"]="+7";

//***

$timezone[154]["country"]["de"]="Weissrussland";

$timezone[154]["utc"]["w"]="+2";

$timezone[154]["utc"]["s"]="+3";

//***

$timezone[155]["country"]["de"]="Zentralafr. Rep.";

$timezone[155]["utc"]["w"]="+1";

$timezone[155]["utc"]["s"]="+1";

//***

$timezone[156]["country"]["de"]="Zypern";

$timezone[156]["utc"]["w"]="+2";

$timezone[156]["utc"]["s"]="+3";

//***

$timezone[157]["country"]["de"]="Albanien";

$timezone[157]["utc"]["w"]="+1";

$timezone[157]["utc"]["s"]="+2";

//***

$timezone[158]["country"]["de"]="Belgien";

$timezone[158]["utc"]["w"]="+1";

$timezone[158]["utc"]["s"]="+2";

//***

$timezone[159]["country"]["de"]="Bosnien-Herzegowina";

$timezone[159]["utc"]["w"]="+1";

$timezone[159]["utc"]["s"]="+2";

//***

$timezone[160]["country"]["de"]="D�nemark";

$timezone[160]["utc"]["w"]="+1";

$timezone[160]["utc"]["s"]="+2";

//***

$timezone[161]["country"]["de"]="Deutschland";

$timezone[161]["utc"]["w"]="+1";

$timezone[161]["utc"]["s"]="+2";

//***

$timezone[162]["country"]["de"]="Frankreich";

$timezone[162]["utc"]["w"]="+1";

$timezone[162]["utc"]["s"]="+2";

//***

$timezone[163]["country"]["de"]="Italien";

$timezone[163]["utc"]["w"]="+1";

$timezone[163]["utc"]["s"]="+2";

//***

$timezone[164]["country"]["de"]="Jugoslawien";

$timezone[164]["utc"]["w"]="+1";

$timezone[164]["utc"]["s"]="+2";

//***

$timezone[165]["country"]["de"]="Kroatien";

$timezone[165]["utc"]["w"]="+1";

$timezone[165]["utc"]["s"]="+2";

//***

$timezone[166]["country"]["de"]="Luxemburg";

$timezone[166]["utc"]["w"]="+1";

$timezone[166]["utc"]["s"]="+2";

//***

$timezone[167]["country"]["de"]="Malta";

$timezone[167]["utc"]["w"]="+1";

$timezone[167]["utc"]["s"]="+2";

//***

$timezone[168]["country"]["de"]="Mazedonien";

$timezone[168]["utc"]["w"]="+1";

$timezone[168]["utc"]["s"]="+2";

//***

$timezone[169]["country"]["de"]="Monaco";

$timezone[169]["utc"]["w"]="+1";

$timezone[169]["utc"]["s"]="+2";

//***

$timezone[170]["country"]["de"]="Niederlande";

$timezone[170]["utc"]["w"]="+1";

$timezone[170]["utc"]["s"]="+2";

//***

$timezone[171]["country"]["de"]="Norwegen";

$timezone[171]["utc"]["w"]="+1";

$timezone[171]["utc"]["s"]="+2";

//***

$timezone[172]["country"]["de"]="�sterreich";

$timezone[172]["utc"]["w"]="+1";

$timezone[172]["utc"]["s"]="+2";

//***

$timezone[173]["country"]["de"]="Polen";

$timezone[173]["utc"]["w"]="+1";

$timezone[173]["utc"]["s"]="+2";

//***

$timezone[174]["country"]["de"]="Schweden";

$timezone[174]["utc"]["w"]="+1";

$timezone[174]["utc"]["s"]="+2";

//***

$timezone[175]["country"]["de"]="Schweiz";

$timezone[175]["utc"]["w"]="+1";

$timezone[175]["utc"]["s"]="+2";

//***

$timezone[176]["country"]["de"]="Slowakei";

$timezone[176]["utc"]["w"]="+1";

$timezone[176]["utc"]["s"]="+2";

//***

$timezone[177]["country"]["de"]="Slowenien";

$timezone[177]["utc"]["w"]="+1";

$timezone[177]["utc"]["s"]="+2";

//***

$timezone[178]["country"]["de"]="Spanien";

$timezone[178]["utc"]["w"]="+1";

$timezone[178]["utc"]["s"]="+2";

//***

$timezone[179]["country"]["de"]="Tschechische Republik";

$timezone[179]["utc"]["w"]="+1";

$timezone[179]["utc"]["s"]="+2";

//***

$timezone[180]["country"]["de"]="Ungarn";

$timezone[180]["utc"]["w"]="+1";

$timezone[180]["utc"]["s"]="+2";

//***

$timezone[181]["country"]["de"]="Grossbritannien";

$timezone[181]["utc"]["w"]="0";

$timezone[181]["utc"]["s"]="+1";

//***

$timezone[182]["country"]["de"]="Irland";

$timezone[182]["utc"]["w"]="0";

$timezone[182]["utc"]["s"]="+1";

//***

$timezone[183]["country"]["de"]="Kanarische Inseln";

$timezone[183]["utc"]["w"]="0";

$timezone[183]["utc"]["s"]="+1";

//***

$timezone[184]["country"]["de"]="Portugal";

$timezone[184]["utc"]["w"]="0";

$timezone[184]["utc"]["s"]="+1";

/*

	f�r Tippfehler und Schaden bei Gebrauch keine Haftung

*/

?>