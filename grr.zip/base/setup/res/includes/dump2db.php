<?php 
 
//	(o)reinforced 1427 by VCN take2reality@gmx.net || batbox@need4speed.com 
 

 require("./../conf/app_silent.inc.php"); 
require("./../conf/perlmut.conf.php"); 

global $conf;


global $timezonesTable; 
 
global $terransUniteSession;
 
$timezonesTable=$conf["timezones"]; 
 
 
 
$timezonesRegionNamesTable=$conf["timezonesRegionNames"]; 
 
 
 
$ASCE="asce"; 
 
 
 
$DESC="desc"; 
 
 
 
$order=$ASCE; 
 
 
 
$filenameAndPath="TimeZones.inc.php"; 
 
 
 
$countryString="de"; 
 
 
 
$varname="timezone"; 
 
 
 
 
 
include($filenameAndPath); 
 
 
 
 
 
$timez=$$varname; 
 
 
 
 
 
 
 
function isUnusedZoneId($id){ 
 
 global $conf;
 
	global $timezonesTable; 
 
global $terransUniteSession;
 
 
 
 
	$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT * FROM `$timezonesTable` WHERE `zoneId` = '$id';"); 
 
 
 
	if($result){ 
 
 
 
		if($result->num_rows==0){ 
 
 
 
			return true; 
 
 
 
		} 
 
 
 
	} 
 
 
 
		return false; 
 
 
 
} 
 
 
 
	$zid=0; 
 
	$result=${$conf["APP.SESSION.sign"]}->doQuery("TRUNCATE TABLE `$timezonesTable`;"); 
 
	$result=${$conf["APP.SESSION.sign"]}->doQuery("TRUNCATE TABLE `$timezonesRegionNamesTable`;"); 
 
 
for($v=0; $v < sizeof($timez); $v++){ 
 
 
 
	$winter=$timez[$v]["utc"]["w"]; 
 
 
 
	$summer=$timez[$v]["utc"]["s"]; 
 
 
 
	$zid++; 
 
 
 
	while(!isUnusedZoneId($zid)){ 
 
 
 
		$zid++; 
 
 
 
	} 
 
 
 
 
	 
	$result=${$conf["APP.SESSION.sign"]}->doQuery("INSERT INTO `$timezonesTable` (`zoneId`, `summer2utc`, `winter2utc`) VALUES('$zid', '$summer', '$winter');"); 
 
	while(list($cstring, $rname) = each($timez[$v]["country"])){ 
 
 
 
		${$conf["APP.SESSION.sign"]}->doQuery("INSERT INTO `$timezonesRegionNamesTable` (`zoneId`, `countryString`, `regionname`) VALUES('$zid', '$cstring', '$rname');"); 
 
 
 
	}	 
 
 
 
} 
 
 
 
 
 
 
 
$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT * FROM `$timezonesRegionNamesTable`  WHERE ((`countryString`='$countryString') AND (`zoneId` IN (SELECT `zoneId` FROM `$timezonesTable` WHERE 1)));"); 
 
 
 
 
 
 
 
while($as=mysqli_fetch_array($result, MYSQLI_ASSOC)){ 
 
 
 
	echo $as["zoneId"] . "::" . $as["regionname"] . "\n"; 
 
 
 
}