<?php
	global $terransUniteSession, $sid;
	require("./../../../vcnnative/lib/classes/perlmut.classes.php");
	require("./../../../vcnnative/lib/functions/perlmut.functions.php");
	require("./../../conf/perlmut.conf.php");
	require("./../../lang/perlmut.lang.php");
	${$conf["APP.SESSION.sign"]}=new ChatSession($conf, $conf["sidsLength"]);
	$sid=session_initialize(${$conf["APP.SESSION.sign"]});
	echo "<TEXTAREA cols=\"80\" rows=\"21\">";
	require("./dump2db.php");
	echo "</TEXTAREA>";
?>	