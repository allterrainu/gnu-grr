<?php
	error_reporting(E_ERROR);
	ini_set('display_errors', FALSE);
	//error_reporting(E_ALL);
	//ini_set('display_errors', TRUE);
	
	ini_set('session.use_cookies', 0);
	ini_set('session.use_only_cookies', 0);
	ini_set('session.use_trans_sid', 0);
	
	global $worlds;
	global $terransUniteSession;
	global $countryCode, $languageCode;
	
	require("./../conf/db.conf.php");
	require("./../conf/app_silent.inc.php");
	require("./../lang/perlmut.lang.php");
	require("./base/conf/perlmut.conf.php");
	require("./../../vcnnative/lib/functions/perlmut.functions.php");
	require("./../../vcnnative/lib/classes/perlmut.classes.php");
	//forced procedure to make res avail
	include("./../../vcnnative/client/gateway.php");
	include("./../../vcnnative/client/acknowledge.php");
	session_write_close();
	exit();
?>
