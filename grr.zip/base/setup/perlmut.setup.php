<?php

error_reporting(E_ERROR);
ini_set('display_errors', FALSE);
//error_reporting(E_ALL);
//ini_set('display_errors', TRUE); 
/* 
 
	Copyright �2007-2013 Daniel Wiesen�cker 
 
 
 
     
 
    This file is part of AngelTrack. 
 
 
 
    AngelTrack is free software: you can redistribute it and/or modify 
 
    it under the terms of the GNU General Public License as published by 
 
    the Free Software Foundation, either version 3 of the License, or 
 
    (at your option) any later version. 
 
 
 
    AngelTrack is distributed in the hope that it will be useful, 
 
    but WITHOUT ANY WARRANTY; without even the implied warranty of 
 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 
    GNU General Public License for more details. 
 
 
 
    You should have received a copy of the GNU General Public License 
 
    along with AngelTrack. If not, see <http://www.gnu.org/licenses/>. 
*/ 
 
	global $terransUniteSession, $conf, $dbm; 
 
//error_reporting(E_ERROR); 
//ini_set('display_errors', FALSE); 
error_reporting(E_ALL); 
ini_set('display_errors', TRUE); 

	 require("./../conf/app_silent.inc.php"); 
	require("./../conf/db.conf.php"); 
	require("./../lang/perlmut.lang.php"); 
	require("./../conf/perlmut.conf.php"); 
	require("./../../vcnnative/lib/functions/perlmut.functions.php"); 
	require("./../../vcnnative/lib/classes/perlmut.classes.php"); 
?> 
<html> 
<head> 
<title> 
ATShop - v.0.58150.415a - Setup 
</title> 
</head> 
<body style="text-align: left;"> 
<tt>f&uuml;hre Setup aus.<br> Bitte warten</tt> 
<?php 
	$relativeroot=$conf["relativeroot"]; 
 
	$hostname=$conf["hostname"]; 
 
	$sessions=$conf["sessions"]; 
 
	$entropyLength=$conf["sidsLength"]; 
 
	$entropyLengthInherit=$conf["ToHostSidsLength"]; 
 
	//***UNIMPLEMENTED YET cause sid gains primitive wall 
 
 
 
	$sessionsSecurity=$conf["sessionsSecurity"]; 
 
 
 
	//session 
	$stunt_request_invoke=$conf["stunt_request_invoke"]; 
	 
	$security_request_invoke=$conf["security_request_invoke"]; 
 
	$sessionCookies=$conf["sessionCookies"]; 
 
	$sessionVars=$conf["sessionVariables"]; 
 
	$security_hash=$conf["SecSesHash2SID"]; 
 
	$security_stunt=$conf["securityStunt"]; 
 
	$users=$conf["users"]; 
 
	$privileges=$conf["priv"]; 
 
	$logs=$conf["logs"];//WHO NEED THAT 
 
	$counter=$conf["counter"]; 
 
	$worlds=$conf["worlds"]; 
 
	$hosts=$conf["hosts"]; 
 
 //reference
	$tokens=$conf["tokens"];

 
	//auth 
 
	$users=$conf["users"]; 
 
	$auth=$conf["auth"]; 
 
	$backupSplittedRegisters=$conf["splittedBackupTable"];

	$authSessions=$conf["authSessions"]; 
 
	$personal=$conf["personalDataStorage"]; 
 
 
 
	//httpChat 
 
	$stack=$conf["stack"]; 
 
	$objects=$conf["objects"]; 
 
	$nicklist=$conf["nicks"]; 
 
	$conx=$conf["conx"]; HANGAR/
 
	$chatIgnore=$conf["chatIgnore"]; 
 
 
 
	//connect 
 
	$what_dbhost=$dbm["what_dbhost"]; 
 
	$what_dblogin=$dbm["what_dblogin"]; 
 
	$what_dbpwd=$dbm["what_dbpass"]; 
 
	$what_dbname=$dbm["what_dbname"]; 
 
 
 
	//timezones 
 
	$timezonesRegion=$conf["timezonesRegionNames"]; 
 
	$timezones=$conf["timezones"]; 
 
 
 
	//shop 
 
	$stackSync=$conf["productStackSync"]; 
 
	$productProperties=$conf["productProperties"]; 
 
	$propertiesBinding=$conf["propertiesBinding"]; 
 
	$baseVarsTable=$conf["baseVars"]; 
 
	$articleTree=$conf["articleTree"]; 
 
	$imageGallery=$conf["imageGallery"]; 
 
	$shipmentMethods=$conf["shipmentMethods"]; 
 
	$currencies=$conf["currencies"]; 
 
	$vendors=$conf["vendors"]; 
 
	$productCategories=$conf["productCategories"]; 
 
	$deliverCountries=$conf["deliverCountries"]; 
 
	$propertiesDescriptors=$conf["propertiesDescriptor"]; 
 
	$storageLinker=$conf["storageLinker"]; 
 
	$zipCodes=$conf["zipCodes"]; 
 
	$supplies=$conf["supplies"]; 
 
	//shop admin 
	 
	$plannedEvent=$conf["events"]; 
	 
	$actionSales=$conf["actionSales"]; 
 
	$shopAdminLog=$conf["adminlog"];	 
 
	//orders 
 
	$orders=$conf["orders"]; 
 
	$pieces=$conf["pieces"]; 
	 
	$chargens=$conf["chargens"]; 
	 
	$emailSampleContainer=$conf["emailSampleContainer"]; 
	 
	$emailBlockContainer=$conf["emailBlockContainer"]; 
 
	//playmobil 
	 
	$hashtagStore=$conf["f14TOMCAT"]; 
 
 
	//link menu 
	$linkMenu=$conf["linkmenu"]; 
 
 	$sessionStore=$conf["sessionStoreData"];
 
 
 
 
	if(sizeof($_POST)==0){ //wheter step 1 
 
	//<SESSION> 
 
		$a=1; 
 
$sql[$a++]="CREATE TABLE `$tokens` (`tokenId` BIGINT UNSIGNED NOT NULL, `tokenName` VARCHAR(255), `token` TINYTEXT, `url` TINYTEXT, PRIMARY KEY (`tokenId`));";//auto logout is only detected once per username no set on machines where somethings maybe can be found
		
		

		$sql[$a++]="CREATE TABLE `$auth` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `userId` BIGINT UNSIGNED NOT NULL, `passwordMD5` VARCHAR(255), `autoLogout` BIGINT UNSIGNED, PRIMARY KEY (`recordId`));";//auto logout is only detected once per username no set on machines where somethings maybe can be found 
 
		$sql[$a++]="CREATE TABLE `$authSessions` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `sid` VARCHAR(245), `userId` BIGINT UNSIGNED NOT NULL, `sessionCookie2C` CHAR(32), PRIMARY KEY ( `entryId` ));"; 
 
		$sql[$a++]="CREATE TABLE `$users` (`userId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `email` VARCHAR(255), `sinceDate` CHAR(10), `lastLoginDate` CHAR(10), `lastLoginTime` VARCHAR(8), `name` VARCHAR(64), `homedir` VARCHAR(255) NOT NULL, `folderId` BIGINT UNSIGNED, `hostId` BIGINT UNSIGNED, `countryString` CHAR(2), `status` INT, `simultanConx` INT, PRIMARY KEY (`userId`));";//</CHANGE> 
 
		$sql[$a++]="CREATE TABLE `$sessions` (`sid` VARCHAR(245) NOT NULL, `inheritSid` VARCHAR(245) NOT NULL, `hostId` BIGINT UNSIGNED NOT NULL, `date` VARCHAR( 10 ) NOT NULL, `time` VARCHAR( 8 ) NOT NULL, `virtual_cookie` LONGTEXT, `check` INT, PRIMARY KEY ( `sid` ));"; 
 
		$sql[$a++]="CREATE TABLE `$sessionCookies` (`sessionCookie2C` CHAR(32) NOT NULL, `sid` VARCHAR(245), `userId` BIGINT UNSIGNED NOT NULL, `rememberLogin` SMALLINT NOT NULL, PRIMARY KEY ( `sessionCookie2C` ));"; 
 

		$sql[$a++]="CREATE Table `$backupSplittedRegisters` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `parentEntryId` BIGINT UNSIGNED, `sessionCookie2C` CHAR(32), `systemToken` VARCHAR(255) NOT NULL, `saveHandlerDump` LONGTEXT, `reregisterVarsList` TINYTEXT NOT NULL, PRIMARY KEY(`entryId`));";

		$sql[$a++]="CREATE Table `$sessionStore` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `parentEntryId` BIGINT UNSIGNED, `sessionCookie2C` CHAR(32), `systemToken` VARCHAR(255) NOT NULL, `key` VARCHAR(1024) NOT NULL, `virtual_cookie` LONGTEXT, `timestamp` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`entryId`));";

		$sql[$a++]="CREATE TABLE `$sessionVars` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `entryId` VARCHAR(255) NOT NULL, `value` LONGTEXT NOT NULL, `path` TINYTEXT NOT NULL, `open` BOOLEAN, `sessionName` VARCHAR(255), `createTime` BIGINT UNSIGNED NOT NULL, `sessionCookie2C` CHAR(32) NOT NULL, PRIMARY KEY ( `recordId` ));"; 
 
		$sql[$a++]="CREATE TABLE `$hosts` (`hostIndex` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `hostName` VARCHAR(67), `indexurl` VARCHAR(255), PRIMARY KEY( `hostIndex` ));"; 
 
		$sql[$a++]="CREATE TABLE `$privileges` (`index` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `userId` BIGINT UNSIGNED NOT NULL, `privilegeName` VARCHAR(32) NOT NULL, `privilegeStatus` SMALLINT, PRIMARY KEY (`index`));"; 
 
		$sql[$a++]="CREATE Table `$security_stunt` (`passThroughId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `fileName` VARCHAR(255) NOT NULL, `path` TINYTEXT NOT NULL, `header` VARCHAR(64) NOT NULL, `deliveryStunt` LONGTEXT NOT NULL, `ph` BOOLEAN NOT NULL, PRIMARY KEY(`passThroughId`));"; 
 
		$sql[$a++]="CREATE Table `$stunt_request_invoke` (`StuntInvokeId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `passThroughId` BIGINT UNSIGNED NOT NULL, `REQUEST_INI` VARCHAR(255), PRIMARY KEY(`StuntInvokeId`));"; 
		 
		$sql[$a++]="CREATE Table `$security_request_invoke` (`SecurityInvokeId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `StuntInvokeId` BIGINT UNSIGNED NOT NULL, `ABLETOKEN` VARCHAR(255), `ATTEMPS` BIGINT UNSIGNED NOT NULL, `MAX_ATTEMPS` BIGINT UNSIGNED NOT NULL, `BLOCKED` BOOLEAN NOT NULL, PRIMARY KEY(`SecurityInvokeId`));"; 
		 
		$sql[$a++]="CREATE Table `$security_hash` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `sid` VARCHAR(245) NOT NULL, `passThroughId` BIGINT UNSIGNED NOT NULL, `tmpFileName` VARCHAR(255), `tmpFilePath` VARCHAR(255) NOT NULL, PRIMARY KEY(`recordId`));"; 
 
		$sql[$a++]="CREATE TABLE `$sessionsSecurity` (`entryId` BIGINT UNSIGNED NOT NULL, `ipAdressV4` VARCHAR(15), `sid` VARCHAR(254) NOT NULL, `loginAttemps` BIGINT UNSIGNED NOT NULL, `failedLoginHistory` LONGTEXT, `blocked` BOOLEAN NOT NULL, `blockSinceDate` VARCHAR(10), `blockSinceTime` VARCHAR(8), `timestamp` VARCHAR(255), `passwordRemailerActive` BOOLEAN, PRIMARY KEY(`entryId`));";  
	 
 
	//<SESSION> 
 
	 
 
	//<HTTPCHAT> 
 
		//$sql[$a++]="CREATE TABLE `$requests`(`requestId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `requestorUserId` BIGINT UNSIGNED NOT NULL, `targetUserId` BIGINT UNSIGNED NOT NULL, `worldId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY (`requestId`) );"; 
 
		$sql[$a++]="CREATE TABLE `$worlds` (`worldId` BIGINT NOT NULL AUTO_INCREMENT, `hostId` BIGINT UNSIGNED NOT NULL, `name` VARCHAR(255), `maxParteners` BIGINT NOT NULL, `description` LONGTEXT, `welcomeMessage` VARCHAR(255), PRIMARY KEY (`worldId`) );"; 
 
		$sql[$a++]="CREATE TABLE `$nicklist` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `nickname` VARCHAR(32) NOT NULL, `userId` BIGINT UNSIGNED NOT NULL, `greeting` TINYTEXT, `color` CHAR(6), `lastKiss` VARCHAR(32), `lastWorld` VARCHAR(32), PRIMARY KEY(`entryId`));"; 
 
		$sql[$a++]="CREATE TABLE `$stack` (`id` BIGINT NOT NULL AUTO_INCREMENT, `sid` VARCHAR(245) NOT NULL, `fromInvokeId` TINYTEXT NOT NULL, `objectId` CHAR(32) NOT NULL, `wid` VARCHAR(32) NOT NULL, `iterator` VARCHAR(255) NOT NULL, `toInvokeId` TINYTEXT NOT NULL, `flag` INT NOT NULL, `type` VARCHAR(6), PRIMARY KEY ( `id` ) );"; 
 
		$sql[$a++]="CREATE TABLE `$objects` (`objectId` CHAR(32) NOT NULL, `messageText` TINYTEXT, `messageStyle` TINYTEXT, `fileDelivery` BOOL NOT NULL, `fileUrl` VARCHAR(255), PRIMARY KEY(`objectId`));"; 
 
		//$sql[$a++]="CREATE TABLE `$history` (`entryId` BIGINT UNSIGNED NOT NULL, `formatedEvent` TINYTEXT, `userId1` BIGINT UNSIGNED NOT NULL, `userId2` BIGINT UNSIGNED NOT NULL, PRIMARY KEY (`entryId`));"; 
 
		$sql[$a++]="CREATE TABLE `$conx` (`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `invokeId` TINYTEXT NOT NULL, `sid` VARCHAR(245) NOT NULL, `wid` CHAR(32) NOT NULL, `nickId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`id`));"; 
 
		//$sql[$a++]="CREATE TABLE `$buddies` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `userId` BIGINT UNSIGNED NOT NULL, `buddyId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`entryId`));"; 
 
		/*remmeber mode 2 sessions once per active room inr relation to Login Gates*/ 
 
		$sql[$a++]="CREATE TABLE `$chatIgnore` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `worldId` BIGINT UNSIGNED NOT NULL, `invokeId` TINYTEXT NOT NULL, `wantedInvokeId` TINYTEXT NOT NULL, PRIMARY KEY (`entryId`));"; 
 
	//</HTTPCHAT> 
 
 
 
	//<SITE STATS> !!!! be aware of 
 
		$sql[$a++]="CREATE TABLE `$counter` (`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,`hostId` BIGINT UNSIGNED, `date` VARCHAR( 10 ) NOT NULL, `sid` VARCHAR(245) NOT NULL, `ip` CHAR(15), PRIMARY KEY ( `id` ) );"; 
 
		$sql[$a++]="CREATE Table `$logs` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `sid` VARCHAR(245), `ontime` VARCHAR(8), `offtime` VARCHAR(8), `date` VARCHAR(10), `remote_host` VARCHAR(255), `locationHistory` TINYTEXT NOT NULL, `userAgent` TINYTEXT, PRIMARY KEY (`recordId`) );"; 
 
	//</SITE STATS> 
 
 
 
		$sql[$a++]="CREATE Table `$timezonesRegion` (`entryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `zoneId` BIGINT UNSIGNED NOT NULL, `countryString` CHAR(2) NOT NULL, `regionname` VARCHAR(255) NOT NULL, PRIMARY KEY (`entryId`) );"; 
 
		$sql[$a++]="CREATE Table `$timezones` (`zoneId` BIGINT UNSIGNED NOT NULL, `winter2utc` DOUBLE NOT NULL, `summer2utc` DOUBLE NOT NULL,PRIMARY KEY (`zoneId`) );"; 
 
 
 
	//<PERSONAL_DATA_STORAGE> 
 
		$sql[$a++]="CREATE Table `$personal` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `uid` BIGINT UNSIGNED NOT NULL, `caption` VARCHAR(255), `value` TINYTEXT, PRIMARY KEY (`recordId`) );"; 
 
	//</PERSONAL_DATA_STORAGE> 
 
 
 
	//<ANGEL_TRACK_SHOP> 
 
		$sql[$a++]="CREATE Table `$stackSync` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `articleId` BIGINT UNSIGNED, `numberAvailable` BIGINT UNSIGNED NOT NULL, `dateSync` VARCHAR(10), `timeSync` VARCHAR(8), `userIdSync` BIGINT UNSIGNED NOT NULL, `numberSold` BIGINT UNSIGNED, `offerEndsDate` VARCHAR(10), `offerEndsTime` VARCHAR(8), `offerPlanDate` VARCHAR(10), `offerPlanTime` VARCHAR(8), `ebay_category1` TINYTEXT NOT NULL, `ebay_category2` TINYTEXT, `ebay_fee` DOUBLE, `ebay_fee_currencyId` BIGINT UNSIGNED, PRIMARY KEY(`recordId`));";  
 
		$sql[$a++]="CREATE Table `$baseVarsTable` (`varId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `parentVarId` BIGINT UNSIGNED, `varname` VARCHAR(255) NOT NULL, `value` TINYTEXT, `datatype` VARCHAR(32) NOT NULL, `unity` VARCHAR(255) NOT NULL, `caption` TINYTEXT NOT NULL, `description` TINYTEXT, PRIMARY KEY(`varId`));";  
 
		$sql[$a++]="CREATE Table `$articleTree` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `articleIdent` VARCHAR(255) NOT NULL, `parentRecordId` BIGINT UNSIGNED, `SKU` VARCHAR(254),  `UPC` VARCHAR(254), `EAN` VARCHAR(254), `GTIN` VARCHAR(254), `APN` VARCHAR(254), `vendorId` BIGINT UNSIGNED NOT NULL, `productCategoryId` BIGINT UNSIGNED NOT NULL, `caption` TINYTEXT NOT NULL, `description` TINYTEXT, `blockNr` DOUBLE NOT NULL, `detailPageURL` TINYTEXT NOT NULL, `imageURL` TINYTEXT NOT NULL, `detailImageURL` TINYTEXT NOT NULL, `price` DOUBLE NOT NULL, `enabled` BOOLEAN NOT NULL, `eventId` BIGINT UNSIGNED NOT NULL, `currencyId` BIGINT UNSIGNED NOT NULL, `sessionStore` VARCHAR(5), PRIMARY KEY(`recordId`));";  
		 
		//>>sessionStore<<  
		//SETED TO <<WAIT0>> wheter not enabled during session 
		//SETED TO <<STOP0>> wheter not enabled during session and retry to WAIT0 
		//SETED TO <<WAIT1>> wheter not enabled during session and will be planned enabled to event 
		//SETED TO <<STOP1>> wheter not enabled during session and will be stoped (disabled) to event 
		//SETED TO <<STACK>> wheter not enabled but may be requested seperatly 
		//SETED TO <<TRAIL>> wheter enabled and won't be refreshed to stock 
			 
 
		$sql[$a++]="CREATE Table `$imageGallery` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `articleId` BIGINT UNSIGNED NOT NULL, `path` TINYTEXT NOT NULL, `completeFilename` TINYTEXT NOT NULL, `suffix` VARCHAR(4), `stackOrder`  INT UNSIGNED NOT NULL, `width` INT UNSIGNED NOT NULL, `height` INT UNSIGNED NOT NULL, `title` TINYTEXT NOT NULL, PRIMARY KEY(`recordId`));";  
 
		$sql[$a++]="CREATE Table `$productCategories` (`categoryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `parentId` BIGINT UNSIGNED NOT NULL, `name` VARCHAR(255) NOT NULL, `blockNr` DOUBLE NOT NULL, `collapsedIconViewURL` TINYTEXT, `expandedIconViewURL` TINYTEXT, PRIMARY KEY(`categoryId`));";  
 
		$sql[$a++]="CREATE Table `$currencies` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `nameOfCurrency` VARCHAR(64) NOT NULL, `characterExpression` VARCHAR(16) NOT NULL, `toShopCurrencyCalculationFactor` DOUBLE NOT NULL, PRIMARY KEY(`recordId`));"; 
 
		$sql[$a++]="CREATE Table `$shipmentMethods` (`shipmentMethodId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `deliveryCompany` VARCHAR(64) NOT NULL, `serviceName` VARCHAR(32) NOT NULL, `amountCharge` DOUBLE NOT NULL, `currencyId` BIGINT UNSIGNED NOT NULL, `countryId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`shipmentMethodId`));"; 
 
		$sql[$a++]="CREATE Table `$vendors` (`vendorId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `vendorName` VARCHAR(64) NOT NULL, `blockNr` DOUBLE, PRIMARY KEY(`vendorId`));"; 
 
		$sql[$a++]="CREATE Table `$deliverCountries` (`countryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `countryName` VARCHAR(255) NOT NULL, `currencyId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`countryId`));"; 
 
		$sql[$a++]="CREATE Table `$zipCodes` (`index` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `cityname` VARCHAR(255) NOT NULL, `zipcode` VARCHAR(10) NOT NULL, `countryId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`index`));"; 
 
		 
 
		 
 
		$sql[$a++]="INSERT INTO `$currencies` (`nameOfCurrency`, `characterExpression`, `toShopCurrencyCalculationFactor`) VALUES('Euro','&#8364;','1');"; //where factor is '1' std currency is set to e.G.: at this point Euro is standard-currency 
 
		$sql[$a++]="INSERT INTO `$currencies` (`nameOfCurrency`, `characterExpression`, `toShopCurrencyCalculationFactor`) VALUES('Dollar','&#36;','0.758782912');"; 
 
		 
 
		 
 
		//logging	 
 
		$sql[$a++]="CREATE TABLE `$shopAdminLog` (`logId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `date` VARCHAR(10), `time` VARCHAR(8), `entryCode` VARCHAR(64), `userId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`logId`));"; 
 
		// 
 
		$sql[$a++]="CREATE TABLE `$orders` (`orderId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `orderNumber` BIGINT UNSIGNED NOT NULL, `date` VARCHAR(10) NOT NULL, `userId` VARCHAR(16) NOT NULL , `shipmentId` BIGINT UNSIGNED NOT NULL, `currencyId` BIGINT UNSIGNED NOT NULL, `status` VARCHAR(16) NOT NULL , `acknowledged` BOOLEAN NOT NULL, `paid` BOOLEAN NOT NULL, `shiped` BOOLEAN NOT NULL, `uniqeStamp` VARCHAR(255) NOT NULL, PRIMARY KEY ( `orderId` ) );"; 
 
		 
		$sql[$a++]="CREATE TABLE `$chargens` (`chargenNr` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `vendorId` BIGINT UNSIGNED NOT NULL , `supplierId` BIGINT UNSIGNED, `articleId` BIGINT UNSIGNED NOT NULL, `propertyBindingRecordId` BIGINT UNSIGNED NOT NULL, `numberOf` BIGINT UNSIGNED NOT NULL, PRIMARY KEY ( `chargenNr` ) );"; 
		 
		$sql[$a++]="CREATE TABLE `$pieces` (`pieceId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `articleRecordId` BIGINT UNSIGNED NOT NULL, `orderId` BIGINT UNSIGNED NOT NULL, `chargenNr` BIGINT UNSIGNED NOT NULL, `amountPerPiece` DOUBLE NOT NULL, `currencyId` BIGINT NOT NULL, `taxInPercent` DOUBLE NOT NULL, `totalAmount` DOUBLE NOT NULL, `inStockAvailable` BOOLEAN NOT NULL, `allocated` BOOLEAN NOT NULL, PRIMARY KEY ( `pieceId` ) );"; 
 
		$sql[$a++]="CREATE TABLE `$storageLinker` (`storageId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `piecesInStorage` INT UNSIGNED NOT NULL, `piecesInCommision` INT UNSIGNED NOT NULL, `piecesInDelivery` INT UNSIGNED NOT NULL, `minimalStorage` INT UNSIGNED NOT NULL, `ordered` BOOLEAN, `dissorted` BOOLEAN, `storageOrderNr` VARCHAR(255), PRIMARY KEY ( `storageId` ) );"; 
 
		$sql[$a++]="CREATE Table `$productProperties` (`propertyId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `descriptorId` BIGINT UNSIGNED NOT NULL, `value` TINYTEXT, `blockNr` DOUBLE NOT NULL, PRIMARY KEY(`propertyId`));";  
 
		$sql[$a++]="CREATE Table `$plannedEvent` (`eventId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `descriptorId` BIGINT UNSIGNED NOT NULL, `fromDate` VARCHAR(10), `toDate` VARCHAR(10), `fromTime` VARCHAR(8), `toTime` VARCHAR(8), `dayTimeStart` VARCHAR(8), `dayTimeEnd` VARCHAR(8), PRIMARY KEY(`eventId`));";  
 
		$sql[$a++]="CREATE Table `$actionSales` (`saleId` BIGINT UNSIGNED NOT NULL, `eventId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `articleId` BIGINT UNSIGNED NOT NULL, `actionPrice` BOOLEAN NOT NULL, `percentageOff` BOOLEAN NOT NULL, `bundleSale` BOOLEAN NOT NULL, `plusPieces` BOOLEAN NOT NULL, `price` DOUBLE, `currencyId` BIGINT UNSIGNED NOT NULL, `percentOff` DOUBLE, `bundleArticleId` BIGINT UNSIGNED, `actionPlusPieces` BIGINT UNSIGNED, PRIMARY KEY(`eventId`));";  
 
		 
		$sql[$a++]="CREATE Table `$propertiesBinding` (`recordId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `articleIdent` VARCHAR(255) NOT NULL, `articleRecordId` BIGINT UNSIGNED NOT NULL, `nextRecordId` BIGINT UNSIGNED, PRIMARY KEY(`recordId`));";  
 
		$sql[$a++]="CREATE TABLE `$propertiesDescriptors` (`descriptorId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `propertyName` VARCHAR(255) NOT NULL, `propertyId` BIGINT UNSIGNED NOT NULL, `datatype` VARCHAR(32) NOT NULL, `unity` VARCHAR(255) NOT NULL, `caption` TINYTEXT NOT NULL, `blockNr` DOUBLE NOT NULL, `description` TINYTEXT, PRIMARY KEY (`descriptorId`));"; 
 
		$sql[$a++]="CREATE TABLE `$emailBlockContainer` (`blockContainerId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `itSelfPlaceholder` VARCHAR(255), `locales_tokenname` VARCHAR(255), `locals` TINYTEXT, `blockNr` DOUBLE, `ADDRESS` VARCHAR(4096), `preset` BOOLEAN NOT NULL, `contentWithReplaceVars` LONGTEXT, `varVarReplaceVarsList` LONGTEXT, PRIMARY KEY (`blockContainerId`));"; 
 
		$sql[$a++]="CREATE TABLE `$emailSampleContainer` (`sampleContainerId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT , `contentWithContainerPlaceHolders` LONGTEXT, `progressLaneAndServiceLocales` LONGTEXT, `blockNr` DOUBLE, PRIMARY KEY (`sampleContainerId`));"; 
 
		$sql[$a++]="CREATE Table `$supplies` (`supplierId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `orderPageUrl` TINYTEXT, `mobilePhoneNr` VARCHAR(254), `gridPhoneNr` VARCHAR(254), `faxNr` VARCHAR(254), `countryId` BIGINT UNSIGNED, `ownCustomberNr` VARCHAR(254), `identKeyData` LONGTEXT, `averageDeliveryTimeInHours` SMALLINT UNSIGNED, `locationPostalAddress` TINYTEXT, `returnShipmentInfoBusiness` LONGTEXT, `deliveryInfosQuota` LONGTEXT, PRIMARY KEY(`supplierId`));"; 
 
		 
		 
	//</ANGEL_TRACK_SHOP> 
 
		$sql[$a++]="CREATE TABLE `$hashtagStore` (`estimatedId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `hashtag` TINYTEXT, `date` VARCHAR(255), PRIMARY KEY (`estimatedId`));"; 
 
		 
	//<LINK_MENU> 
		$sql[$a++]="CREATE TABLE `$linkMenu` (`menuEntryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `parentMenuEntryId` BIGINT UNSIGNED, `passThroughId` BIGINT UNSIGNED, `href` TINYTEXT, `title` VARCHAR(255) NOT NULL, `siteTitle` VARCHAR(255) NOT NULL, `linkDescription` TINYTEXT, `icon_suffix` VARCHAR(4) NOT NULL, `icon` BLOB, `cssClassName` VARCHAR(255), `additionalStyleSheet` TINYTEXT, `robot` TINYTEXT, `keywords` TINYTEXT, `desc` TINYTEXT, PRIMARY KEY (`menuEntryId`));"; 
 
	//</LINK_MENU> 
		 
 
 
	//</SET UP VARS FOR TAX SENTENCES> 
 
		 
 
		 
 
	//</SET UP VARS> 
 
 
 
		$sql[$a++]="TRUNCATE TABLE `$baseVarsTable`;"; 
 
	 
 
		$sql[$a++]="INSERT INTO `$baseVarsTable` (`varId`, `parentVarId`, `varname`, `value`, `datatype`, `unity`, `caption`, `description`) VALUES(1, NULL, '" . $baseVars[0]["varname"] . "', '" . $baseVars[0]["value"] . "', '" . $baseVars[0]["datatype"] . "', '" . $baseVars[0]["unity"] . "', '" . $baseVars[0]["caption"] . "', '" . $baseVars[0]["description"] . "');"; 
 
 
 
		for($t=0; $t < sizeof($baseVars); $t++){ 
 
			$sql[$a++]="INSERT INTO `$baseVarsTable` (`parentVarId`, `varname`, `value`, `datatype`, `unity`, `caption`, `description`) VALUES(1, '" . $baseVars[$t]["varname"] . "', '" . $baseVars[$t]["value"] . "', '" . $baseVars[$t]["datatype"] . "', '" . $baseVars[$t]["unity"] . "', '" . $baseVars[$t]["caption"] . "', '" . $baseVars[$t]["description"] . "');"; 
 
		} 
 
	//</SET UP VARS> 
	 
 
 
		 
 
	$sql[$a++]="SELECT * FROM `perlmut_authenticated_sessions`;"; 
 
 
$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname); 
 
if ($what_db->connect_error) { 
    die('Connect Error (' . $what_db->connect_errno . ') ' 
            . $what_db->connect_error); 
}else $error=false; 
 
 
 
  	for($i=1; $i <= sizeof($sql)/*&&!$error*/; $i++){ 
 
 
 
		$result=mysqli_query($what_db, $sql[$i]); 
 
 
 
		if(!$result){ 
 
 
 
			echo "<br>" . $i . ": \"" . $sql[$i] . "\"<br>"; 
 
			echo mysqli_error($what_db); 
 
			$error=true; 
 
 
 
		} 
 
 
 
	} 
 
 
 
		mysqli_close($what_db); 
 
 
 
		?> 
 
 
 
		<FORM name="wayn3" action="perlmut.setup.php"> 
 
 
 
			<INPUT type="hidden" name="step" value="4"> 
 
 
 
		</FORM> 
 
 
 
		<?php 
 
 
 
		if($error){ 
 
 
 
			echo "<p>Fehler (siehe oben) aufgetreten!!!</p>"; 
 
 
 
			?> 
 
 
 
				<FORM name="wayn" method="POST" action="perlmut.setup.php"> 
 
 
 
				<INPUT type="hidden" name="step" value="9"> 
 
 
 
				<INPUT type="submit" value="beenden"> 
 
 
 
				</FORM> 
 
 
 
				<FORM name="wayn" method="POST" action="perlmut.setup.php"> 
 
 
 
					<INPUT type="hidden" name="step" value="2"> 
 
 
 
					<INPUT type="submit" value="&uuml;bergehen"> 
 
 
 
				</FORM> 
 
 
 
			<?php 
 
 
 
		} 
 
 
 
		else{ 
 
 
 
			echo "<p>ready.</p>"; 
 
 
 
		?> 
 
 
 
			<FORM name="wayn" method="POST" action="perlmut.setup.php"> 
 
 
 
			<INPUT type="hidden" name="step" value="2"> 
 
 
 
			<INPUT type="submit" value="weiter"> 
 
 
 
			</FORM> 
 
 
 
		<?php 
 
 
 
		} 
 
 
 
	}else 
 
 
 
	if($_POST["step"]=="2"){ 
 
 
 
		 
 
 
		echo "<br>"; 
 
		 
		${$conf["APP.SESSION.sign"]} = new ChatSession($conf, $dbm); //creates host automatically 
 
		session_initialize(${$conf["APP.SESSION.sign"]}); 
		 
		?> 
		<TT>Zeitzonen werden importiert:</TT> 
		<TEXTAREA cols="80" rows="10"> 
<?php require("./../res/includes/dump2db.php"); ?> 
		</TEXTAREA> 
		<?php 
		echo "<br>$hostname wurde erfolgreich erstellt. "; 
 
 
 
		echo $lang["errors"][${$conf["APP.SESSION.sign"]}->establishWorld($conf["logonRoom"], "", "", -1, false)]["msg"][${$conf["APP.SESSION.sign"]}->lang]; 
 
 
 
		echo "<br>Setup beendet. Superusername:'$what_dblogin'"; 
 
 ?>
 
		<P><A target="_self" href="./presents.php"><INPUT type="button" name="logon" style="color: #000000; " value="superUser login" title=" als Superuser anmelden "></A></P><P><A target="_self" href="./importZipCodes.php"><INPUT type="button" name="zipcodes" style="color: #000000; " value="import zip-codes" title=" Postleitzahlen importieren "></A></P>
		
		<?php
 
 
		echo "<p>ready.</p>"; 
 
 
 
		 
 
		echo "<TT>" . getBaseVar("tax1", "caption", getBaseVar("taxDeclarations", "varId", false)) .  ": ". getBaseVar("tax1", "value", getBaseVar("taxDeclarations", "varId", false)) . " " . getBaseVar("tax1", "unity", getBaseVar("taxDeclarations", "varId", false)) . " " . getBaseVar("tax1", "description", getBaseVar("taxDeclarations", "varId", false)) .   "</TT><BR>"; //gets global tax 
 
		echo "<TT>" . getBaseVar("tax1", "caption", getBaseVar("taxDeclarations", "varId", false)) .  ": ". getBaseVar("tax2", "value", getBaseVar("taxDeclarations", "varId", false)). " " . getBaseVar("tax1", "unity", getBaseVar("taxDeclarations", "varId", false)) . " " . getBaseVar("tax2", "description", getBaseVar("taxDeclarations", "varId", false)) .   "</TT><BR>";  //gets minor tax 
 
	}else 
 
	if($_POST["step"]=="9"){ 
 
		?> 
		Setup mit Fehlern beendet. 
		<?php 
	} 
 
?> 
</body> 
</html>
