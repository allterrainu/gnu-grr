<?php
	require("./vcnnative/client/head.php");
	require("./lib/app/assemble_lead.php");
	require("./vcnnative/client/hashtag_submit.php");
	require("./lib/app/icons.php");
?>