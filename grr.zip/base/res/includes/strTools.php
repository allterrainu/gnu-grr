<?php
function str_db_declare($todbstr){
	$todbstr=str_ireplace("$", "#DOL#", $todbstr);
	$todbstr=str_ireplace("\\\\\\\"", "#BOUNDEDESCAPEDQUOTE#", $todbstr);
	$todbstr=str_ireplace("\\\"", "#ESCAPEDQUOTE#", $todbstr);
	$todbstr=str_ireplace("\"", "#QUOTE#", $todbstr);
	$todbstr=str_ireplace("\'", "#ESCAPEDSINGLEQUOTE#", $todbstr);
	$todbstr=str_ireplace("'", "#SINGLEQUOTE#", $todbstr);
	$todbstr=str_ireplace(";", "#SEMICOLON#", $todbstr);
	return $todbstr;
}

function str_db_redeclare($fromdbstr){
	$fromdbstr=str_ireplace("#DOL#", "$", $fromdbstr);
	$fromdbstr=str_ireplace("#ESCAPEDSINGLEQUOTE#", "\'", $fromdbstr);
	$fromdbstr=str_ireplace("#SINGLEQUOTE#", "'",  $fromdbstr);
	$fromdbstr=str_ireplace("#ESCAPEDQUOTE#", "\\\"", $fromdbstr);
	$fromdbstr=str_ireplace("#SEMICOLON#", ";", $fromdbstr);
	$fromdbstr=str_ireplace("#QUOTE#", "\"", $fromdbstr);
	return $fromdbstr;
}
?>