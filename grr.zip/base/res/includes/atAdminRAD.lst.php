<?php
$Admin_RAD_Menu_Prefs["menuWidth"]=300;
$Admin_RAD_Menu_Prefs["itemHeight"]=18;
$Admin_RAD_Menu_Prefs["border"]=1;
$Admin_RAD_Menu_Prefs["top"]=8;
$Admin_RAD_Menu_Prefs["left"]=0;
$Admin_RAD_Menu_Prefs["speed"]=2;


//main
$Admin_RAD_Menu[0][0]["caption"]=$lang["menu"]["main_actions"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[0][0]["link_href"]="./req.php?tsa=actions.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[0][0]["link_target"]="tool";
//subs
$Admin_RAD_Menu[0][1]["caption"]=$lang["menu"]["transmition"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[0][1]["link_href"]="./req.php?tsa=transmit.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[0][1]["link_target"]="tool";
$Admin_RAD_Menu[0][2]["caption"]=$lang["menu"]["orders"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[0][2]["link_href"]="./req.php?tsa=orders.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[0][2]["link_target"]="tool";
$Admin_RAD_Menu[0][3]["caption"]=$lang["menu"]["bills"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[0][3]["link_href"]="./req.php?tsa=bills.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[0][3]["link_target"]="tool";


//main
$Admin_RAD_Menu[1][0]["caption"]=$lang["menu"]["main_catalog"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[1][0]["link_href"]="./req.php?tsa=actions.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[1][0]["link_target"]="tool";
//subs
$Admin_RAD_Menu[1][1]["caption"]=$lang["menu"]["categories"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[1][1]["link_href"]="./req.php?tsa=categories.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[1][1]["link_target"]="tool";
$Admin_RAD_Menu[1][2]["caption"]=$lang["menu"]["sortiment"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[1][2]["link_href"]="./req.php?tsa=sortiment.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[1][2]["link_target"]="tool";
$Admin_RAD_Menu[1][3]["caption"]=$lang["menu"]["vendorList"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[1][3]["link_href"]="./req.php?tsa=vendors.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[1][3]["link_target"]="tool";


//main
$Admin_RAD_Menu[2][0]["caption"]=$lang["menu"]["main_session"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[2][0]["link_href"]="./req.php?tsa=sessionManager.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[2][0]["link_target"]="tool";
//subs
$Admin_RAD_Menu[2][1]["caption"]=$lang["menu"]["userManagement"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[2][1]["link_href"]="./req.php?tsa=userMM.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[2][1]["link_target"]="tool";
$Admin_RAD_Menu[2][2]["caption"]=$lang["menu"]["logViewer"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[2][2]["link_href"]="./req.php?tsa=viewLog.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[2][2]["link_target"]="tool";
$Admin_RAD_Menu[2][3]["caption"]=$lang["menu"]["event"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[2][3]["link_href"]="./req.php?tsa=events.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[2][3]["link_target"]="tool";


//main
$Admin_RAD_Menu[3][0]["caption"]=$lang["menu"]["main_preferences"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[3][0]["link_href"]="./req.php?tsa=preferences.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[3][0]["link_target"]="tool";
//subs
$Admin_RAD_Menu[3][1]["caption"]=$lang["menu"]["currencies"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[3][1]["link_href"]="./req.php?tsa=currencies.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[3][1]["link_target"]="tool";
$Admin_RAD_Menu[3][2]["caption"]=$lang["menu"]["layout"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[3][2]["link_href"]="./req.php?tsa=customizr.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[3][2]["link_target"]="tool";
$Admin_RAD_Menu[3][3]["caption"]=$lang["menu"]["shipment"]["caption"][$terransUniteSession->lang];
$Admin_RAD_Menu[3][3]["link_href"]="./req.php?tsa=shipment.php&amp;dsc=.&amp;like=department";
$Admin_RAD_Menu[3][3]["link_target"]="tool";
?>