<?php

$date = getDate();
	

function getMillis(){
	$d=microtime();
	$atok=strtok($d, ".");
	$atok=strtok(".");
	$btok=strtok($d, " ");
	$btok=strtok(" ");
	$atok=substr($atok, 0 ,3);
	$e = $btok . $atok;
	return $e;
}
header('Content-Type: text/xml');
	
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
echo "\t<RESULT>\n";
echo "\t\t<SERVERMILLIS>\n";
echo "\t\t\t\t" . getMillis() . "\n";
echo "\t\t</SERVERMILLIS>\n";
echo "\t\t<CLIENTMILLIS>\n";
echo "\t\t\t\t" . $_GET["timeStamp"] . "\n";
echo "\t\t</CLIENTMILLIS>\n";
echo "\t\t<HOUR>\n";
echo "\t\t\t\t" . $date["hours"] . "\n";
echo "\t\t</HOUR>\n";
echo "\t\t" . "<MINUTE>\n";
echo "\t\t\t\t" . $date["minutes"] . "\n";
echo "\t\t" . "</MINUTE>\n";
echo "\t\t<SECOND>\n";
echo "\t\t\t\t" . $date["seconds"] . "\n";
echo "\t\t</SECOND>\n";
echo "\t</RESULT>";
?>