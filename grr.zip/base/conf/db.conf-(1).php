<?php

	function strcount($str, $needle1, $delimiter){
		$delimiter=$delimiter?$delimiter:"";
		$f=strlen($delimiter)==0?1:0;
		$w=0;
		$count=0;
		$str=$str . $delimiter;
		while($w<strlen($str)){
			if(($w+strlen($needle1))<=strlen($str)){
				$d=(substr($str, $w, strlen($needle1)));
				$d="" . $delimiter . $d;
				$e=strpos($d, $needle1);
				/*
				Zend Engine Yes
				*/
					if($f==1) $e++;
				/*
				Gecko No
				*/
				if(($f==1?$e==1:$e!=0)){//so far
					$count++;
					$w+=($e)-(strlen($delimiter)+$f-1)+(strlen($needle1)-1);
				}else{
					$w++;
				}
			}else $w++;
		}
		return $count;
	}

	$dbm["what_dbname"]="persistant";					//ask ur provider
	$dbm["what_dbhost"]="localhost";				//ask ur provider
	$dbm["what_dblogin"]="persistant";					//ask ur provider
	$dbm["what_dbpass"]="q-7jY2YdO1SW@mkX";			//ask ur provider *Gfxd84pGsGF8fUMR*
?>