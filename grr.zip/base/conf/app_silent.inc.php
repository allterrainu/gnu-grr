<?php
	$conf["APP.SESSION.sign"]="terransUniteSession";
	$conf["APP.VARS.main"]="appWindow_";
	$conf["APP.VARS.index"]="_sys_";
	$conf["APP.VARS.register"]="_ID";
	$d=0;
	$conf["APP.VARS.cookies"][$d++]="__cfduid";
	$conf["APP.VARS.cookies"][$d++]="__cflb";
	$conf["APP.VARS.cookies"][$d++]="__cf_bm";
	$conf["APP.VARS.cookies"][$d++]="";
		
	//^^cloudflare cookies
	//***
//
?>
