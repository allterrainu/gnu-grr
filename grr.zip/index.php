<?php 
	error_reporting(E_ERROR); 
	ini_set('display_errors', FALSE); 
	//error_reporting(E_ALL); 
	//ini_set('display_errors', TRUE); 
	ini_set('session.use_cookies', 0); 
	ini_set('session.use_only_cookies', 0); 
	ini_set('session.use_trans_sid', 0); 
	global $conf;
	global $countryCode, $languageCode; 
	 
	require("./base/conf/db.conf.php"); 
	require("./base/conf/app_silent.inc.php");
	global ${$conf["APP.SESSION.sign"]};
	require("./base/lang/perlmut.lang.php");
	require("./base/conf/perlmut.conf.php");
	require("./vcnnative/lib/functions/perlmut.functions.php"); 
	require("./vcnnative/lib/classes/perlmut.classes.php"); 
	//forced procedure to make res avail 
	include("./vcnnative/client/gateway.php");
	${$conf["APP.SESSION.sign"]}->setEnrollStatement();
	include("./vcnnative/client/acknowledge.php"); 
	${$conf["APP.SESSION.sign"]}->setEnrollStatement();
	session_write_close(); 
	exit($conf["sessionExitCodeSuccess"]); 
?> 
