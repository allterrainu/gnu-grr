<?php 

        global $conf;
        global ${$conf["APP.SESSION.sign"]};
        
	error_reporting(E_ERROR); 
 
	ini_set('display_errors', true); 


	$lang["greetings"]["scan_sys_reset"]["de"]=(($lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]] . ($lang["first_clause"]["scan_sys_service"]["register"]?$lang["session_service"]["scan_sys_service"]["lock"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]:$conf["domain"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]["session"]))==($lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]))?$lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]:$lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang];
	$lang["greetings"]["scan_sys_reset"]["en"]=(($lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]] . ($lang["first_clause"]["scan_sys_service"]["register"]?$lang["session_service"]["scan_sys_service"]["lock"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]:$conf["domain"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]["session"]))==($lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]))?$lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]:$lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang];

	function isValidMd5($md5){
		if($md5=="") return false;
		return !ctype_digit($md5)&&ctype_lower($md5)&&ctype_alpha($md5)?true:false;
	}

	function fillFrontEndZeros($of, $by){
		$retval=$of;
		for($c=0; $c < $by-strlen($of); $c++){
			$retval= "0" . $retval;
		}
		return $retval;
	}
 
 
	/* 
	BB2C SessionFlagZ 
	*/ 
 
	function isSubDomainCarry($url){ 
		return substr_count(substr($url, 0, strpos($url, "/")?strpos($url, "/"):strlen($url)), ".")>=2?true:false; 
	} 
	 
	/**** 
		improoved equotation  
	****//* 
		port carry e.g. debian http port (10000) won't deliver false 
		*/ 
		 
	function isIPV4ADR($thesis){ 
		$ary=null; 
		//gopher and THE REST is very fine 
		/* 
		deploys (ausfahren) even not (as it was) wheter {QUERY} does carry dots '.' and whatever let me q 
		*/ 
		$r=0; 
		$blamedPlan=false; 
		$stepCount=0; 
		while($stepCount<=2){ 
			$itr=strstr(substr($thesis, $r), ".", true); 
			$d=0; 
			while(!is_numeric(substr($itr, $d))&&$d<=strlen($itr)){ 
				$d++; 
			} 
			$failed=$d>strlen($itr)?true:false; 
			$itr=substr($itr, $d); 
			$r+=strpos(substr($thesis, $r++), "."); 
			$ary[$stepCount++]=strlen($itr)>0?$itr:null; 
		} 
		$blamedPlan=$failed; 
		$r; 
		$stepCount--; 
		$itr=$stepCount>2?"":substr($thesis, $r); 
		$a=0; 
		$delim[$a++]=":"; 
		$delim[$a++]="/"; 
		$delim[$a++]="."; 
		$delim[$a++]="?"; 
		$found=false; 
		$occ=-1; 
		$maxitr=null; 
		$itrCR=$itr; 
		for($v=0; $v < sizeof($delim); $v++){ 
			$found=0; 
			$found=strpos($itrCR, $delim[$v]); 
			$found++; 
			$occ=$found!=false?$found--:$occ; 
			$itr=($occ!=-1)?substr($itrCR, 0, $found):$itrCR; 
			$maxitr[$v]=$itr; 
		} 
		$itsmin=0; 
		for($v=0; $v<sizeof($maxitr); $v++){ 
			$itsmin=strlen($maxitr[$v])<=strlen($maxitr[$itsmin])&&strlen($maxitr[$v])!=0?$v:$itsmin; 
		} 
		$ary[$stepCount]=$maxitr[$itsmin]; 
		for($v=0; $v<sizeof($ary)&&!$blamedPlan; $v++){ 
			$isnum=false; 
			if(is_numeric($ary[$v])){ 
				$isnum=true; 
				if($ary[$v]>=255){ 
					$blamedPlan=true; 
				} 
			}else{ 
				$blamedPlan=true; 
			} 
		} 
		return (substr_count($thesis , ".", (strpos($thesis, "http://")!=false?7:(strpos($thesis, "https://")!=false?8:(strpos($thesis, ".")>=3?strpos($thesis, "."):0))))>=3)?(!$blamedPlan?true:false):false;  
	} 
 
function fullDeclaredModulo($a, $b){ 
 
 
 
	$retval=round((($a/$b)-floor($a/$b))*$b); 
 
 
 
	return $retval; 
 
 
 
} 

function session_enable($terransUniteSession_1){
	global $conf;
	global ${$conf["APP.SESSION.sign"]}, $lang, $langmode, $countryCode, $languageCode; 
	$terransUniteSession_1=${$conf["APP.SESSION.sign"]}!=null?${$conf["APP.SESSION.sign"]}:$terransUniteSession_1;
	/*
		Enterpreneur Duty Ship
	*/			
	$sid=session_continue($terransUniteSession_1);
	if($sid===$terransUniteSession_1->restoreSession($terransUniteSession_1->getSessionIdByCookie())){
		${$conf["APP.SESSION.sign"]}->setEnrollStatement();
		session_id($sid);
	}else{
		$sid=session_initialize($terransUniteSession_1);
	}
	session_id($sid);
	$itsServ=false;
	include("./base/site/index.php");
	${$conf["APP.SESSION.sign"]}=$terransUniteSession_1;
	//BTTBX
//	echo session_id();
//	echo $terransUniteSession_1->EXPIRED;
	//*** database cleared issue not yet
	${$conf["APP.SESSION.sign"]}->setEnrollStatement();
	return $sid==$terransUniteSession_1->EXPIRED?false:session_id();
} 
 
 
function session_initialize($terransUniteSession_1){ 
	global $conf;
global ${$conf["APP.SESSION.sign"]}; 
	$terransUniteSession_1=${$conf["APP.SESSION.sign"]}!=null?${$conf["APP.SESSION.sign"]}:$terransUniteSession_1;
	$dssid=$terransUniteSession_1->getSessionIdByCookie(); 
	$asid=$terransUniteSession_1->manageSession($dssid, $conf["sidsLength"], true, false, true, true); 
	$sid=$terransUniteSession_1->manageSession(($dssid!=""?$dssid:$asid), $conf["sidsLength"], false, true, true, false); 
	//*** bttbxk
	//$terransUniteSession_1->savePPDSid($bsid); 
	${$conf["APP.SESSION.sign"]}=$terransUniteSession_1;
	${$conf["APP.SESSION.sign"]}->setEnrollStatement();
	return $sid; 
} 
 
function session_continue($terransUniteSession_1){//solved by merchandised cookie probs with run over a minute 
	global $conf;
	global ${$conf["APP.SESSION.sign"]}; 
	$terransUniteSession_1=${$conf["APP.SESSION.sign"]}!=null?${$conf["APP.SESSION.sign"]}:$terransUniteSession_1;
	$asid=$terransUniteSession_1->getSessionIdByCookie(); 
	$sid=$terransUniteSession_1->manageSession($asid, $conf["sidsLength"], false, true, true, false); 
	${$conf["APP.SESSION.sign"]}=$terransUniteSession_1;
	return $sid;
} 


function floatModulo($a, $b){ 
 
 
 
	$retval=((($a/$b)-floor($a/$b))*$b); 
 
 
 
	return $retval; 
 
 
 
} 
 
 
 
 
 
 
 
function mirrorOut($header, $tmpPath, $prefix, $recId, $extension, $ph){ 
		global $conf;
		global ${$conf["APP.SESSION.sign"]};

		if($ph){
			require($tmpPath . "/" . $_SESSION[$prefix . $recId] . "." . $extension); 
		}else{ 
			if($extension=="js"){ 
				$decimated=file_get_contents($tmpPath . "/" . $_SESSION[$prefix . $recId] . "." . $extension);	 
				$decimated=str_ireplace("#DOL#", "$", $decimated); 
				$decimated=str_ireplace("#ESCAPEDSINGLEQUOTE#", "\'", $decimated); 
				$decimated=str_ireplace("#SINGLEQUOTE#", "'",  $decimated); 
				$decimated=str_ireplace("#ESCAPEDQUOTE#", "\\\"", $decimated); 
				$decimated=str_ireplace("#SEMICOLON#", ";", $decimated); 
				$decimated=str_ireplace("#QUOTE#", "\"", $decimated); 
				$decimated=str_ireplace("#BOUNDEDESCAPEDQUOTE#", "\\\\\\\"", $decimated); 
				$decimated=str_ireplace("#PREPROCIN#", "<?php", $decimated); 
				$decimated=str_ireplace("#PREPROCOUT#", "?>", $decimated); 
				$decimated=str_ireplace("#CMTIN#", "/*", $decimated); 
				$decimated=str_ireplace("#CMTOUT#", "*/", $decimated); 
				$decimated=str_ireplace("#COMMENT#", "//", $decimated); 
				$decimated=str_ireplace("#NL#", "\n", $decimated); 
				$decimated=str_ireplace("#TAB#", "\t", $decimated); 
				$decimated=str_ireplace("#PRESET#", "\\", $decimated); 
				$decimated=str_ireplace("#ESCPRESET#", "\\\\", $decimated); 
				echo $decimated; 
			}else{ 
				echo file_get_contents($tmpPath . "/" . $_SESSION[$prefix . $recId] . "." . $extension); 
			} 
		} 
 
 
} 
 
 
 
 
 
 
 
function mirrorOff($tmpPath, $tmpFilename){ 
 
 
 
		$loc=$tmpPath . "/" . $tmpFilename; 
 
 
 
		chmod($tmpPath, 755); 
 
 
 
		chmod($loc, 755); 
 
 
 
		unlink($loc); 
 
 
 
} 
 
 
 
 
 
 
 
function striposi($temp, $a){ 
 
 
 
	$v=0; 
 
 
 
	while((substr($temp, $v, strlen($a))!=$a)&&(($v+strlen($a))<=strlen($temp))){ 
 
 
 
		$v++; 
 
 
 
	} 
 
 
 
	return ((($v+strlen($a))<=strlen($temp))?$v:-1); 
 
 
 
} 
 
 
 
global $port; 
 
 
$port=null; 


function hasValidCookie($field, $sid, $trust){
	global $conf;
	global ${$conf["APP.SESSION.sign"]};
	reset($field);
	if(sizeof($field)>0){	
		$tme=current($field);
		do{
			if($tme!=false) if(strlen($tme)>0){			
				$dds=true;
				$md5SessionCookie=key($field);
				if($md5SessionCookie!=false){
					$dds=strlen($md5SessionCookie)>0?$dds:false;
					$dds=(substr($tme, 0, 2)!="0x")?$dds:false;
					for($o=0; $o<sizeof($conf["APP.VARS.cookies"])&&$dds; $o++){
						$dds=$conf["APP.VARS.cookies"][$o]!=$md5SessionCookie?(!isValidMd5($md5SessionCookie)?$dds:false):false;
					}
					if($dds){
						$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT `sid` FROM `{${$conf["APP.SESSION.sign"]}->perlmut_session_cookies_table}` WHERE `sessionCookie2C`='$md5SessionCookie';"); 
						if($result){ 
							$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
							if($enrow){
                                                            if($sid==$enrow[0]||$trust){ 
								return $trust?$enrow[0]:$md5SessionCookie; 
                                                            }
                                                        }else return false;
						}
					}
				}
			}
			$tme=next($field);
		}while($tme!=false);
	}
	return false;
} 
 
 
 
function getCookieStorage($field){
	global $conf;
	global ${$conf["APP.SESSION.sign"]};
	$retval=null;
	reset($field);
	if(sizeof($field)>0){
		$tme=current($field);		
		do{
			if($tme) if(strlen($tme)>0){
				$md5SessionCookie=key($field);				
				if($md5SessionCookie!=false){
					if(strlen($md5SessionCookie)>0){
						$dds=true;
						if(substr($tme, 0, 2)!="0x"){	
							for($o=0; $o<sizeof($conf["APP.VARS.cookies"])&&$dds; $o++){
								$dds=($conf["APP.VARS.cookies"][$o]!=$md5SessionCookie&&(isValidMd5($md5SessionCookie)))?	$dds:false;
							}
							if($dds){
								$retval[$count]["hash"]=$md5SessionCookie;
								$retval[$count++]["time"]=$tme;
							}
						}
					}
				}
			}
			$tme=next($field);
		}while($tme!=false);
	}
	return $retval;
}

function open($save_path, $session_name){ 
	global $conf;
	global ${$conf["APP.SESSION.sign"]};
	${$conf["APP.SESSION.sign"]}->sessionPath=$save_path;
	${$conf["APP.SESSION.sign"]}->sessionName=$session_name;
	return true;
} 
 
 
 
 
function close(){
	global $conf;
	global ${$conf["APP.SESSION.sign"]};
	${$conf["APP.SESSION.sign"]}->sessionPath=null;
	${$conf["APP.SESSION.sign"]}->sessionName=null;
	return true;
}
 
 
 
 
 
 
function read($pkey){ 
	global $conf;
global ${$conf["APP.SESSION.sign"]};
 	$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT `value` FROM `{${$conf["APP.SESSION.sign"]}->perlmut_session_vars_table}` WHERE `entryId`='$pkey';");
	if($result){ 
 		if($result->num_rows>0){ 
 			$row=mysqli_fetch_array($result, MYSQLI_NUM);
 			return $row[0]; 
		} 
		return ""; 
	} 
	return ""; 
} 
 
function write($pkey, $val){
	$microtime = microtime();
	$microtimeMillis = strtok($microtime, " ");
	$microtimeSeconds = strtok(" ");
	global $conf;
	global ${$conf["APP.SESSION.sign"]};
	${$conf["APP.SESSION.sign"]}->smartStoreBackup(false); //faster when done only on concurrent session
	$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT `value` FROM `{${$conf["APP.SESSION.sign"]}->perlmut_session_vars_table}` WHERE `entryId`='$pkey';"); 
 	if($result){ 
 		if($result->num_rows>0){ 
 			$result2=${$conf["APP.SESSION.sign"]}->doQuery("UPDATE `{${$conf["APP.SESSION.sign"]}->perlmut_session_vars_table}` SET `value`='$val', `createTime`=$microtimeSeconds WHERE `entryId`='$pkey';"); 
			if($result2){ 
 				return true; 
 			} 
			return false; 
 		} 
 		else{ 
 			$result2=${$conf["APP.SESSION.sign"]}->doQuery("INSERT INTO `{${$conf["APP.SESSION.sign"]}->perlmut_session_vars_table}` (`entryId`, `value`, `path`, `sessionName`, `createTime`, `sessionCookie2C`) VALUES('$pkey', '$val', '{${$conf["APP.SESSION.sign"]}->sessionPath}', '{${$conf["APP.SESSION.sign"]}->sessionName}', $microtimeSeconds, '{${$conf["APP.SESSION.sign"]}->sessionCookieToken}');");
 			if($result2){ 
 				return true; 
 			} 
 			return false; 
		} 
 	}else{ 
		$result2=${$conf["APP.SESSION.sign"]}->doQuery("INSERT INTO `{${$conf["APP.SESSION.sign"]}->perlmut_session_vars_table}` (`entryId`, `value`, `path`, `sessionName`, `createTime`, `sessionCookie2C`) VALUES('$pkey', '$val', '{${$conf["APP.SESSION.sign"]}->sessionPath}', '{${$conf["APP.SESSION.sign"]}->sessionName}', $microtimeSeconds, '{${$conf["APP.SESSION.sign"]}->sessionCookieToken}');");
		if($result2){ 
 			return true; 
 		} 
 		return false; 
 	} 
	return false; 
} 
 
 
 
 
 
 
 //indexing does obsolente no recall within after invocation of destroy or time elappted trash therefore no funds of register are useful verify //*** secureFinsihAuth()
function destroy($pkey){ 
 	global $conf;
	global ${$conf["APP.SESSION.sign"]};
	/* **root data** */	
	${$conf["APP.SESSION.sign"]}->smartStoreBackup($ary, $self?null:$sessionCookie2C); 
	$result=${$conf["APP.SESSION.sign"]}->doQuery("DELETE FROM `{${$conf["APP.SESSION.sign"]}->perlmut_session_vars_table}` WHERE `entryId`='$pkey';"); 
 	if($result){ 
 		return true; 
 	} 
 	return false; 
} 
 
 
 
 
 
 
 
function trash($maxlifetime){ 
	//$maxlifetime	
	/* **root data** */
    
    global $conf;
	${$conf["APP.SESSION.sign"]}->smartStoreBackup($ary, $self?null:$sessionCookie2C); 
	
	//getting $_SESSION_RESTORE >> finishTransfer(${$conf["APP.SESSION.sign"]}->virtualcookie_read($val));
	return true; 
} 
 
session_set_save_handler("open", "close", "read", "write", "destroy", "trash"); 
 
 
 
session_cache_limiter("nocache"); 
 
 
 
 
//due to maintaineance 
 
 
function getBaseVar($varName, $field, $varId){ 
 
 
 
	$varId=$varId?$varId:false; 
 
 
 
	global $conf; 
 
 

	global ${$conf["APP.SESSION.sign"]};
 
 
 
	if($varId>0) $result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT * FROM `" . $conf["baseVars"] . "` WHERE `parentVarId`='$varId' AND `varname`='$varName';"); 
 
 
 
	else  $result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT * FROM `" . $conf["baseVars"] . "` WHERE `varname`='$varName';"); 
 
 
 
	if($result) if($result->num_rows>0){ 
 
 
 
		$fetch=mysqli_fetch_array($result, MYSQLI_ASSOC);  
 
		return $fetch[$field]; 
 
 
 
	} 
 
 
 
	return false; 
 
 
 
} 
 
 
 
 
 
 
 
/*e.G.: 
 
 
 
 
 
 
 
getBaseVar("tax1", "value", getBaseVar("taxDeclarations", "varId", false)); //gets global tax 
 
 
 
getBaseVar("tax2", "value", getBaseVar("taxDeclarations", "varId", false)); //gets global minor tax 
 
 
 
*/ 
 
 
 
 
 
 
 
function countChars($of, $except){ 
 
 
 
	$countTable=NULL; 
 
 
 
	for($v=0; $v < strlen($of); $v++){ 
 
 
 
		$c=substr($of, $v, 1); 
 
 
 
		$isin=false; 
 
 
 
		if($except){ 
 
 
 
			for($a=0; $a < strlen($except); $a++){ 
 
 
 
				$isin=$c==substr($except, $a,1)?true:$isin; 
 
 
 
				if($isin){ 
 
 
 
					break; 
 
 
 
				} 
 
 
 
			} 
 
 
 
		} 
 
 
 
		if($isin==false){ 
 
 
 
			@$countTable[$c]++ or $countTable[$c]=1; 
 
 
 
		} 
 
 
 
	} 
 
 
 
	return $countTable; 
 
 
 
} 
 
 
 
 
 
 
 
function stripQueryChars($of){ 
 
 
 
	$a=0; 
 
 
 
	$forbidden[$a++]="SELECT"; 
 
 
 
	$forbidden[$a++]="CREATE"; 
 
 
 
	$forbidden[$a++]="DELETE"; 
 
 
 
	$forbidden[$a++]="ALTER"; 
 
 
 
	$forbidden[$a++]="UPDATE"; 
 
 
 
	$forbidden[$a++]="INSERT"; 
 
 
 
	$forbidden[$a++]="DROP"; 
 
 
	$forbidden[$a++]="TRUNCATE"; 
 
 
	$v=0; 
 
 
	$found=true; 
 
 
 
	while($v<$a){ 
 
 
 
		$temp=$forbidden[$v]; 
 
 
 
		$b=strlen($of)-strlen($temp); 
 
 
 
		for($i=0; $i < $b ; $i++){ 
 
 
 
			$is=substr($of, $i, strlen($temp)); 
 
 
 
			if($is==$temp){ 
 
 
 
				$of=substr($of, 0, $i) . substr($of, $i+strlen($temp), strlen($of)-strlen($temp)); 
 
 
 
				break; 
 
 
 
			} 
 
 
 
		} 
 
 
 
		$v++; 
 
 
 
	} 
 
 
 
	return $of; 
 
 
 
} 
 
 
	function getSessionIdByCookie(){
		if(sizeof($_COOKIE)>0){
			$sid=hasValidCookie($_COOKIE, false, true);
			if($sid!=null){
				return $sid;
			}
		}
		return "";
	}

  
 
 
 
 
function dateIsBetween($cdate, $adate, $bdate){//hu T includes borders 
 
 
 
	echo $cdate["mday"] . "." . $cdate["mon"] . "." . $cdate["year"]; 
 
 
 
	echo "<br>" . $adate["mday"] . "." . $adate["mon"] . "." . $adate["year"]; 
 
 
 
	echo "<br>" . $bdate["mday"] . "." . $bdate["mon"] . "." . $bdate["year"]; 
 
 
 
 
 
 
 
	if(parseInt($adate["year"])<=parseInt($cdate["year"])&&parseInt($bdate["year"])>=parseInt($cdate["year"])){ 
 
 
 
		if(parseInt($adate["year"])==parseInt($cdate["year"])&&parseInt($bdate["year"])==parseInt($cdate["year"])){ 
 
 
 
			if(parseInt($adate["mon"])<=parseInt($cdate["mon"])&&parseInt($bdate["mon"])>=parseInt($cdate["mon"])){ 
 
 
 
				if(parseInt($adate["mon"])==parseInt($cdate["mon"])&&parseInt($bdate["mon"])==parseInt($cdate["mon"])){ 
 
 
 
					if(parseInt($adate["mday"])<=parseInt($cdate["mday"])&&parseInt($bdate["mday"])>=parseInt($cdate["mday"])){ 
 
 
 
						if(parseInt($adate["mday"])==parseInt($cdate["mday"])&&parseInt($bdate["mday"])==parseInt($cdate["mday"])){ 
 
 
 
							return true; //T 
 
 
 
						}else{ 
 
 
 
							return true; 
 
 
 
						} 
 
 
 
					}else{ 
 
 
 
						return false; 
 
 
 
					} 
 
 
 
				}else{ 
 
 
 
					if(parseInt($adate["mon"])==parseInt($cdate["mon"])){ 
 
 
 
						if(parseInt($adate["mday"])<=parseInt($cdate["mday"])){ 
 
 
 
							if(parseInt($adate["mday"])==parseInt($cdate["mday"])){ 
 
 
 
								return true;  //T 
 
 
 
							}else{ 
 
 
 
								return true; 
 
 
 
							} 
 
 
 
						}else{ 
 
 
 
							return false; 
 
 
 
						} 
 
 
 
					}else if(parseInt($bdate["mon"])==parseInt($cdate["mon"])){ 
 
 
 
						if(parseInt($bdate["mday"])>=parseInt($cdate["mday"])){ 
 
 
 
							if(parseInt($bdate["mday"])==parseInt($cdate["mday"])){ 
 
 
 
								return true;  //T 
 
 
 
							}else{ 
 
 
 
								return true; 
 
 
 
							} 
 
 
 
						}else{ 
 
 
 
							return false; 
 
 
 
						} 
 
 
 
					}else{ 
 
 
 
						return true; 
 
 
 
					} 
 
 
 
				} 
 
 
 
			}else{ 
 
 
 
				return false; 
 
 
 
			} 
 
 
 
		}else{ 
 
 
 
			if(parseInt($adate["year"])==parseInt($cdate["year"])){ 
 
 
 
				if(parseInt($adate["mon"])<=parseInt($cdate["mon"])){ 
 
 
 
					if(parseInt($adate["mon"])==parseInt($cdate["mon"])){ 
 
 
 
						if(parseInt($adate["mday"])<=parseInt($cdate["mday"])){ 
 
 
 
							if(parseInt($adate["mday"])==parseInt($cdate["mday"])){ 
 
 
 
								return true;  //T 
 
 
 
							}else{ 
 
 
 
								return true; 
 
 
 
							} 
 
 
 
						}else{ 
 
 
 
							return false; 
 
 
 
						} 
 
 
 
					}else{ 
 
 
 
						return true; 
 
 
 
					} 
 
 
 
				}else{ 
 
 
 
					return false; 
 
 
 
				} 
 
 
 
			}else if(parseInt($bdate["year"])==parseInt($cdate["year"])){ 
 
 
 
				if(parseInt($bdate["mon"])>=parseInt($cdate["mon"])){ 
 
 
 
					if(parseInt($bdate["mon"])==parseInt($cdate["mon"])){ 
 
 
 
						if(parseInt($bdate["mday"])>=parseInt($cdate["mday"])){ 
 
 
 
							if(parseInt($bdate["mday"])==parseInt($cdate["mday"])){ 
 
 
 
								return true;  //T 
 
 
 
							}else{ 
 
 
 
								return true; 
 
 
 
							} 
 
 
 
						}else{ 
 
 
 
							return false; 
 
 
 
						} 
 
 
 
					}else{ 
 
 
 
						return true; 
 
 
 
					} 
 
 
 
				}else{ 
 
 
 
					return false; 
 
 
 
				} 
 
 
 
			} 
 
 
 
		} 
 
 
 
	}else{ 
 
 
 
		return false; 
 
 
 
	} 
 
 
 
} 
 
 
 
 
 
 
 
function parseInt($str){ 
 
 
 
	$number=0; 
 
 
 
	$first=false; 
 
 
 
	$ints=null; 
 
 
 
	$neg=false; 
 
 
 
	$end=false; 
 
 
 
	$mustFollowNum=false; 
 
 
 
	$n=0; 
 
 
 
	$trigger=false; 
 
 
 
 
 
 
 
	for($a=0; $a < strlen($str)&&!$end; $a++){ 
 
 
 
		$c=substr($str,$a,1); 
 
 
 
		if($mustFollowNum==true){ 
 
 
 
			if(!$trigger){ 
 
 
 
				if(!$first){ 
 
 
 
					$neg=false; 
 
 
 
				}else{ 
 
 
 
				$mustFollowNum=false; 
 
 
 
				} 
 
 
 
			}else{ 
 
 
 
				$trigger=false; 
 
 
 
			} 
 
 
 
		} 
 
 
 
		switch($c){ 
 
 
 
			case "-": 
 
 
 
				$neg=true; 
 
 
 
				$mustFollowNum=true; 
 
 
 
				$trigger=true; 
 
 
 
			break; 
 
 
 
			case "0": 
 
 
 
				if($first==false){ 
 
 
 
					; 
 
 
 
				}else{ 
 
 
 
					$ints[$n++]=0; 
 
 
 
				} 
 
 
 
				break; 
 
 
 
			case "9": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=9; 
 
 
 
			break; 
 
 
 
			case "8": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=8; 
 
 
 
			break; 
 
 
 
			case "7": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=7; 
 
 
 
			break; 
 
 
 
			case "6": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=6; 
 
 
 
			break; 
 
 
 
			case "5": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=5; 
 
 
 
			break; 
 
 
 
			case "4": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=4; 
 
 
 
			break; 
 
 
 
			case "3": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=3; 
 
 
 
			break; 
 
 
 
			case "2": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=2; 
 
 
 
			break; 
 
 
 
			case "1": 
 
 
 
				$first=true; 
 
 
 
				$ints[$n++]=1; 
 
 
 
			break; 
 
 
 
			default: 
 
 
 
				if($first==true){ 
 
 
 
					$end=true; 
 
 
 
				} 
 
 
 
 
 
 
 
		} 
 
 
 
	} 
 
 
 
	$n=0; 
 
 
 
	for($a=sizeof($ints)-1; $a >= 0; $a--){ 
 
 
 
		$number+=pow(10, $a) * $ints[$n++]; 
 
 
 
	} 
 
 
 
	if($neg){ 
 
 
 
		return -1*$number; 
 
 
 
	} 
 
 
 
	return $number; 
 
 
 
} 
 
 
 
 
 
 
 
/*2BC*/ 
 
 
 
?>