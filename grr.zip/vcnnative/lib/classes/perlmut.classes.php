<?php

global $conf, $dbm;

function getMoonPhase($date, $images){

	global $conf;
	global ${$conf["APP.SESSION.sign"]};

	return floor(${$conf["APP.SESSION.sign"]}->getMoonPhasis($date, $images))+1;
}

class CalendarDay{
	var $D_Mon=-1;
	var $D_Year=-1;
	var $D_Day=-1;
	var $T_Hour=-1;
	var $T_Minute=-1;
	var $T_Second=-1;
	
	function CalendarDay(){
		//parent::CalendarDay();
	}
		
	function setDate($ary){
		$this->setDateFunc($ary["year"], $ary["mon"], $ary["mday"], isSet($ary["hour"])?$ary["hour"]:0, isSet($ary["minute"])?$ary["minute"]:0, isSet($ary["second"])?$ary["second"]:0);
	}
	
	function setDateFunc($year, $mon, $day, $hour, $minute, $second){
		$this->D_Year=$year;
		$this->D_Mon=$mon;
		$this->D_Day=$day;
		$this->T_Hour=$hour;
		$this->T_Minute=$minute;
		$this->T_Second=$second;
	}
	
	function getDate(){
		$retval["year"]=$this->D_Year;
		$retval["mon"]=$this->D_Mon;
		$retval["mday"]=$this->D_Day;
		$retval["hour"]=$this->T_Hour;
		$retval["minute"]=$this->T_Minute;
		$retval["second"]=$this->T_Second;
		
		return $retval;
	}
}

class JulianDayEphemeris{

	var $decimal=null;
	var $mountGDate=null;

	function JulianDay(){
	
	}
	
	function getJDE(){
		return $this->decimal;
	}
	
	function setJDE($jde){
		$this->decimal=$jde;
	}
	
	function applyFromGDate(){
		$date=$this->mountGDate->getDate();
		$Y=$date["year"];
		$M=$date["mon"];
		$D=$date["mday"];
		$DH=$date["hour"];
		$DM=$date["minute"];
		$DS=$date["second"];
		$D+=-1+($DH+($DM/60)+($DS/(60*60)))/24;
		$Y=$M<=2?$Y-1:$Y;
		$M=$M<=2?$M+12:$M;
		$A=floor($Y/100);
		$B=2-$A+floor($A/4);
		$valJD=floor(365.25*($Y+4716)) + floor(30.6001*($M+1)) +$D +$B - 1524.5;
		$this->decimal=$valJD;
	}
	
	function getGregorianDate(){
		//fur further agreso use ya south DDAY
	}
	
	function setGregorianDate($ary){
		$this->mountGDate= new CalendarDay();
		$this->mountGDate->setDate($ary);
		$this->applyFromGDate();
	}
}


class DatePub{
	
	var $currentSetGDate=null;
	var $currentSetJDE=null;
	var $currentSetDynamicTime=null;

	function DatePub(){
		
	}
	
	function setGDate($ary){
		$this->currentSetGDate= new CalendarDay();
		$this->currentSetGDate->setDate($ary);
	}
	
	function setJDE($decimal){
		$this->currentSetJDE=new JulianDayEphemeris();
		$this->currentSetJDE->setJDE($decimal);
	}
}

	function getMoonAverage($date){
		global $conf;
		global ${$conf["APP.SESSION.sign"]};

  		$backside=0.5;
		$avg_date=new DateTime();
		$avg_date->setDate($date["year"], $date["mon"], $date["mday"]);
		$avg_phasis=null;
		$count=0;
		for($v=0; $v<floor($repeats*$backside); $v++){
			for($d=0; $d < 59; $d++){
				date_add($avg_date, new DateInterval("P1D"));
			}
			$avg_str_date=$avg_date->format(DATE_ATOM);	
			$avg_phasis[$count++]=getMoon(${$conf["APP.SESSION.sign"]}->hackDate($avg_str_date, "-", "year", "mon", "mday"));
		}
		$avg_date->setDate($date["year"], $date["mon"], $date["mday"]);
		$avg_str_date=$avg_date->format(DATE_ATOM);
		$avg_phasis[$count++]=getMoon(${$conf["APP.SESSION.sign"]}->hackDate($avg_str_date, "-", "year", "mon", "mday"));
		for($v=0; $v<floor($repeats*(1-$backside)); $v++){
			for($d=0; $d < 59; $d++){
				date_sub($avg_date, new DateInterval("P1D"));
			}
			$avg_str_date=$avg_date->format(DATE_ATOM);	
			$avg_phasis[$count++]=getMoon(${$conf["APP.SESSION.sign"]}->hackDate($avg_str_date, "-", "year", "mon", "mday"));
		}
		$retval_min=0;
		$retval_max=0;
		$t=1;
		rsort($avg_phasis);
		$scount1=1;
		$scount2=0;
		$retval_min+=$avg_phasis[0];
		$compAvg=0;
		for(; $t < sizeof($avg_phasis); $t++){
			$compAvg+=$avg_phasis[$t];
			if($avg_phasis[$t]>(($retval_min/$scount1)/1.5)){//filters overflow values
				$retval_min+=$avg_phasis[$t];
				$scount1++;
			}else{
				$retval_max+=$avg_phasis[$t];
				$scount2++;
			}
		}
		if(($scount1>=$scount2/1.5)||($scount2>$scount1/1.5)){if($scount1>=$scount2){//gathers more relevant information
				$retval=$retval_min/$scount1;
			}else{
				$retval=$retval_max/$scount2;
			}
		}else{
			$retval=$compAvg/sizeof($avg_phasis);
		}
		return floor($retval);
	}

function getYearDecimal($date){
	$d=0;
	$day_year[$d++]=-1;

		$day_year[$d++]=-1;

		$day_year[$d++]=30;

		$day_year[$d++]=58;

		$day_year[$d++]=89;

		$day_year[$d++]=119;

		$day_year[$d++]=150;

		$day_year[$d++]=180;

		$day_year[$d++]=211;

		$day_year[$d++]=241;

		$day_year[$d++]=272;

		$day_year[$d++]=303;

		$day_year[$d++]=333;
	$dday=0;
	for($d=1; $d<=$date["mon"]; $d++){
		$dday=$day_year[$d];
	}
	$dday+=($date["mday"])+($date["hour"]+($date["minute"]/60)+($date["second"]/(60*60)))/24;
	
	$perc=$dday/365;
	
	$retval=$date["year"]+$perc;
	return $retval;
}

function getMoon($date){
	$dateHolder=new CalendarDay();
	$dateHolder->setDate($date);
	$aryDate=$dateHolder->getDate();
	$valJDEgather=new JulianDayEphemeris();
	$valJDEgather->setGregorianDate($date);
	$valJDE=$valJDEgather->getJDE();
	$Y=getYearDecimal($aryDate);
	$k=($Y-2000) * 12.3601;
	$compare=($k*1000000)%1000000;
	$compare/=10000;
	$perc=(150-(100-$compare))%100;
	$perc=$perc<0?-1*$perc:$perc;
	return $perc;
}

//$perc=($scale<25?((-100+$scale)<50?100-$scale:50+$scale):($scale>50?((100-$scale)):(100-$scale>25?50-$scale:$scale)));
	
function getMoonLuminationInPercentage($date){
	$Y=getYearDecimal($date);
	$k=($Y-2000) * 12.3601;
	$compare=($k*1000000)%1000000;
	$compare=floor($compare);
	$compare/=10000;
	$perc=(150-(100-$compare))%100;
	$perc=$perc<0?-1*$perc:$perc;
	$scale=$perc;
	$perc=($scale<25?((-100+$scale)<50?100-$scale:50+$scale):($scale>50?((100-$scale)):(100-$scale>25?50-$scale:$scale)));
	$perc=$perc<0?$perc*-1:$perc;
	return $perc;
}

class DateDB{

	//conf

	var $what_db=null;

	var $what_dbname="";

	var $what_dbhost="";

	var $what_dblogin="";

	var $what_dbpass="";

	var $lang=null;

	var $cur_transaction;

	var $cur_transaction_position;

	var $cur_transaction_rollback_statements;

	var $calendar;

	var $gathering;

	var $tokens_to_url_table;

	var $resultStatementStack=null;

	var $openTransaction=false;

	function setDBVars($conf, $dbm){

		$this->calendar=$conf["calendar"];

		$this->gathering=$conf["gathering"];

		$this->what_dbname=$dbm["what_dbname"];

		$this->what_dbhost=$dbm["what_dbhost"];

		$this->what_dblogin=$dbm["what_dblogin"];

		$this->what_dbpass=$dbm["what_dbpass"];

		$this->lang=$conf["countryString"];

		$this->tokens_to_url_table=$conf["tokens"];
	}

	function setLanguage($countryString){

		$this->lang=$countryString;

	}

	function DateDB($conf, $dbm){

		$this->setDBVars($conf, $dbm);

	}

	function formatDate($cdate, $formatString, $hijri){//to be

		$retval="unclassified format string";

		if($formatString=="WD3 MON3 D HH:MM:SS YYYY"){

			$retval = substr($cdate["weekday"],0,3) . " " . substr($cdate["month"],0,3) . " " . $cdate["mday"] . " " . fillFrontEndZeros($cdate["hours"],2) . ":" . fillFrontEndZeros($cdate["minutes"],2) . ":" . fillFrontEndZeros($cdate["seconds"],2) . " " . $cdate["year"];

			return $retval;

		}

		if($formatString=="WD MON D HH:MM:SS YYYY"){

			$retval = $cdate["weekday"] . " " . $cdate["month"] . " " . $cdate["mday"] . " " . fillFrontEndZeros($cdate["hours"], 2) . ":" . fillFrontEndZeros($cdate["minutes"], 2) . ":" . fillFrontEndZeros($cdate["seconds"],2) . " " . $cdate["year"];

			return $retval;

		}

		if($formatString=="Dn MN YYYY"){

			if($hijri){

				$retval = $cdate["mday"] . ($cdate["mday"]==1?"st":($cdate["mday"]==2?"nd":($cdate["mday"]==3?"rd":"th"))) . " " . $this->calendar["Hijri"][$cdate["mon"]-1]["name"]["mu"] . " " . $cdate["year"];

			}else{

				$retval = $cdate["mday"] . ($cdate["mday"]==1?"st":($cdate["mday"]==2?"nd":($cdate["mday"]==3?"rd":"th"))) . " " . $this->calendar["Greogorian"][$cdate["mon"]-1]["name"][$this->lang!=null?$this->lang:"de"] . " " . $cdate["year"];

			}

			return $retval;

		}

		if($formatString=="Dn MN YY"){

			if($hijri){

				$retval = $cdate["mday"] . $cdate["mday"]==1?"st":$cdate["mday"]==2?"nd":$cdate["mday"]==3?"rd":"th" . " " . $this->calendar["Hijri"][$cdate["mon"]-1]["name"]["mu"] . " " . substr($cdate["year"],2,2);

			}else{

				$retval = $cdate["mday"] . $cdate["mday"]==1?"st":$cdate["mday"]==2?"nd":$cdate["mday"]==3?"rd":"th" . " " . $this->calendar["Greogorian"][$cdate["mon"]-1]["name"][$this->lang!=null?$this->lang:"de"] . " " . substr($cdate["year"],2,2);

			}

			return $retval;

		}

		if($formatString=="DD. MN YYYY"){

			if($hijri){

				$retval = $cdate["mday"] . ". " . $this->calendar["Hijri"][$cdate["mon"]-1]["name"][$this->lang!=null?$this->lang:"de"] . " " . $cdate["year"];

			}else{

				$retval =  $cdate["mday"] . ". " . $this->calendar["Greogorian"][$cdate["mon"]-1]["name"][$this->lang!=null?$this->lang:"de"] . " " . $cdate["year"];

			}

			return $retval;

		}

		if($formatString=="MMDDYYYY"){

			$retval = fillFrontEndZeros($cdate["mon"],2) . "-" . fillFrontEndZeros($cdate["mday"], 2) . "-" . $cdate["year"];

			return $retval;

		}

		if($formatString=="MDYYYY"){

			$retval = $cdate["mon"] . "-" . $cdate["mday"] . "-" . $cdate["year"];

			return $retval;

		}

		if($formatString=="MMDDYY"){

			$retval = $cdate["mon"] . "-" . $cdate["mday"] . "-" . substr($cdate["year"],2,2);

			return $retval;

		}

		if($formatString=="MMDDYY"){

			$retval = fillFrontEndZeros($cdate["mon"],2) . "-" . fillFrontEndZeros($cdate["mday"]) . "-" . substr($cdate["year"],2,2);

			return $retval;

		}

		if($formatString=="DDMMYYYY"){

			$retval = fillFrontEndZeros($cdate["mday"], 2) . "." . fillFrontEndZeros($cdate["mon"], 2) . "." . $cdate["year"];

			return $retval;

		}



		if($formatString=="YYYYMMDD"){

			$retval = $this->lang=="en"?fillFrontEndZeros($cdate["mon"], 2) . "-" . fillFrontEndZeros($cdate["mday"], 2) . "-" . $cdate["year"]:fillFrontEndZeros($cdate["mday"], 2) . "." . fillFrontEndZeros($cdate["mon"], 2) . "." . $cdate["year"];

			return $retval;

		}



		if($formatString=="DMYYYY"){

			$retval = $cdate["mday"] . "." . $cdate["mon"] . "." . $cdate["year"];

			return $retval;

		}

		if($formatString=="DDMMYY"){

			$retval = fillFrontEndZeros($cdate["mday"], 2) . "." . fillFrontEndZeros($cdate["mon"], 2) . "." . substr($cdate["year"],2,2);

			return $retval;

		}

		if($formatString=="DMYY"){

			$retval = $cdate["mday"] . "." . $cdate["mon"] . "." . substr($cdate["year"],2,2);

			return $retval;

		}

		if($formatString=="DD. MN YY"){

			if($hijri){

				$retval = $cdate["mday"] . "." . $this->calendar["Hijri"][$cdate["mon"]-1]["name"][$this->lang!=null?$this->lang:"de"] . " " . $cdate["year"];

			}else{

				$retval = $cdate["mday"] . "." . $this->calendar["Greogorian"][$cdate["mon"]-1]["name"][$this->lang!=null?$this->lang:"de"] . " " . $cdate["year"];

			}

			return $retval;

		}

		$delims=null;

		for($a=0; $a < strlen($formatString); $a++){

			if(countChars(substr($formatString, $a, 1), "MDY")!=null){

				$delims[sizeof($delims)]=substr($formatString, $a, 1);

			}

		}

		$a=0;

		$c=0;

		$format=null;

		while($a<strlen($formatString)&&sizeof($format)<4){

			$format[sizeof($format)]=strtok(substr($formatString, $a, strlen(formatString)-$a), $delims[$c++]);

		}

		$retval="";

		$a=0;

		for($h=0; $h < sizeof($format); $h++){

			if($format[$h]=="M"){

				$retval=$retval . $cdate["mon"];

			}

			if($format[$h]=="MM"){

				$retval=$retval . fillFrontEndZeros($cdate["mon"], 2);

			}

			if($format[$h]=="D"){

				$retval=$retval . $cdate["mday"];

			}

			if($format[$h]=="DD"){

				$retval=$retval . fillFrontEndZeros($cdate["mday"], 2);

			}

			if($format[$h]=="YY"){

				$retval=$retval . substr($cdate["year"],2,2);

			}

			if($format[$h]=="YYYY"){

				$retval=$retval . $cdate["year"];

			}

			if($h< sizeof($format)-1) $retval=$retval . $delims[$a++];

		}

		return $retval;

	}



	function getDate($cdate, $shijri){

		if(!$cdate){

			$cdate=getDate();

		}



		$cdate["mon"]=sqrt($cdate["mon"]*$cdate["mon"]);

		$cdate["mday"]=sqrt($cdate["mday"]*$cdate["mday"]);

		$gdate=$this->hackDate($this->gathering["Greogorian"], "-", "year", "mon", "mday");

		$hdate=$this->hackDate($this->gathering["Hijri"], "-", "year", "mon", "mday");

		if($shijri==true){

		$req=false;

		$cycyear=$hdate["year"];

		while(!$req){

			$hyear=$hdate["year"];

			$year=$gdate["year"];

			if(($year%4==0)&&(($year%400==0)||($year%100!=0))){

					$this->calendar["Greogorian"][1]["days"]=29;

			}else{

				$this->calendar["Greogorian"][1]["days"]=28;

			}

			$sw=($hyear-$cycyear==2)||($hyear-$cycyear==5)||($hyear-$cycyear==7)||($hyear-$cycyear==10)||($hyear-$cycyear==13)||($hyear-$cycyear==16)||($hyear-$cycyear==18)||($hyear-$cycyear==21)||($hyear-$cycyear==24)||($hyear-$cycyear==26)||($hyear-$cycyear==29)?true:false;

			if($hyear%30==0) $cycyear=$hyear;

			if($gdate["mon"]==$cdate["mon"]&&$gdate["year"]==$cdate["year"]&&$cdate["mday"]==$gdate["mday"]){

				$req=true;

			}

			$gdate["mday"]++;



			//if(!$req){



				if($gdate["mday"]>$this->calendar["Greogorian"][$gdate["mon"]-1]["days"]){

					$gdate["mon"]++;

					$gdate["mday"]=1;

					if($gdate["mon"]==13){

						$gdate["year"]++;

						$gdate["mon"]=1;



					}

				}

				if(!$req) $hdate["mday"]++;

				else{

					$hdate["mday"]--;

					if($hdate["mday"]==0){

						$hdate["mon"]--;

						if($hdate["mon"]==0){

								$hdate["year"]--;

								$hdate["mon"]=12;



						}

						$hdate["mday"]=$this->calendar["Hijri"][$hdate["mon"]-1][$sw?"sdays":"days"];



					}



				}



				if($hdate["mday"]>$this->calendar["Hijri"][$hdate["mon"]-1][$sw?"sdays":"days"]){

					$hdate["mon"]++;

					$hdate["mday"]=1;

					if($hdate["mon"]==13){

						$hdate["year"]++;

						$hdate["mon"]=1;



					}

				}

			//}



		}

		return $hdate;

		}

		return $cdate;

	}

	function getMoonPhasis($date, $images=false){

		$images=$images?$images:180;

		$retval=(getMoonAverage($date)*$images)/100;

		return $retval;

	}

	function getTime_HH_MM_SS($delim){//varchar(8) in perlmut db
		$help=getDate();
		$time=$help["hours"] . $delim . $help["minutes"] . $delim . $help["seconds"];
		return $time;
	}

	function hackDate($datum, $delim, $_1, $_2, $_3){
		$noError=strtok($datum, $delim);
		$retval=null;
		if($noError){//NULL hopefully to be interpreted like false !
			$retval[$_1]=parseInt($noError);
		}else{
			return null;
		}
		$noError=strtok($delim);
		if($noError){
			$retval[$_2]=parseInt($noError);
		}else{
			return null;
		}
		$noError=strtok($delim);
		if($noError){
			$retval[$_3]=parseInt($noError);
		}else{
			return null;
		}
		return $retval;
	}

	function hackTime($zeit, $delim){
		$noError=strtok($zeit, $delim);
		$retval=null;
		if($noError||$noError=="0"){//Really expressing ment more then only NULL so ThX view
			$retval["hours"]=$noError;
		}else{
			return null;
		}
		$noError=strtok($delim);
		if($noError||$noError=="0"){
			$retval["minutes"]=$noError;
		}else{
			return null;
		}
		$noError=strtok($delim);
		if($noError||$noError=="0"){
			$retval["seconds"]=$noError;
		}else{
			return null;
		}
		return $retval;
	}

	function getRecordSource($what_dbhost, $what_dblogin, $what_dbpass, $what_dbname, $new){
		if($this->what_db&&!$new){
			return $this->what_db;
		}
		$this->what_db = new mysqli($this->what_dbhost, $this->what_dblogin, $this->what_dbpass, $this->what_dbname);
		if ($this->what_db->connect_error) {
				die('Connect Error (' . $this->what_db->connect_errno . ') ' . $this->what_db->connect_error);
		}else $error=false;
		return $this->what_db;
	}

	function getConfigRecordSource(){
		return $this->getRecordSource($this->what_dbhost, $this->what_dblogin, $this->what_dbpass, $this->what_dbname, true);
	}

	function doQuery($sql){
		$result=mysqli_query($this->getConfigRecordSource(), $sql);
		if(mysqli_error($this->what_db)){
			echo $sql;
			echo mysqli_error($this->what_db);
		}else if($result) $this->closeDb();
		return $result;
	}

	function setEnrollStatement(){
		if($this->openTransaction){
			$state=true;
			try{
				if(isSet($this->resultStatementStack)) for($q=0; $q < sizeof($this->resultStatementStack); $q++){	
					if(!$this->resultStatementStack[$q]) throw new Exception(mysqli_error($this->what_db));				
				}			
			}catch(Exception $e){
				for($q=0; $q < sizeof($this->resultStatementStack); $q++){	
					if(isSet($this->resultStatementStack[$q])) if($this->resultStatementStack[$q]) $this->resultStatementStack[$q]->free();				
				}			
				if($this->what_db!=null) $this->what_db->rollback(true);
				$state=false;			
			}
			if($state){
				if($this->what_db!=null) $this->what_db->commit();
				$this->resultStatementStack=null;
				$this->openTransaction=false;
			}			
			if($this->what_db!=null) $this->what_db->autocommit(true);			
		}		
	}


	function doTransactionQuery($sql, $newopen=true, $finish=false){
		if($this->what_db==null) $this->what_db=$this->getConfigRecordSource();
		$newopen=$newopen?$newopen:false;
		if($newopen){
			if(!$this->openTransaction) $this->openTransaction=true;
			if($this->openTransaction) if($this->what_db!=null) $this->what_db->autocommit(false);
			
		}
		$finish=$finish?$finish:false;
		if($finish){
			if($this->openTransaction){
				$state=true;
				try{
					if(isSet($this->resultStatementStack)) for($q=0; $q < sizeof($this->resultStatementStack); $q++){	
						if(!$this->resultStatementStack[$q]) throw new Exception(mysqli_error($this->what_db));				
					}			
				}catch(Exception $e){
					for($q=0; $q < sizeof($this->resultStatementStack); $q++){	
						if(isSet($this->resultStatementStack[$q])) if($this->resultStatementStack[$q]) $this->resultStatementStack[$q]->free();						
					}			
					if($this->what_db!=null) $this->what_db->rollback(true);
					$state=false;			
				}
				if($state){
					if($this->what_db!=null) $this->what_db->commit();
					$this->resultStatementStack=null;
					$this->openTransaction=false;
				}			
				if($this->what_db!=null) $this->what_db->autocommit(true);			
			}		
		}else if($this->openTransaction){
			$result=@$this->what_db->query($sql);
			if($this->what_db->error){
				echo $sql;
				echo mysqli_error($this->what_db);
			}else{
				if(isSet($this->resultStatementStack)) $this->resultStatementStack[sizeof($this->resultStatementStack)]=$result;
				else $this->resultStatementStack[0]=$result;
			}
		}	
		return $result;
	}

	function getConnectionNumber(){
		return $this->what_db;
	}

	function closeDb(){
		if($this->what_db!=null) $this->what_db->close();
		$this->what_db=null;
	}
}

class Session extends DateDB{
	var $since=-1;
	var $counter=-1; //total means different conx since
	var $current_counter=-1;
	var $day_counter=-1;
	var $perlmut_session_table=null;
	var $perlmut_session_cookies_table=null;
	var $perlmut_host_table=null;
	var $perlmut_log_table=null; //not implemented yet
	var $perlmut_counter_table=null;
	var $session_security_expiration_timeout_in_minutes=-1;
	var $sessionExpire=-1;	
	var $perlmut_session_sid_range=null;
	var $perlmut_session_sid_length=null;
	var $perlmut_images_table=null; //not implemented yet
	var $hostRelRoot=null;
	var $hostId=1;
	var $relRoot="";
	var $EXPIRED=null;
	var $autoLogout=0;
	var $maxCookieLease=0;  //***with rember login
	var $maxCookieLife=0;	//***all other states
	var $restoreData=0;
	var $keepData=0;
	var $sessionCookieToken="";
	var $sessionName="";
	var $sessionPath="";
	var $perlmut_backup_table="";
	var $perlmut_session_store_table="";

	function getConnectionCount(){
		$result=$this->doTransactionQuery("SELECT * from `{$this->perlmut_session_table}` WHERE `hostId` = '{$this->hostId}';");
		if($result){
			$retval=$result->num_rows;
		}
		return $retval;
	}

	function validCookie($cookie){
		$sql="SELECT DISTINCT `sessionCookie2C` FROM `$this->perlmut_session_cookies_table` WHERE `sessionCookie2C`='$cookie';";
		$result=$this->doTransactionQuery($sql);
		if($result){
			$retval=$result->num_rows > 0;
		}
		return $retval?$retval:null;
	}

	function getSessionExitCode($sucess){
		return $sucess?$this->EXIT_SUCCESS:$this->EXIT_FAILURE;
	}

	function finishAuth(){/*
		$osid=session_id();
		$issid=$this->generateSID($this->perlmut_session_sid_length);//session_regenerate_id(true);
		//$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_authenticated_sessions_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_cookies_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");
		$transBuffer=null;
		$count=0;
		while(list($regvar, $val)=each($_SESSION)){//may transfer
			$transBuffer[$regvar]=$val;
		}
		session_id($issid);
		while(list($regvar, $val)=each($transBuffer)){//but not needed could server_token_finish provide
			$_SESSION[$regvar]=$val;
		}
		$_SESSION[$itsWinId]=$issid;
		$_SESSION["gate_ini"]=$issid;
		$_SESSION[session_name()]=$issid;
		$this->updateSession();*/
	}

	function getSessionCookie($issid){
		$sessionCookie="";
		$result=$this->doTransactionQuery("SELECT `sessionCookie2C` FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '$issid';");
		if($result){
			$arow=mysqli_fetch_array($result, MYSQLI_NUM);
			$sessionCookie=$arow[0];
		}
		return $sessionCookie;
	}


	function smartStoreBackup($md5cookie){
		$md5cookie=$md5cookie!=false?$md5cookie:$this->sessionCookieToken;
		$result1=$this->doTransactionQuery("SELECT `sid` FROM `{$this->perlmut_session_cookies_table}` WHERE `sessionCookie2C` = '$md5cookie';");
		if($result1) if($result1->num_rows>0){
                       $arow=mysqli_fetch_array($result1, MYSQLI_NUM);	
                        $sid=$arow[0];
                               $result3=$this->doTransactionQuery("SELECT DISTINCT `value` FROM `{$this->perlmut_session_vars_table}` WHERE `entryId` = '$sid';");
                               if($result3) if($result3->num_rows>0){
                         $getrow=mysqli_fetch_array($result3, MYSQLI_NUM);	
                            $val=$getrow[0];
                            $resultPrev=$this->doTransactionQuery("SELECT DISTINCT `entryId` FROM `{$this->perlmut_backup_table}` WHERE `sessionCookie2C`='$md5cookie';"); 
                            if($resultPrev){ 
                                    if($resultPrev->num_rows>0){ 
                                            $result2=$this->doTransactionQuery("UPDATE `{$this->perlmut_backup_table}` SET `saveHandlerDump`='" . $val . "' WHERE `sessionCookie2C`='$md5cookie';"); 
                                            if($result2){  

                                            }	 		
                                    }
                            }else{		
                                            $result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_backup_table}` (`parentEntryId`, `sessionCookie2C` , `systemToken` , `saveHandlerDump`, `reregisterVarsList`) VALUES('0', '" . $md5cookie . "', '', '" . $val . "', '*');");
            //q.e.d.
                                    }
                        }
                }
		// virtual cookie backup

		$microtime = microtime();
		$microtimeMillis = strtok($microtime, " ");
		$microtimeSeconds = strtok(" ");

		$resultPrev=$this->doTransactionQuery("SELECT `entryId` FROM `{$this->perlmut_session_store_table}` WHERE `sessionCookie2C`='$md5cookie';"); 
 		if($resultPrev){ 
	 		if($resultPrev->num_rows>0){ 
				$result2=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_store_table}` SET `virtual_cookie`='" . $this->virtualcookie_read() . "' WHERE `sessionCookie2C`='$md5cookie';"); 
				if($result2){  
                               }	 		
			}else{		
				$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_session_store_table}` (`parentEntryId`, `sessionCookie2C`, `systemToken`, `key`, `virtual_cookie`, `timestamp`) VALUES('0', '" . $md5cookie . "', '?itsServ=default', 'any', '" . $this->virtualcookie_read() . "', '" . $microtimeSeconds . "');");
				if($result){
                                        $this->setEnrollStatement();
                                        return true;
                                }else return false;
			}
		}	
                $this->setEnrollStatement(); //TGT
	}

	function restoreSessionData($issid){
		$this->clearExpired($issid);		
		$resultPrev=$this->doTransactionQuery("SELECT DISTINCT `sessionCookie2C` FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '$issid';");
		if($resultPrev) if($resultPrev->num_rows>0){
                    $enrow=mysqli_fetch_array($resultPrev, MYSQLI_NUM);	
                    $sessionCookie2C=$enrow[0];
                }
                $result=$this->doTransactionQuery("SELECT DISTINCT `sid` FROM `{$this->perlmut_session_cookies_table}` WHERE `sessionCookie2C` = '$sessionCookie2C';");
		if($result){ 
                 if($result->num_rows>0){
                        $arow=mysqli_fetch_array($result, MYSQLI_NUM);	
                        if($arow[0]==$issid){
                        	$this->saveSID($arow[0], true);
                         $this->setEnrollStatement();
                        }
                    }
                    $result=$this->doTransactionQuery("SELECT DISTINCT `saveHandlerDump` FROM `{$this->perlmut_backup_table}` WHERE `sessionCookie2C` = '$sessionCookie2C';");
                    $itsrow=mysqli_fetch_array($result, MYSQLI_NUM);
                    $val=$itsrow[0];
		
                    $microtime = microtime();
                    $microtimeMillis = strtok($microtime, " ");
                    $microtimeSeconds = strtok(" ");


                    $result=$this->doTransactionQuery("SELECT `value` FROM `{$this->perlmut_session_vars_table}` WHERE `entryId`='$issid';"); 
                    if($result){ 
                            if($result->num_rows>0){ 
                                    $result2=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_vars_table}` SET `value`='$val', `createTime`=$microtimeSeconds WHERE `entryId`='$issid';"); 
                                    if($result2){  
                                    } 
                            } 
                            else{ 
                                    $result2=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_session_vars_table}` (`entryId`, `value`, `path`, `sessionName`, `createTime`, `sessionCookie2C`) VALUES('$issid', '$val', '{$this->sessionPath}', '{$this->sessionName}', $microtimeSeconds, '$sessionCookie2C');");
                                    if($result2){  
                                    } 
                            } 
                    }else{ 
                            $result2=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_session_vars_table}` (`entryId`, `value`, `path`, `sessionName`, `createTime`, `sessionCookie2C`) VALUES('$issid', '$val', '{$this->sessionPath}', '{$this->sessionName}', $microtimeSeconds, '$sessionCookie2C');");
                            if($result2){  
                            } 
                    }

                    $resultRestore=$this->doTransactionQuery("SELECT `virtual_cookie` FROM `{$this->perlmut_session_store_table}` WHERE `sessionCookie2C`= '$sessionCookie2C';");
                    if($resultRestore){
                            $enrow=mysqli_fetch_array($resultRestore, MYSQLI_NUM);	
                            $virtual_cookie=isSet($enrow[0])?$enrow[0]:"";
                            if(strlen($virtual_cookie)>0)$this->virtualcookie_write($virtual_cookie);
                    }
                }
	}

	function regenerateData(){
		$this->keepData=$this->restoreData;
		return $this->keepData;
	}

	function setCookieToWindowLifetime(){
		$this->restoreData=$this->keepData;
		$this->keepData=-1;
		$this->setSessionCookie(session_id(), false);
	}

	function setCookieExpired(){
		$this->regenerateData();
		$this->setSessionCookie(session_id(), 1);
	}

	function getCurrentUserId(){
		return 0;
	}

	function setSessionCookie($issid, $offset){
		global $conf;

		$sessionCookie="";

		$offset=($offset==false?$this->keepData:($offset>1?$offset:($offset==1?(7200*24)*-1:$this->keepData)));

		$result=$this->doTransactionQuery("SELECT `sessionCookie2C` FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '$issid';");

		if($result) if($result->num_rows==0){

			do{

				$sessionCookie=md5(uniqid(rand()));
			}

			while($this->validCookie($sessionCookie));


			$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_session_cookies_table}` (`sessionCookie2C`, `sid`, `userId`, `rememberLogin`) VALUES('$sessionCookie', '$issid', " . ($this->getCurrentUserId()?$this->getCurrentUserId():0) . ", " . ($this->rememberLogin?"1":"0") . ");");

			if($result){

				$this->sessionCookieToken=$sessionCookie;

			}else{

				return false;

			}

		}else{

			$arow=mysqli_fetch_array($result, MYSQLI_NUM);

			if($result) if($result->num_rows==1) $this->sessionCookieToken=$sessionCookie=$arow[0];
		}

		if($this->isAuthenticated()||$offset==-1) $validUntil=-1; else $validUntil=round(time()) + $offset;

		if(((substr_count($conf["domain"][$this->lang]["domain"], "localhost") == 1)||(isIPV4ADR($_SERVER["HTTP_HOST"])&&isIPV4ADR($conf["domain"][$this->lang]["security"])))||isIPV4ADR($conf["domain"][$this->lang]["domain"])){
			if($this->isAuthenticated()||$offset==-1) session_set_cookie_params($validUntil, $conf["relativeroot"], $conf["domain"][$this->lang]["domain"]);
			setCookie($sessionCookie, time(), $validUntil, false, "", (isSet($_SERVER["HTTPS"])?($_SERVER["HTTPS"]?true:false):false), false);
		}else if(isSubDomainCarry($conf["domain"][$this->lang]["domain"])){
			if($this->isAuthenticated()||$offset==-1) session_set_cookie_params($validUntil, $conf["relativeroot"], $conf["domain"][$this->lang]["domain"]);
			setCookie($sessionCookie, time(), $validUntil, false, $conf["domain"][$this->lang]["domain"], (isSet($_SERVER["HTTPS"])?($_SERVER["HTTPS"]?true:false):false), false);
		}else{
			if($this->isAuthenticated()||$offset==-1) session_set_cookie_params($validUntil, $conf["relativeroot"], (isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"])||isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"])?"":".") . $conf["domain"][$this->lang]["domain"]);
			setCookie($sessionCookie, time(), $validUntil, false, (isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"])||isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"])?"":".") . $conf["domain"][$this->lang]["domain"], (isSet($_SERVER["HTTPS"])?($_SERVER["HTTPS"]?true:false):false), false);
		}
		return true;
	}

	function isAuthenticated(){
		return false;
	}

	function restoreSession($issid){
		$this->restoreSessionData($issid);
		if(sizeof($_COOKIE)>0){
			$itsVal=$this->saveSID($issid, true);
			$this->setEnrollStatement();
			$this->finishAuth();
			return ($itsVal||true)&&$this->setSessionCookie($issid, true)?true:false;
		}
		return false;
	}



	function getSessionIdByCookie(){
		if(sizeof($_COOKIE)>0){
			$sid=hasValidCookie($_COOKIE, false, true);
			if($sid!=null){
				return $sid;
			}
		}
		return "";
	}

	function getHostName(){

		$result=$this->doTransactionQuery("SELECT `hostName` FROM `$this->perlmut_host_table` WHERE `hostIndex`='$this->hostId';");

		if($result) if($result->num_rows==1){

			$row=mysqli_fetch_array($result, MYSQLI_NUM);

			return $row[0];

		}

		return null;

	}

	function setSessionVars($conf, $dbm){
		$this->setDBVars($conf, $dbm);
		$this->EXPIRED=$conf["expired_value"];
		$this->perlmut_session_table=$conf["sessions"];
		$this->perlmut_log_table=$conf["logs"];
		$this->perlmut_counter_table=$conf["counter"];
		$this->session_security_expiration_timeout_in_minutes=$conf["session_security_expiration_timeout_in_minutes"];
		$this->since=$conf["since"];
		$this->perlmut_session_sid_range=$conf["sidsCharRange"];
		$this->perlmut_host_table=$conf["hosts"];
		$this->perlmut_session_vars_table=$conf["sessionVariables"];
		$this->perlmut_session_cookies_table=$conf["sessionCookies"];
		$this->perlmut_backup_table=$conf["splittedBackupTable"];		
		$this->relRoot=$conf["relativeroot"];
		$this->perlmut_session_sid_length=$conf["sidsLength"];
		$hostname=$conf["hostname"];
		$result=$this->doTransactionQuery("SELECT DISTINCT `hostIndex` FROM `$this->perlmut_host_table` WHERE `hostName`='$hostname';");
		$addmem=0;
		if($result){
			$row=mysqli_fetch_array($result, MYSQLI_NUM);
			$addmem=$row[0];
		}		
		$this->hostRelRoot=$conf["relativeroot"];
		$this->hostId=$addmem!=0?$addmem:1;
		$this->sessionExpire=$this->session_security_expiration_timeout_in_minutes;
		$this->perlmut_session_store_table=$conf["sessionStoreData"];
		$this->keepData=$conf["maxCookieLeaseSeconds"];
		$this->maxCookieLease=$conf["maxCookieLeaseSeconds"];
		$this->maxCookieLife=$conf["maxCookieLifetimeSeconds"];
		$this->EXIT_FAILURE=$conf["sessionExitCodeFailure"];
		$this->EXIT_SUCCESS=$conf["sessionExitCodeSuccess"];
		$this->rememberLogin=0;
		$this->sessionName="";
		$this->sessionPath="";
	}



	function Session($conf, $dbm){

		global $lang;

	  	$this->setSessionVars($conf, $dbm);

	  	$hostname=$conf["hostname"];

	  	$result=$this->doTransactionQuery("SELECT * from `$this->perlmut_host_table` WHERE `hostName` = '$hostname';");

		if($result->num_rows>0){

			$enrow = mysqli_fetch_array($result, MYSQLI_ASSOC);

			$this->hostId=$enrow["hostIndex"];

		}else{

			echo $lang["errors"][$this->createHost($conf, $dbm)]["msg"][$this->lang];

		}

	}

	function saveSID($issid, $ov){
		$ov=$ov?$ov:false;
		$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);
		$time=$this->getTime_HH_MM_SS(":");
		$retval=true;
		$sql=$sql2="INSERT INTO `$this->perlmut_session_table` (`sid`, `inheritSid`, `hostId`, `date`, `time`, `virtual_cookie`, `check`) VALUES('$issid', '', " . ($this->hostId?$this->hostId:1) . ", '$date', '$time', '', 0);"; //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers

		if($ov){
			$sql2="SELECT (`sid`) FROM `$this->perlmut_session_table` WHERE `sid`='$issid';";

			$result=$this->doTransactionQuery($sql2);
			if($result){
				if($result->num_rows>0){
					$row=mysqli_fetch_array($result, MYSQLI_NUM);
					$fsid=$row[0];
					$sql2="UPDATE `$this->perlmut_session_table` SET `sid`='$issid', `hostId`=" . ($this->hostId?$this->hostId:1) . ", `date`='$date', `time`='$time', `check`=0 WHERE `sid`='$fsid';"; //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers
					$retval=true;
				}else $retval=false;
			}else $retval=false;
		}
		$result=$retval?$this->doTransactionQuery($sql2):$this->doTransactionQuery($sql);
		if($result){
			session_id($issid);
			return true;
		}else{
			return $retval;
		}
		$this->updateCounter(0);

		return $retval;
	}



	function manageSession($issid, $length, $clear, $gain, $noto, $gateini){
		$restore=true;
		global $lang;
		if(($issid=="")||($issid==$this->EXPIRED)&&!$gateini){

			$nsid=$this->generateSID($length);

			$this->saveSID($nsid, true);

			session_id($nsid);

			$this->setEnrollStatement();

			if(($clear||!$gain)) $this->clearExpired("");

			$this->setEnrollStatement();

		}else{

			if($gain&&!$clear) if($this->clearExpired($issid)){

				$this->setEnrollStatement();

				if($restore){//dec flow on

					if(!$this->restoreSession($issid)){

						//echo $lang["errors"][26]["msg"][$this->lang];

						$this->remove($issid);

						$this->closeDb();

						return false;

					}else{

						session_id($issid);//dec flow on

						if(strcount($lang["greetings"]["scan_sys_reset"][$this->lang], $lang["greetings"]["scan_sys_delimiter"]["sys"], $lang["errors"][26]["msg"][$this->lang])==$lang["combine_clause"]["scan_sys_control"][$this->lang]) $retval=$lang["combine_clause"]["scan_sys_launch"][$this->lang]; else{
						};

						$this->updateSession();

					}



				}
				
			}else{
				$this->setEnrollStatement();
				session_id($issid);

				if($gain) $this->setSessionCookie($issid, false);//got arow

				$this->updateSession();

     		}

		}

		if(($gateini&&$issid!="")&&!$gain) if($this->clearExpired($issid)){

			$this->setEnrollStatement();
			if($restore){//dec flow on

				if(!$this->restoreSession($issid)){

					echo $lang["errors"][22]["msg"][$this->lang];

					$this->remove($issid);
					
					$this->setEnrollStatement();			

					return $retval;

				}

			}

		}

		if($noto) session_start();

		return ((!$gain&&!$gateini)?$issid:session_id()); //st

	}



	function remove($issid){

		$result=$this->doTransactionQuery("DELETE FROM `{$this->perlmut_session_table}` WHERE `sid` = '$issid';");

		if($result&&$issid){

			$result=$this->doTransactionQuery("SELECT `rememberLogin`, `sessionCookie2C` FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '$issid';");

			if($result){

				$arow=mysqli_fetch_array($result, MYSQLI_NUM);

				if($arow[0]>0){

					session_unset();

					session_destroy();

					return true;

				}else{

					$_2c=$arow[1];

					if($_2c!=""){

						$result=$this->doTransactionQuery("DELETE FROM `{$this->perlmut_session_cookies_table}` WHERE `sessionCookie2C` = '$_2c';");

						if($result){

							session_unset();

							if(session_id()) session_destroy();

							return true;

						}

					}

					return false;

				}

			}

		}

		return false;

	}

	function generateSID($idlength){
		$newsid="";
		do{
			$newsid="";
			$charfield=$this->perlmut_session_sid_range;
			$microtime = microtime();
			$microtime = strtok($microtime, " ");
			srand($microtime*1000000);
			while(strlen($newsid)<($idlength)){
				$i=rand(0,strlen($charfield));
				$newsid.=substr($charfield,$i,1);
			}
		}while($this->validSession($newsid));
		return $newsid;
	}

	function validSession($issid){
		$retval2=true;
		$sql="SELECT DISTINCT * FROM `$this->perlmut_session_cookies_table` WHERE `sid`='$issid';";
		$result2=$this->doTransactionQuery($sql);
		if($result2) $retval2=$result2->num_rows > 0; else $retval2=false;
		$sql="SELECT DISTINCT * FROM `$this->perlmut_session_table` WHERE `sid`='$issid';";
		$result=$this->doTransactionQuery($sql);
		$retval=$result->num_rows > 0;
		return $retval||$retval2;
	}



	function createHost($conf, $dbm){
		global $lang;
		$hostname=$conf["hostname"];
		$myDateDb = new DateDB($conf, $dbm);

		$rs=$myDateDb->getRecordSource($dbm["what_dbhost"], $dbm["what_dblogin"], $dbm["what_dbpass"], $dbm["what_dbname"], true);
		if($rs){
			/*LNG blockNr*/echo $lang["errors"][39]["msg"][$myDateDb->lang];
		}else{

			return 10;

		}

		$result55=$myDateDb->doTransactionQuery("SELECT * FROM `{$this->perlmut_host_table}` WHERE `hostname` = '$hostname';");

		if($result55) if($result55->num_rows>0){

			return 11;

		}
					
$indexurl=$conf["domain"][$conf["countryString"]]["url"] . $conf["relativeroot"];
		$result=$myDateDb->doTransactionQuery("INSERT INTO `{$this->perlmut_host_table}` (`hostName`, `indexurl`) VALUES('" . $hostname . "', '" . $indexurl . "');");
		if($result){

				echo $lang["errors"][$this->createAccount($dbm["what_dblogin"], $conf["webmasterEmail"], $dbm["what_dbpass"], $dbm["what_dbpass"], 1)]["msg"][$this->lang];

				echo "<br>" . $lang["errors"][$this->setSuperUserPrivilegeByDBUser($conf, $dbm, $dbm["what_dblogin"])]["msg"][$this->lang];

			return 17;

		}else{

			if($result55->num_rows==0) echo $lang["errors"][40]["msg"][$this->lang];
			//direct output because possibly not matching even errorcode but mysql incompatibility
			return 7;
		}

	}

	function getSID(){
		$sid=session_id();
		return $sid!=""?session_id():$this->EXPIRED;
	}

	function updateSession(){
		$issid=session_id();
		$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);
		$time=$this->getTime_HH_MM_SS(":");
		$sql="UPDATE `{$this->perlmut_session_table}` SET date='$date', time='$time' WHERE `sid`='$issid';";
		$result=$this->doTransactionQuery($sql);
	}

	function clearExpired($issid){
		$query=0;
		$sqls[$query++]="DELETE FROM `$this->perlmut_session_table` WHERE `sid`='#id';";
		return $this->_clearExpired($issid, $sqls, 0, $this->sessionExpire);
	}

	function _clearExpired($issid, $queries, $mode, $timeout){
		$sql="SELECT * FROM `$this->perlmut_session_table` WHERE `hostId`= '$this->hostId';";
		$sqlarray=null;
		$result=$this->doTransactionQuery($sql);
		$i=0;
		//read every row into array zeile
		$row=null;
		$zeile=null;
		if($result) while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){
			$zeile[$i]=$row;
			$i++;
		}
		$online=0;
		$expired=false;
		$cleared=true;
		$dateNtime=getDate();
		$year=$dateNtime["year"];
		if((($year%4)==0)&&!(($year%100==0)&&($year%400>0))){//
				$this->calendar["Greogorian"][1]["days"]=29;
		}
		$query=0;
		if($zeile!=null) for ($v=0; $v < sizeof($zeile); $v++){ //zoule 1
		 	$date=$this->hackDate($zeile[$v]["date"], "-", "mon", "mday", "year");
			$time=$this->hackTime($zeile[$v]["time"], ":");
			//***
			$control=$zeile[$v]["time"];
			//***
			if($date["mon"]==$dateNtime["mon"]-1&&$date["mday"]==$this->calendar["Greogorian"][$date["mon"]]["days"]){
				$lastmon1=$date["mon"];
				$days=0;
			}else{
				if($date["mon"]>1){
					$lastmon1=$date["mon"]-1;
				}
				else{
					$lastmon1=11;
				}
				$days=$this->calendar["Greogorian"][$lastmon1]["days"]+1;
			}
			if($dateNtime["mon"]>1){
				$lastmon2=$dateNtime["mon"]-1;
			}else{
				$lastmon2=11;
			}
			$daysAct=$this->calendar["Greogorian"][$lastmon2]["days"]+1;
			while($lastmon1!=$lastmon2){
				$lastmon2--;
				if($lastmon2==0){
					$lastmon2=11;
				}
				$daysAct+=$this->calendar["Greogorian"][$lastmon2]["days"]+1;
			}
			$lastAccessTime=((($days+$date["mday"]-1)*24)+$time["hours"])*60 + $time["minutes"];
			//lastAccessTime fasst nun alle Minuten des Monats (ein monat vor zugriff) davor bis zu dem beginn des aktuellen monats und dessen Minuten zusammen
			$systemTime=((($daysAct+$dateNtime["mday"]-1)*24)+$dateNtime["hours"])*60 + $dateNtime["minutes"];
			//***smart Backup
			$id=$zeile[$v]["sid"];

			$resultCookie=$this->doTransactionQuery("SELECT `sessionCookie2C` from `{$this->perlmut_session_cookies_table}` WHERE `sid`='$id';");
			if($resultCookie) $rowCookie=mysqli_fetch_array($resultCookie, MYSQLI_ASSOC);
			$cookieToken=$rowCookie["sessionCookie2C"];
			if ($issid==$zeile[$v]["sid"]){
				$cleared=false;
			}
			if ($lastAccessTime < ($systemTime-$timeout)){
				if($issid==$zeile[$v]["sid"]){
					$expired=true;
					//same sessions					
					$this->smartStoreBackup(false);				
				}else{
					//other sessions					
					$this->smartStoreBackup($cookieToken);				
				}
				$case=$zeile[$v]["check"]==$mode?true:false;
				if($mode>=1){
					$result=$this->doTransactionQuery("SELECT `userId` FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `sid`='$id';");
					if($result){
						if($result->num_rows>0){
							$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
							$user=$enrow[0];
						}
					}
				}

				if($case){
					if ($issid==$zeile[$v]["sid"]){
						$expired=true;
					}

					if($queries!=null){
						for($t=0; $t < sizeof($queries); $t++){
							$posA=strpos($queries[$t], "#");
							$posB=strpos(substr($queries[$t], $posA, strlen($queries[$t])-$posA), "'");
							$len=posB-1;
							$posB+=$posA;
							$search=substr($queries[$t], $posA, $posB-$posA);
							$var=substr($queries[$t], $posA+1, $len);
							$str=${$var};
							$sqlarray[$query++]=substr($queries[$t], 0, $posA) . $str . substr($queries[$t], $posB, strlen($queries[$t])-$posB);
						}

						for ($i=0; $i < sizeof($sqlarray); $i++){
							$result3=$this->doTransactionQuery($sqlarray[$i]);
							//if($result3)
							//if($result3->num_rows>0){
								//mysqli_free_result($result3);
							//}

						}
					}
				}

			}else {

				$online++;

			}

		}



		if(!$cleared){
			$this->updateCounter($online);
		}
		return ($cleared||$expired);
	}

	function updateCounter($online){
		$issid=session_id();
		$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);
		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_counter_table` WHERE `date`='$date' AND `sid`='$issid';");
		if($result){
			if($result->num_rows == 0){
				$IP=$_SERVER["REMOTE_ADDR"];
				$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_counter_table` (`hostId`, `date`, `sid`, `ip`) VALUES($this->hostId, '$date', '$issid', '$IP');");
			}
		}

		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_counter_table` WHERE `date`='$date' AND `hostId` = '$this->hostId';");
		$this->day_counter=$result->num_rows;
		//since vcounter
		//$sql="SELECT * FROM `$this->perlmut_counter_table` WHERE `date` between '$this->since' and '$date';";
		//$result=$this->doTransactionQuery($sql);
		//VisitorCounter
		$result=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_counter_table}` WHERE `hostId` = '$this->hostId';");
		$this->counter=$result->num_rows;
		//current Visitor Counter
       	$this->current_counter=$online;
	}

	function virtualcookie_write($data){
		$issid=session_id();
		$sql="UPDATE `$this->perlmut_session_table` SET `virtual_cookie`='$data' WHERE sid='$issid';";
		$result=$this->doTransactionQuery($sql);
		if($result){
                    $this->setEnrollStatement();
                    return true;
                }
		return false;
	}

	function virtualcookie_append($data){
		$existing_data=$this->virtualcookie_read();
		$data=$existing_data . $data;
		return $this->virtualcookie_write($issid, $data);
	}

	function virtualcookie_read(){
		$issid=session_id();
		$sql="SELECT `virtual_cookie` FROM `$this->perlmut_session_table` WHERE sid='$issid';";
		$result=$this->doTransactionQuery($sql);
		if($result){
			$row=mysqli_fetch_array($result, MYSQLI_NUM);
		}else{
			$row="";
		}
		return $row[0];
	}

	function createAccount($username, $email, $password, $passwordRepeat, $simultan){//beta 2
		if($username){
			if($email){
				$pattern="_\A[\w!#$%&'*+/=?`{|}~^-]+(?:\.[\w!#$%&'*+/=?`{|}~^-]+)*@?(?:[A-Z0-9-]+\.)+[A-Z]{2,99}\Z_";;
				if(preg_match($pattern, strtoupper($email))){
					if($password!=null){
						if($passwordRepeat!=null){
							if($password!=$passwordRepeat){
								return	6;
							}
						}else{
							return 5;
						}
					}else{
						return 4;
					}
				}else{
					return 3;
				}
			}else{
				return 2;
			}
		}else{
			return 1;
		}
		
		$username=stripQueryChars($username);
		$result=$this->doTransactionQuery("SELECT * from `$this->perlmut_user_table` WHERE `name`='$username' AND `hostId` = '$this->hostId';");
		if($result!=null){
			if($result->num_rows>0){
				return 8;
			}
		}
			$email=stripQueryChars($email);
			$pwd=md5($password);
			$home=$this->relRoot . "/" . $username;
			$cdate=$this->formatDate($this->getDate(getDate(), null, null, false), "MMDDYYYY", false);
			$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_user_table` (`email`, `sinceDate`, `lastLoginDate` , `lastLoginTime` , `name`, `homeDir`, `hostId`, `status`, `simultanConx`) VALUES('$email', '$cdate', '', '', '$username', '$home', " . ($this->hostId?$this->hostId:1) . ", '0', '$simultan');");
			if($result){
				$result=$this->doTransactionQuery("SELECT `userId` FROM `$this->perlmut_user_table` WHERE `name` = '$username' AND `hostId` = '$this->hostId';");
				$issid=session_id();
				$userId=0;
				if($result) {
					if($result->num_rows>0){
						$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
						$userId=$enrow[0];
					} else $userId=1;
				} else $userId=1;
				$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_auth_table` (`userId`, `passwordMD5`) VALUES($userId, '$pwd');");
				if($result){
					return 0;
				}else{
					return 7;
				}
			}else{
				return 7;
			}
	}
}

class SecureHandler{
	var $filename="";
	var $path="";
	var $header="";
	var $tmpPath="";
	var $stamp=null;
	var $has=false;

	function SecureHandler($recId, $prefix, $tmpPath, $filename, $path, $header, $content){
		global $include;
		$pparts=pathinfo($filename);
		$this->filename=$filename;
		$this->path=$path;
		$this->header=$header;
		$isReg=isSet($_SESSION[$prefix . $recId])?$_SESSION[$prefix . $recId]:false;
		if($isReg){
			//$_SESSION[$prefix . $recId]=$isReg;
		}else{
			$isReg="TMP" . md5($filename) . uniqId() . md5(session_id());
			$_SESSION[$prefix . $recId]=$isReg;
		}
		$tmpFile=$tmpPath . "/" . $isReg . "." . $pparts["extension"];
		if(file_exists($tmpFile)){
			$this->has=true;
		}else{
			$strcmt=false;

			$content=str_ireplace("#DOL#", "$", $content);

			$content=str_ireplace("#ESCAPEDSINGLEQUOTE#", "\'", $content);

			$content=str_ireplace("#SINGLEQUOTE#", "'",  $content);

			$content=str_ireplace("#ESCAPEDQUOTE#", "\\\"", $content);

			$content=str_ireplace("#SEMICOLON#", ";", $content);

			$content=str_ireplace("#QUOTE#", "\"", $content);

			$content=str_ireplace("#BOUNDEDESCAPEDQUOTE#", "\\\\\\\"", $content);

			$content=str_ireplace("#PREPROCIN#", "<?php", $content);

			$content=str_ireplace("#PREPROCOUT#", "?>", $content);

			if($pparts["extension"]=="js") $strcmt=true;

			$content=str_ireplace("#COMMENT#", "//", $content);

			$content=str_ireplace("#NL#", "\n", $content);

			$content=str_ireplace("#TAB#", "\t", $content);

			$content=str_ireplace("#PRESET#", "\\", $content);

			$content=str_ireplace("#ESCPRESET#", "\\\\", $content);

			//***deletes comments

			$decimated=$content;

			$foundcmt=true;

			$delim=null;

			$include="";

			$delim[0]="#CMTIN#";

			$delim[1]="#CMTOUT#";

			$count=0;



			while($foundcmt){

				$foundcmt=false;

				$a=-1;

				$foundcmt=(striposi($decimated, $delim[0])==-1)?$foundcmt:true;//GREETINGS EARTH DRAIN WE HAVE NOW TAKEN OVER YOUR RADIO

				if($foundcmt){

					$a=strpos($decimated, $delim[0]);

					$decimated=substr($decimated, 0, $a) . substr($decimated, (striposi($decimated, $delim[1])+strlen($delim[1])), strlen($decimated)-(striposi($decimated, $delim[1]))-strlen($delim[1]));

				}

				$foundcmt=false;//Are the spongebobs a fool -> c'est frai <- dont't they

				$count++;



			}

			//2BC <!-- HTML COMMENT--> /* PHP||JS COMMENT */

			//$strcmt=true;

			$content=$decimated;

			if(!$strcmt){

				$content=str_ireplace("#CMTIN#", "/*", $content);//but senseless it may work now

				$content=str_ireplace("#CMTOUT#", "*/", $content);//but senseless it may work now

			}
			//***deletes comments

		require("./copysights.php");

		if($strcmt){

			$include=str_ireplace("#CMTIN#", "/*", $include);

			$include=str_ireplace("#CMTOUT#", "*/", $include);

		}


		$tmpFileHandler = fopen ($tmpFile, "w+");

		fputs($tmpFileHandler, ($strcmt?$include:"") . $content);

		fclose($tmpFileHandler);

		}
		$this->stamp=$tmpFile;

		return false;

	}



	function getStamp(){
		return $this->stamp;

	}



	function readyStamp(){

		return $this->has;

	}

}



class SecureSession extends Session{
	var $since=-1;
	var $counter=-1; //total means different conx since
	var $current_counter=-1;
	var $day_counter=-1;
	var $perlmut_session_table=null;
	var $perlmut_session_cookies_table=null;
	var $perlmut_host_table=null;
	var $perlmut_log_table=null; //not implemented yet
	var $perlmut_counter_table=null;
	var $session_security_expiration_timeout_in_minutes=-1;
	var $perlmut_session_sid_range=null;
	var $perlmut_session_sid_length=null;
	var $perlmut_images_table=null; //not implemented yet
	var $perlmut_secureStunt_table=null;
	var $perlmut_secureStunt_temp_path="";
	var $hostRelRoot=null;
	var $hostId=1;
	var $relRoot="";
	var $EXPIRED=null;
	var $parent=null;
	var $tmpSecHandler=null;
	var $prefix="_tmp_sec_ses";
	var $perlmut_secureHash2SID_table;
	var $sessionCookieToken="";

	function SecureSession($conf, $dbm){
		$this->parent=get_parent_class($this);
		parent::Session($conf, $dbm);
	}

	function getSessionByPPDSid($bsid){
		$result=$this->doTransactionQuery("SELECT DISTINCT `sid` FROM`{$this->perlmut_session_table}` WHERE `inheritSid`='" . $bsid ."';");
		if($result){
			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
			if($result->num_rows>0) return $enrow[0];
			return "";
		}
		return "";
	}



	function savePPDSid($gambleSid){
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_table}` SET `inheritSid`='$gambleSid' WHERE `sid`='" . session_id() ."';"); //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers
		if($result) return true;
		return false;
	}



	function setSessionVars($conf, $dbm){
		parent::setSessionVars($conf, $dbm);
		$this->EXPIRED=$conf["expired_value"];
		$this->perlmut_secureStunt_table=$conf["securityStunt"];
		$this->perlmut_secureStunt_temp_path=$conf["tmpSessionPath"];
		$this->perlmut_secureHash2SID_table=$conf["SecSesHash2SID"];
	}
	

	//server_token_finish provide

	function finishSecureSession($ary, $key){

/*		$osid=session_id();

		$issid=$this->generateSID($this->perlmut_session_sid_length);//session_regenerate_id(true);

		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_authenticated_sessions_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");

		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");

		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_cookies_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");

		$transBuffer=null;

		$count=0;

		while(list($regvar, $val)=each($_SESSION)){//may transfer

			$transBuffer[$regvar]=$val;

		}*/

		/*session_id($issid);

		$_SESSION["gate_ini"]=$issid;while(!isSet($_SESSION["gate_ini"])){ ; }

		/*while(list($regvar, $val)=each($transBuffer)){//but not needed could server_token_finish provide

			$_SESSION[$regvar]=$val;

		}

		$this->updateSession();

		*/

		return $issid;

	}

	function getTmpRecordId($name, $path){
		$result=$this->doTransactionQuery("SELECT DISTINCT `passThroughId` FROM `{$this->perlmut_secureStunt_table}` WHERE `fileName`='" . $name . "' AND `path`='" . $path. "';");
		if($result){
			if($result->num_rows>0){
				$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
				$recId=$enrow[0];
			}else{
				return false;
			}
		}else{
			return false;
		}
		return $recId;
	}

	function getOutputHHTPHeader($name, $path){
		$result=$this->doTransactionQuery("SELECT DISTINCT `header` FROM `{$this->perlmut_secureStunt_table}` WHERE `fileName`='" . $name . "' AND `path`='" . $path. "';");
		if($result){
			if($result->num_rows>0){
				$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
				$header=$enrow[0];
			}else{
				return false;
			}
		}else{
			return false;
		}
		return $header;
	}

	function prepareRequest(){
		$result=$this->doTransactionQuery("SELECT `passThroughId`, `fileName`, `path`, `header`, `deliveryStunt`, `ph` FROM `{$this->perlmut_secureStunt_table}` WHERE 1;");
		if($result){
			if($result->num_rows>0){
				while($enrow=mysqli_fetch_array($result, MYSQLI_ASSOC)){
					$tmpSecHandler=new SecureHandler($enrow["passThroughId"], $this->prefix, $this->perlmut_secureStunt_temp_path, $enrow["fileName"], $enrow["path"], $enrow["header"], $enrow["deliveryStunt"]);
					if(!$tmpSecHandler->readyStamp()){
						$pparts=pathinfo($tmpSecHandler->getStamp());
						$result2=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_secureHash2SID_table}` (`sid`, `passThroughId`, `tmpFileName`, `tmpFilePath`) VALUES('" . session_id() . "', '" . $enrow["passThroughId"] . "', '" . $pparts["filename"] . "." . $pparts["extension"] . "', '" . $pparts["dirname"] . "')");
					}
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
		return true;
	}

	function getMirror($name, $path, $ph){
		$this->prepareRequest();
		$pparts=pathinfo($name);
		$path=stripQueryChars($path);
		mirrorOut($this->getOutputHHTPHeader($name, $path), $this->perlmut_secureStunt_temp_path, $this->prefix, $this->getTmpRecordId($name, $path), $pparts["extension"], $ph);
	}



	function clearExpired($issid){
		$retval=parent::clearExpired($issid);
		$query=0;
		$sqls=null;
		//$sqls[$query++]="DELETE FROM `$this->perlmut_session_table` WHERE `sid`='#id';";
		//due to super call may be not needed but seems to be affected
		return $retval&&$this->_clearExpired($issid, $sqls, 1, $this->sessionExpire);
	}

	function _clearExpired($issid, $queries, $mode, $timeout){
		$sql="SELECT * FROM `$this->perlmut_session_table` WHERE `hostId`= '$this->hostId';";
		$sqlarray=null;
		$result=$this->doTransactionQuery($sql);
		$i=0;
		//read every row into array zeile
		$row=null;
		$zeile=null;
		if($result) while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){
			$zeile[$i]=$row;
			$i++;
		}
		$online=0;
		$expired=false; //important for the users session
		$cleared=true; //switches to false when SID value was found
		$dateNtime=getDate();
		$year=$dateNtime["year"];
		if((($year%4)==0)&&!(($year%100==0)&&($year%400>0))){//
				$this->calendar["Greogorian"][1]["days"]=29;
		}
		$query=0;
		if($zeile!=null) for ($v=0; $v < sizeof($zeile); $v++){
		 	$date=$this->hackDate($zeile[$v]["date"], "-", "mon", "mday", "year");
			$time=$this->hackTime($zeile[$v]["time"], ":");
			//***
			$control=$zeile[$v]["time"];
			//***
			if($date["mon"]==$dateNtime["mon"]-1&&$date["mday"]==$this->calendar["Greogorian"][$date["mon"]]["days"]){
				$lastmon1=$date["mon"];
				$days=0;
			}else{
				if($date["mon"]>1){
					$lastmon1=$date["mon"]-1;
				}
				else{
					$lastmon1=11;
				}
				$days=$this->calendar["Greogorian"][$lastmon1]["days"]+1;
			}
			if($dateNtime["mon"]>1){
				$lastmon2=$dateNtime["mon"]-1;
			}else{
				$lastmon2=11;
			}

			$daysAct=$this->calendar["Greogorian"][$lastmon2]["days"]+1;

			while($lastmon1!=$lastmon2){
				$lastmon2--;

				if($lastmon2==0){

					$lastmon2=11;

				}

				$daysAct+=$this->calendar["Greogorian"][$lastmon2]["days"]+1;

			}

			$lastAccessTime=((($days+$date["mday"]-1)*24)+$time["hours"])*60 + $time["minutes"];

			//springt mit der konf??derierten Sternenflotte ins Schwimm

			$systemTime=((($daysAct+$dateNtime["mday"]-1)*24)+$dateNtime["hours"])*60 + $dateNtime["minutes"];

			//***smart Backup
			$id=$zeile[$v]["sid"];

			$resultCookie=$this->doTransactionQuery("SELECT `sessionCookie2C` from `{$this->perlmut_session_cookies_table}` WHERE `sid`='$id';");
			if($resultCookie) $rowCookie=mysqli_fetch_array($resultCookie, MYSQLI_ASSOC);
			$cookieToken="";
                        if($rowCookie!=null) $cookieToken=$rowCookie["sessionCookie2C"];
			if ($issid==$zeile[$v]["sid"]){
				$cleared=false;
			}
			if ($lastAccessTime < ($systemTime-$timeout)){
				if($issid==$zeile[$v]["sid"]){
					$expired=true;
					//same sessions					
					$this->smartStoreBackup(false);				
				}else{
					//other sessions					
					$this->smartStoreBackup($cookieToken);				
				}
				$case=$zeile[$v]["check"]==$mode?true:false;

				if($mode>=1){

					$result=$this->doTransactionQuery("SELECT DISTINCT `userId` FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `sid`='$id';");

					$user=null;

					if($result){
						if($result->num_rows>0){
							$enrow=mysqli_fetch_array($result, MYSQLI_NUM);
							$user=$enrow[0];
						}
					}
				}

				if($case){
					if ($issid==$zeile[$v]["sid"]){
						$expired=true;
					}
					//**DELETE OF TMP_CACHE
							$flo=$this->doTransactionQuery("SELECT `passThroughId`, `tmpFileName`, `tmpFilePath` FROM `{$this->perlmut_secureHash2SID_table}` WHERE `sid`='" . $id . "';");
							if($flo){
								if($flo->num_rows>0){
									while($enrow=mysqli_fetch_array($flo, MYSQLI_ASSOC)){
										$pparts=pathinfo($enrow["tmpFilePath"] . "/" . $enrow["tmpFileName"]);
										mirrorOff($pparts["dirname"], $pparts["basename"]);
									}
								$flo2=$this->doTransactionQuery("DELETE FROM `{$this->perlmut_secureHash2SID_table}` WHERE `sid`='" . $id . "';");
								}else{
									;
								}
							}else{
								;
							}
					//***
					if($queries!=null){
						for($t=0; $t < sizeof($queries); $t++){
							$posA=strpos($queries[$t], "#");
							$posB=strpos(substr($queries[$t], $posA, strlen($queries[$t])-$posA), "'");
							$len=$posB-1;
							$posB+=$posA;
							$search=substr($queries[$t], $posA, $posB-$posA);
							$var=substr($queries[$t], $posA+1, $len);
							$str=${$var};
							$sqlarray[$query++]=substr($queries[$t], 0, $posA) . $str . substr($queries[$t], $posB, strlen($queries[$t])-$posB);
						}
						for ($i=0; $i < sizeof($sqlarray); $i++){
							$result3=$this->doTransactionQuery($sqlarray[$i]);
							//if($result3) @mysqli_free_result($result);
						}
					}
				}
			}else {
				$online++;
			}
		}
		if(!$cleared){
			$this->updateCounter($online);
		}
		return ($cleared||$expired);
	}
}

class AuthSession extends SecureSession{
	var $perlmut_user_table=null;
	var $perlmut_auth_table=null;
	var $perlmut_authenticated_sessions_table=null;
	var $perlmut_priv_table=null;
	var $personal_data_synth=null;
	var $personal_data_table=null;
	var $autoLogoutTime=null;
	var $hostId=1;
	var $errors=null;

	function AuthSession($conf, $dbm){
		global $lang;
                $this->parent=get_parent_class($this);
		parent::SecureSession($conf, $dbm);
		$this->setAuthSessionVars($conf, $dbm);
		$hostname=$conf["hostname"];
		$result=$this->doTransactionQuery("SELECT DISTINCT * from `$this->perlmut_host_table` WHERE `hostName` = '$hostname';");
		if($result->num_rows>0){
			$enrow = mysqli_fetch_array($result, MYSQLI_ASSOC);
			$this->hostId=$enrow["hostIndex"];
		}else{
			echo $lang["errors"][$this->createHost($conf, $dbm)]["msg"][$this->lang];
		}
	}

	function getCurrentUserName(){//usernames are once for all perlmut hosts on a physical host
		$issid=session_id();
		$result=$this->doTransactionQuery("SELECT `userId` FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `sid` = '$issid';");
		if($result){
			$row=mysqli_fetch_array($result, MYSQLI_NUM);
			if($row){
				$uid=$row[0];
				$result=$this->doTransactionQuery("SELECT `name` FROM `{$this->perlmut_user_table}` WHERE `userId` = '$uid';");
			}
			if($result){
				if($result->num_rows>0){//IF ONE
					$row=mysqli_fetch_array($result, MYSQLI_NUM);
					return $row[0];
				}
			}
		}
		return null;
	}



	function finishAuth(){
		/*$osid=session_id();
		$issid=$this->generateSID($this->perlmut_session_sid_length);//session_regenerate_id(true);
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_authenticated_sessions_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_cookies_table}` SET `sid` = '$issid' WHERE `sid` = '$osid';");
		$transBuffer=null;
		$count=0;
		while(list($regvar, $val)=each($_SESSION)){//may transfer
			$transBuffer[$regvar]=$val;
		}
		session_id($issid);
		while(list($regvar, $val)=each($transBuffer)){//but not needed could server_token_finish provide
			$_SESSION[$regvar]=$val;
		}
		$_SESSION[$itsWinId]=$issid;
		$_SESSION["gate_ini"]=$issid;
		$_SESSION[session_name()]=$issid;
		$this->updateSession();*/
	}

	function updateSession(){
		$issid=session_id();
		$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);
		$time=$this->getTime_HH_MM_SS(":");
		$sql="UPDATE `{$this->perlmut_session_table}` SET date='$date', time='$time' WHERE `sid`='$issid';";
		$result=$this->doTransactionQuery($sql);
		$userId=$this->getUserIdByLogonCookie();
		$sql="SELECT `rememberLogin` FROM `{$this->perlmut_session_cookies_table}` WHERE `sid`='$issid' AND `userId` = '$userId';";
		$result2=$this->doTransactionQuery($sql);
		if($result2){
			$itsFlagA=$result2->num_rows>=1?true:false;
			if($itsFlagA){
				$itsFlag=mysqli_fetch_array($result2, MYSQLI_NUM);
				$this->rememberLogin=$itsFlag[0]==1?true:false;
			}
		}
		if($this->rememberLogin) $this->setSessionCookie($issid, $this->regenerateData());
	}

	function getUserIdByLogonCookie(){
		$sql="SELECT `userId` FROM `{$this->perlmut_session_cookies_table}` WHERE `sessionCookie2C`='{$this->sessionCookieToken}';";
		$result=$this->doTransactionQuery($sql);
		$itsRow=null;
		if($result) if($result->num_rows>=0) $itsRow=mysqli_fetch_array($result, MYSQLI_ASSOC);
		if($itsRow!=null) return $itsRow["userId"];
		return -1;
	}

	function accountingForm($issid, $size, $errcode, $personalInfoDescription){
		global $lang;
		global $overrideUsername;
		$this->personal_data_synth;
		$this->personal_data_table;
		echo "<TABLE cellspacing=\"0\" cellpadding=\"0\" class=\"accountingFormTable\">";
		if(sizeof($errcode)>0) if(isSet($errcode["global"])){
			echo "<TR><TD cellspan=\"2\"><p class=\"error\">" . $lang["errors"][$errcode["global"]]["msg"][$this->lang] . "</p></TD></TR>";
		}
		if(sizeof($errcode)>0) if(isSet($errcode["username"])){
			echo "<TR><TD cellspan=\"2\"><p class=\"error\">" . $lang["errors"][$errcode["username"]]["msg"][$this->lang] . "</p></TD></TR>";
		}
		if(!$overrideUsername){
			echo "<TR><TD>" . $this->personal_data_synth["username"]["prompt"][$this->lang] . "</TD>";
			echo "<TD><INPUT value=\"" . $_SESSION["username"] . "\" name=\"username\" type=\"text\" size=\"$size\" maxlength=\"64\"></TD>";
			echo "</TR>";
		}

		if(sizeof($errcode)>0) if(isSet($errcode["password"])){
			echo "<TR><TD cellspan=\"2\"><p class=\"error\">" . $lang["errors"][$errcode["password"]]["msg"][$this->lang] . "</p></TD></TR>";
		}

		if($this->personal_data_synth["password"]["dutyfield"]&&$this->personal_data_synth["password"]["caption"]=="password"){
			echo "<TR><TD>" . $lang["prompts"][2]["msg"][$this->lang] . "</TD>";
			echo "<TD><INPUT name=\"password1\" type=\"password\" size=\"$size\" maxlength=\"32\"></TD>";
			echo "</TR>";
			echo "<TR><TD>" . $lang["prompts"][3]["msg"][$this->lang] . "</TD>";
			echo "<TD><INPUT value=\"\" name=\"password2\" type=\"password\" size=\"$size\" maxlength=\"32\"></TD>";
			echo "</TR>";
		}else{
			echo "<INPUT name=\"password1\" type=\"hidden\" size=\"" . $this->personal_data_synth["password"]["maxlength"] . "\" maxlength=\"32\" value=\"" . $this->personal_data_synth["password"]["options"][0]["value"] . "\">";
			echo "<INPUT name=\"password2\" type=\"hidden\" size=\"" . $this->personal_data_synth["password"]["maxlength"] . "\" maxlength=\"32\" value=\"" . $this->personal_data_synth["password"]["options"][0]["value"] . "\">";
		}
		if(sizeof($errcode)>0) if(isSet($errcode["email"])){
			echo "<TR><TD cellspan=\"2\"><p class=\"error\">" . $lang["errors"][$errcode["email"]]["msg"][$this->lang] . "</p></TD></TR>";
		}
		echo "<TR><TD>" . $lang["prompts"][0]["msg"][$this->lang] . "</TD>";
		echo "<TD><INPUT value=\"" . $_SESSION["email"] . "\" name=\"email\" type=\"text\" size=\"$size\" maxlength=\"255\"></TD>";
		echo "</TR>";
		if(sizeof($errcode)>0) if(isSet($errcode["emailRetype"])){
			echo "<TR><TD cellspan=\"2\"><p class=\"error\">" . $lang["errors"][$errcode["emailRetype"]]["msg"][$this->lang] . "</p></TD></TR>";
		}
		echo "<TR><TD>" . $lang["prompts"][5]["msg"][$this->lang] . "</TD>";
		echo "<TD><INPUT value=\"" . $_SESSION["emailRetype"] . "\" name=\"emailRetype\" type=\"text\" size=\"$size\" maxlength=\"255\"></TD>";
		echo "</TR>";
		echo "</TABLE>";
		echo "<FIELDSET>";
		echo "<TABLE cellspacing=\"0\" cellpadding=\"0\" class=\"accountingFormTable\">";
		echo "<LEGEND>$personalInfoDescription</LEGEND>";
		for($v=0; $v< sizeof($this->personal_data_synth); $v++){
			if(sizeof($errcode)>0) if(isSet($errcode[$this->personal_data_synth[$v]["caption"]])){
				echo "<TR><TD cellspan=\"2\"><p class=\"error\">" .  $lang["errors"][$errcode[$this->personal_data_synth[$v]["caption"]]]["msg"][$this->lang] . "</p></TD></TR>";
			}
			echo "<TR>";
			echo "<TD>";
			echo $this->personal_data_synth[$v]["prompt"][$this->lang];
			echo "</TD>";
			echo "<TD>";
			if($this->personal_data_synth[$v]["formElement"]=="text"){
				$val="";
				if(sizeof($_POST)>0){
					$val=isSet($_SESSION[$this->personal_data_synth[$v]["caption"]])?$_SESSION[$this->personal_data_synth[$v]["caption"]]:"";
				}
				echo "<input type=\"text\" size=\"$size\" maxlength=\"" . $this->personal_data_synth[$v]["maxlength"] . "\" name=\"" . $this->personal_data_synth[$v]["caption"] .  "\" value=\"$val\">";
			}else if($this->personal_data_synth[$v]["formElement"]=="select"){
				//SELECT
				echo "<SELECT name=\"". $this->personal_data_synth[$v]["caption"] ."\">\n";
					if(sizeof($this->personal_data_synth[$v]["options"])>0){
						for($s=0; $s < sizeof($this->personal_data_synth[$v]["options"]); $s++){
							echo "<OPTION value=\"" . $this->personal_data_synth[$v]["options"][$s]["value"] . "\">" . $this->personal_data_synth[$v]["options"][$s]["caption"] . "</OPTION>\n";
						}
					}else{
						$result=$this->doTransactionQuery($this->personal_data_synth[$v]["selection"]["query"]);
						if($result){
							while($arow=mysqli_fetch_array($result, MYSQLI_ASSOC)){
								$sel=$arow[$this->personal_data_synth[$v]["selection"]["valueField"]]==$_POST[$this->personal_data_synth[$v]["caption"]]?" selected":"";
								echo "\n<OPTION value=\"" . $arow[$this->personal_data_synth[$v]["selection"]["valueField"]] . "\"$sel>". $arow[$this->personal_data_synth[$v]["selection"]["captionField"]] . "</OPTION><BR>";
							}
						}
					}
				echo "</SELECT>";
			}
			echo "</TD>";
			echo "</TR>";
		}
		echo "</TABLE>";
		echo "</FIELDSET>";
		echo "<INPUT type=\"submit\" value=\"" . $lang["buttons"]["send"]["caption"][$this->lang] . "\">";
	}

	function processingAccountingForm($issid, $size, $personalInfoDescription){
		global $overrideUsername;
		$errCodes=null;
		if(!$overrideUsername){
			if($_POST["username"]==""){
				$errCodes["username"]=1;
			}
		}

		if($_POST["password1"]!=$_POST["password2"]){
			$errCodes["password"]=6;
		}

		if($_POST["password1"]==""){
			$errCodes["password"]=4;
		}else if($_POST["password2"]==""){
			$errCodes["password"]=5;
		}

		if(!isSet($errCodes["password1"])&&!isSet($errCodes["password2"])){
			echo "<INPUT type=\"hidden\" value=\"" . $_POST["password1"] . "\" name=\"password1\">";
			echo "<INPUT type=\"hidden\" value=\"" . $_POST["password2"] . "\" name=\"password2\">";
		}

		//2BC wg passwort consistence
		$pattern="_\A[\w!#$%&'*+/=?`{|}~^-]+(?:\.[\w!#$%&'*+/=?`{|}~^-]+)*@?(?:[A-Z0-9-]+\.)+[A-Z]{2,99}\Z_";

		if($_POST["email"]==""){
			$errCodes["email"]=2;
		}else if(!preg_match($pattern, strtoupper($_POST["email"]))){
			$errCodes["email"]=3;
		}
		if(!isSet($errCodes["email"])){
			$_SESSION["email"]=$_POST["email"];
			echo "<INPUT type=\"hidden\" value=\"" . $_SESSION["email"] . "\" name=\"email\">";
		}
		if($_POST["emailRetype"]==""){
			$errCodes["emailRetype"]=38;
		}else if(!preg_match($pattern, strtoupper($_POST["emailRetype"]))){
			$errCodes["emailRetype"]=3;
		}else if($_POST["emailRetype"]!=$_POST["email"]){
			$_SESSION["emailRetype"]=$_POST["emailRetype"];
			$errCodes["emailRetype"]=37;
		}

		if(!isSet($errCodes["emailRetype"])){
			echo "<INPUT type=\"hidden\" value=\"" . $_SESSION["emailRetype"] . "\" name=\"emailRetype\">";
		}

		for($v=0; $v< sizeof($this->personal_data_synth); $v++){
			if($this->personal_data_synth[$v]["dutyfield"]){
				if($_POST[$this->personal_data_synth[$v]["caption"]]==""){
					$errCodes[$this->personal_data_synth[$v]["caption"]]=36;
				}else{
					$_SESSION[$this->personal_data_synth[$v]["caption"]]=$_POST[$this->personal_data_synth[$v]["caption"]];
					echo "<INPUT type=\"hidden\" value=\"" . $_SESSION[$this->personal_data_synth[$v]["caption"]] . "\" name=\"" . $this->personal_data_synth[$v]["caption"] . "\">";
				}
			}
		}

		if($errCodes==null){
			return true;
		}else{
			if(!$overrideUsername&&$errCodes["username"]!=1){
				$errCodes["username"]=$this->checkUsername($_POST["username"]);
			}
		}
		$this->accountingForm($issid, $size, $errCodes, $personalInfoDescription);
		return false;
	}

	function addComprehensiveData($username, $caption, $value){
		$uid=$this->getUserId($username);
		$result=$this->doTransactionQuery("SELECT * FROM `{$this->personal_data_table}` WHERE `uid` = '$uid' AND `caption` = '$caption';");
		if($result){
			if($result->num_rows>0){
				$result2=$this->doTransactionQuery("UPDATE `{$this->personal_data_table}` SET `value` = '$value' WHERE `uid` = '$uid' AND `caption` = '$caption';");
				if($result2){
					return true;
				}
				return false;
			}
		}
		$result2=$this->doTransactionQuery("INSERT INTO `{$this->personal_data_table}` (`uid`, `caption`, `value`) VALUES('$uid','$caption','$value');");
		if($result2){
			return true;
		}
		return false;
	}

	function checkUsername($name){
		$result=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_user_table}` WHERE `name`='$name';"); //name once per whole project
		if($result){
			$n=$result->num_rows;
			if($n==1){
				return 8;
			}else{
				return 34;
			}
		}
	}



	function saveSID($issid, $ov){
		$ov=$ov?$ov:false;
		$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);
		$time=$this->getTime_HH_MM_SS(":");
		$retval=true;
		$sql=$sql2="INSERT INTO `$this->perlmut_session_table` (`sid`, `inheritSid`, `hostId`, `date`, `time`, `virtual_cookie`, `check`) VALUES('$issid', '', " . ($this->hostId?$this->hostId:1) . ", '$date', '$time', '', 2);"; //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers

		if($ov){
			$sql2="SELECT (`sid`) FROM `$this->perlmut_session_table` WHERE `sid`='$issid';";

			$result=$this->doTransactionQuery($sql2);
			if($result){
				if($result->num_rows>0){
					$row=mysqli_fetch_array($result, MYSQLI_NUM);
					$fsid=$row[0];
					$sql2="UPDATE `$this->perlmut_session_table` SET `sid`='$issid', `hostId`=" . ($this->hostId?$this->hostId:1) . ", `date`='$date', `time`='$time', `check`=0 WHERE `sid`='$fsid';"; //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers
					$retval=true;
				}else $retval=false;
			}else $retval=false;
		}
		$result=$retval?$this->doTransactionQuery($sql2):$this->doTransactionQuery($sql);
		if($result){
			session_id($issid);
			return true;
		}else{
			return $retval;
		}
		$this->updateCounter(0);

		return $retval;
	}




	function setRemember(){
		global $conf;
		$this->regenerateData();
		$this->setSessionCookie(session_id(), $this->maxCookieLife);
		$uid=$this->getCurrentUserId();
		$issid=session_id();
		$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_session_cookies_table}` SET `rememberLogin` = 1 AND SET `sid` = '$issid' WHERE `userId` = $uid ;");
	}

	function clearExpired($issid){//AUTO LOGOUT NEEDS ITERATIVE STEPING
		//$retval=parent::clearExpired($issid);
		$retval=true;
		$query=0;
		$sqls[$query++]="DELETE FROM `{$this->perlmut_session_table}` WHERE `sid`='#id';";
		//$sqls[$query++]="UPDATE `{$this->perlmut_user_table}` SET `status` = 4  WHERE `userId`='#user';";
		$sqls[$query++]="DELETE FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `sid` = '#id';";
		//$sqls[$query++]="DELETE FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '#id';";
		//if(!$this->_clearExpired($issid, $sqls, 1, $this->sessionExpire)){
			$sqls=null;
			$query=0;
			$sqls[$query++]="DELETE FROM `{$this->perlmut_session_table}` WHERE `sid`='#id';";
			//$sqls[$query++]="UPDATE `{$this->perlmut_authenticated_sessions_table}` SET `sid`='{$this->EXPIRED}' WHERE `sid` = '#id';";
			$sqls[$query++]="DELETE FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `sid` = '#id';";
			//$sqls[$query++]="DELETE FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '#id';";
			return $retval&&$this->_clearExpired($issid, $sqls, 2, $this->sessionExpire);
		//}
		//return $retval&&true;
	}

	function setAuthSessionVars($conf, $dbm){
		$this->setSessionVars($conf, $dbm);
		$this->perlmut_user_table=$conf["users"];
		$this->perlmut_auth_table=$conf["auth"];
		$this->perlmut_priv_table=$conf["priv"];
		$this->perlmut_authenticated_sessions_table=$conf["authSessions"];
		$this->autoLogoutTime=$conf["autoLogoutTime"];
		$this->personal_data_synth=$conf["personalData"];
		$this->personal_data_table=$conf["personalDataStorage"];
	}

/*

	function getUserNameByLogonCookie($logonCookie){

	}

	*/

/*

*/

/*

	function logonByCookie($logonCookie){

	}

*/

	function logon($username, $password){//BUG IN HERE
		$pwd=md5($password);
		$username=stripQueryChars($username);
		$userId=$this->getUserId($username);
		if($userId!=null){
			$result=$this->doTransactionQuery("SELECT `passwordMD5` FROM `{$this->perlmut_auth_table}` WHERE `userId` = '$userId';");
			$enrow=mysqli_fetch_array($result, MYSQLI_ASSOC);
			$pwdseted=$enrow["passwordMD5"];
			$simultaniusConnections=-1;
			if($pwd==$pwdseted){
				
				$result=$this->doTransactionQuery("SELECT `simultanConx` FROM `{$this->perlmut_user_table}` WHERE `userId` = '$userId';");

				if($result){

					$row=mysqli_fetch_array($result, MYSQLI_NUM);

					$simultaniusConnections=$row[0];

				}else{

					return 7;

				}

				
				$result=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `userId` = '$userId' AND NOT `sid` = '{$this->EXPIRED}';");

				if($result){

					if($result->num_rows < $simultaniusConnections||$simultaniusConnections==1){

						if($simultaniusConnections==1){

							$this->logoff();

						}

						
						$issid=session_id();

						$result=$this->doTransactionQuery("SELECT `sessionCookie2C` FROM `{$this->perlmut_session_cookies_table}` WHERE `sid` = '$issid';");

						$md5SessionCookie="";

						if($result){

							$arow=mysqli_fetch_array($result, MYSQLI_NUM);

							$md5SessionCookie=$arow[0];

						}

						$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_authenticated_sessions_table}` (`sid`, `userId`, `sessionCookie2C`) VALUES ('$issid', $userId, '$md5SessionCookie');");

						if($result){

							
							$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);

							$time=$this->getTime_HH_MM_SS(":");

							$this->user_name=$username;

							$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_user_table}` SET `lastLoginDate` = '$date', `lastLoginTime` = '$time' WHERE `userId` = '$userId';");

							if($result){

								$this->finishAuth();

								return 14;

							}

						}

					}else{

						return 33;

					}

				}else{

					return 7;

				}

			}

			else{

				return 16;

			}

		}else{

			return 15;

		}

	}

	function logoff(){

		$issid=session_id();

		if(!$this->clearExpired(session_id())){

			if($result=$this->doTransactionQuery("DELETE FROM `$this->perlmut_authenticated_sessions_table` WHERE `sid`='$issid';")){

				return true;

			}else{

				return false;

			}

		}else{

			$userId=$this->getCurrentUserId();

			if($userId!=null){

				if($result=doQuery("DELETE FROM `$this->perlmut_authenticated_sessions_table` WHERE `userId`='$userId';")){

					return true;

				}else{

					return false;

				}

			}else{

				return false;

			}

		}

	}

	function isAuthenticated(){

		if($this->clearExpired(session_id())==false){

			if($userId=$this->getCurrentUserId()){

				$result=$this->doTransactionQuery("SELECT `sid` FROM `$this->perlmut_authenticated_sessions_table` WHERE `userId` = '$userId';");

				while($enrow=mysqli_fetch_array($result, MYSQLI_NUM)){;

					$issid=$enrow[0];

					if($issid==session_id()){//ACID

						return true;

					}

				}

			}else{

				return false;

			}

		}else{

			return false;

		}

		return false;

	}

	function changePassword($currentPassword, $password, $passwordRepeat){

		if($this->isAuthenticated()){

			$checkSession = new AuthSession($this->getHostName());

			$checkSession->manageSession(session_id(), $this->perlmut_session_sid_length);

			$errorlevel=$checkSession->logon($this->user_name, $currentPassword);

			if($errorlevel!=14){

				return $errorlevel;

			}

			if($password != $passwordRepeat){

				return 6;

			}

			$cuid=$this->getCurrentUserId();

			$password=md5($password);

			$result=$this->doTransactionQuery("UPDATE `$this->perlmut_auth_table` SET `passwordMD5` = '$password' WHERE `userId` = '$cuid';");

			if($result){

				return 29;

			}else{

				return 22;

			}

		}else{

			return false;

		}

	}







	function getCurrentUserId(){//hopefully regards on it can
		$val=$this->getCurrentUserName();
		return $this->getUserId($val!=null?$val:false);

	}

	function getUserId($username){

		if($username==false) return $username;

		stripQueryChars($username);

		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_user_table` WHERE `name`='$username' AND `hostId`='$this->hostId';");

		if($result){

			if($result->num_rows>0){

				$enrow=mysqli_fetch_array($result, MYSQLI_ASSOC);

				$userId=$enrow["userId"];

			}else{

				return null;

			}

		}else{

			return null;

		}

		return $userId;

	}

	function setPrivilege($privname, $setto){

		if($privname!="super"){
			$dst=$this->getCurrentUserId();
			$userId=$dst?$dst:1;

			$result=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_priv_table}` WHERE `privilegeName` = '$privname';");

			if($result->num_rows>0){

				$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_priv_table}` SET `privilegeStatus`='$setto' WHERE `userId`='$userId' AND `privilegeName`='$privname';");

				if($result){

					return true;

				}else{

					$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_priv_table}` (`userId`, `privilegeName`, `privilegeStatus`) VALUES(" . ($userId?$userId:1) . ", '$privname', '$setto');");

					if($result){

						return true;

					}else{

						return false;

					}

				}

			}else{
				$dst2=$this->getCurrentUserId();
				$userId=$dst?$dst2:1;
#
			//LAPED setup

				$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_priv_table}` (`userId`, `privilegeName`, `privilegeStatus`) VALUES(" . $userId . ", '$privname', '$setto');");

				if($result){

					return true;

				}else{

					return false;

				}

			}

		}

		return false;

	}

	function removePrivilege($privname){

		$userId=$this->getCurrentUserId();

		$result=$this->doTransactionQuery("DELETE FROM `$this->perlmut_priv_table` WHERE `userId` = '$userId' AND `privilegeName` = 'privname';");

		if($result){

			return true;

		}else{

			return false;

		}

	}

	function getPrivilege($privname){

		$userId=$this->getCurrentUserId();

		$result=$this->doTransactionQuery("SELECT `privilegeStatus` FROM `$this->perlmut_priv_table` WHERE `privilegeName` = '$privname' AND `userId` = '$userId';");

		if($result){

			if($result->num_rows==1){

				$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

				return $enrow[0];

			}else{

				return null;

			}

		}else{

			return null;

		}

	}

	function isSuperuser(){

		return ($this->getPrivilege("super")==1);

	}

	function setSuperUserPrivilegeByHostSU($superuserName, $superuserPass, $username, $conf, $dbm){

		$myValidateSession = new AuthSession($conf, $dbm);

		$myValidateSession->logon($superuserName, $superuserPass);

		if($myValidateSession->isAuthenticated()){

			$userId=$this->getUserId($superuserName);

			$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_priv_table` WHERE `privilegeName` = 'super';");

			if($result->num_rows>0){

				$result=$this->doTransactionQuery("UPDATE `$this->perlmut_priv_table` SET `privilegeStatus`='1' WHERE `userId`='$userId' AND `privilegeName`='super';");

				if($result){

					return 13;

				}else{

					return 7;

				}

			}else{

				$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_priv_table` (`userId`, `privilegeName`, `privilegeStatus`) VALUES($userId, 'super', '1');");

				if($result){

					return 13;

				}else{

					return 7;

				}

			}

		}else{

			return 10;

		}

	}

	function setSuperUserPrivilegeByDBUser($conf, $dbm, $username){

		$myDateDb = new DateDB($conf, $dbm);

		$rs=$myDateDb->getRecordSource($dbm["what_dbhost"], $dbm["what_dblogin"], $dbm["what_dbpass"], $dbm["what_dbname"], true);

		if($rs){/*2nd security instance check

			  only works with read rights to mysql db and table User

			*/

			/*

			$rs=$myDateDb->getRecordSource($dbm["what_dbhost"], $dbm["what_dblogin"], $dbm["what_dbpass"], "mysql", true);



			$result=$myDateDb->doTransactionQuery("SELECT * FROM `user` WHERE `User` = 'root';");

			$enrow = mysqli_fetch_array($result, MYSQLI_ASSOC);

			if($dbm["what_dbpass"]!=""){

				if($enrow["Password"]==md5($dbm["what_dbpass"])){

					$myDateDb->closeDb();

				}else{

					return 10;

				}

			}else{

				if($enrow["Password"]==""){

					$myDateDb->closeDb();

				}else{

					return 10;

				}

			}

		}else{

			return 10;//above ignored due to no access to mysql named database

		*/

		}





		$userId=$this->getUserId($username);

		$result=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_priv_table}` WHERE `privilegeName` = 'super' && `userId` = '$userId';");

		if($result->num_rows>0){

			$result=$this->doTransactionQuery("UPDATE `{$this->perlmut_priv_table}` SET `privilegeStatus`='1' WHERE `userId`='$userId' AND `privilegeName`='super';");

			if($result){

				return 13;

			}else{

				return 7;

			}

		}else{

			$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_priv_table}` (`userId`, `privilegeName`, `privilegeStatus`) VALUES($userId, 'super', '1');");

			if($result){

				return 13;

			}else{

				return 7;

			}

		}

	}

	function setSuperUserPrivilegeByDBRoot($conf, $dbm, $username){

		$myDateDb = new DateDB($conf, $dbm);

		$rs=$myDateDb->getRecordSource($dbm["what_dbhost"], "root", $dbm["dbrootpwd"], "mysql", true);

		if($rs){

			$result=$myDateDb->doTransactionQuery("SELECT * FROM `user` WHERE `User` = 'root';");

			$enrow = mysqli_fetch_array($result, MYSQLI_ASSOC);

			if($conf["dbrootpwd"]!=""){

				if($enrow["Password"]==md5($conf["dbrootpwd"])){

					$myDateDb->closeDb();

				}else{

					return 10;

				}

			}else{

				if($enrow["Password"]==""){

					$myDateDb->closeDb();

				}else{

					return 10;

				}

			}

		}else{

			return 10;

		}

		$userId=$this->getUserId($username);

		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_priv_table` WHERE `privilegeName` = 'super' && `userId` = '$userId';");

		if($result->num_rows>0){

			$result=$this->doTransactionQuery("UPDATE `$this->perlmut_priv_table` SET `privilegeStatus`='1' WHERE `userId`='$userId' AND `privilegeName`='super';");

			if($result){

				return 13;

			}else{

				return 7;

			}

		}else{

			$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_priv_table` (`userId`, `privilegeName`, `privilegeStatus`) VALUES($userId, 'super', '1');");

			if($result){

				return 13;

			}else{

				return 7;

			}

		}

	}

}

class ChatSession extends AuthSession{

	var $perlmut_nick_table;

	var $perlmut_world_table;

	var $perlmut_igno_table;

	var $perlmut_object_table;

	var $perlmut_stack_table;

	var $logonRoom;

	var $conx;

	var $worldId=null;//<BETA>

	function getRoomsCount($room){

		$wid=$this->getWorldId($room, $this->hostId);

		$result=$this->doTransactionQuery("SELECT * FROM `{$this->conx}` WHERE `wid`='$wid';");

		if($result){

			return $result->num_rows;

		}

		return 0;

	}



	function setChatSessionVars($conf, $dbm){

		$this->setAuthSessionVars($conf, $dbm);

		$this->perlmut_stack_table=$conf["stack"];

		$this->perlmut_nick_table=$conf["nicks"];

		$this->conx=$conf["conx"];

		$this->perlmut_object_table=$conf["objects"];

		$this->perlmut_world_table=$conf["worlds"];

		$this->logonRoom=$conf["logonRoom"];

		$this->perlmut_igno_table=$conf["chatIgnore"];

	}

	function getCurrentNickname($invokeId){

		$sid=session_id();

		$this->worldId=$this->getCurrentWorldId($invokeId);

		$result=$this->doTransactionQuery("SELECT `nickId` FROM `{$this->conx}` WHERE `sid`='$sid' AND `wid`='{$this->worldId}' AND `invokeId`='$invokeId';");

		if($result){

			$row=mysqli_fetch_array($result, MYSQLI_NUM);

			$nickId=$row[0];

			$result=$this->doTransactionQuery("SELECT `nickname` FROM `{$this->perlmut_nick_table}` WHERE `entryId`='$nickId';");

			if($result){

				$row=mysqli_fetch_array($result, MYSQLI_NUM);

				return $row[0];

			}

		}

	}

	function getCurrentNickId($invokeId){

		$sid=session_id();

		$this->worldId=$this->getCurrentWorldId($invokeId);

		$result=$this->doTransactionQuery("SELECT `nickId` FROM `{$this->conx}` WHERE `sid`='$sid' AND `wid`='{$this->worldId}' AND `invokeId`='$invokeId';");

		if($result){

			$row=mysqli_fetch_array($result, MYSQLI_NUM);

			$nickId=$row[0];

			return $nickId;

		}

	}

	function ChatSession($conf, $dbm){

		global $lang;

		$this->setChatSessionVars($conf, $dbm);

		$hostname=$conf["hostname"];

		$result=$this->doTransactionQuery("SELECT * from `{$this->perlmut_host_table}` WHERE `hostName` = '$hostname';");

		if($result->num_rows>0){

			$enrow = mysqli_fetch_array($result, MYSQLI_ASSOC);

			$this->hostId=$enrow["hostIndex"];

		}else{

			echo $lang["errors"][$this->createHost($conf, $dbm)]["msg"][$this->lang];

		}

	}





function saveSID($issid, $ov){
		$ov=$ov?$ov:false;
		$date=$this->formatDate($this->getDate(getDate(), false, null, null), "MMDDYYYY", false);
		$time=$this->getTime_HH_MM_SS(":");
		$retval=true;
		$sql=$sql2="INSERT INTO `$this->perlmut_session_table` (`sid`, `inheritSid`, `hostId`, `date`, `time`, `virtual_cookie`, `check`) VALUES('$issid', '', " . ($this->hostId?$this->hostId:1) . ", '$date', '$time', '', 0);"; //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers

		if($ov){
			$sql2="SELECT (`sid`) FROM `$this->perlmut_session_table` WHERE `sid`='$issid';";

			$result=$this->doTransactionQuery($sql2);
			if($result){
				if($result->num_rows>0){
					$row=mysqli_fetch_array($result, MYSQLI_NUM);
					$fsid=$row[0];
					$sql2="UPDATE `$this->perlmut_session_table` SET `sid`='$issid', `hostId`=" . ($this->hostId?$this->hostId:1) . ", `date`='$date', `time`='$time', `check`=0 WHERE `sid`='$fsid';"; //check is a flag to take care of usage modes 0 -> 'Session Mode' 1 -> 'Auth Session Mode' and furthers
					$retval=true;
				}else $retval=false;
			}else $retval=false;
		}
		$result=$retval?$this->doTransactionQuery($sql2):$this->doTransactionQuery($sql);
		if($result){
			session_id($issid);
			return true;
		}else{
			return $retval;
		}
		$this->updateCounter(0);

	$worldId=$this->getWorldId($this->logonRoom, $this->hostId);

		return $retval;

	}

	function logonNoisy($username, $password, $msg){

		$errorlevel=$this->logon($username, $password);

		if($errorlevel==14){

			$this->send4all($msg, $this->logonRoom);

			return 14;

		}

		return $errorlevel;

	}

	function send4all($msg, $world){//every unconnected session s going to be cleared no matter no problem

		$id=uniqid("", false);

		$result=$this->doTransactionQuery("SELECT `sid` FROM `$this->perlmut_session_table` WHERE `hostId` = '$this->hostId';");

		$issids=null;

		$nr=0;

		while($issids[$nr]=mysqli_fetch_array($result, MYSQLI_NUM)){

			$nr++;

		}

		if($nr>0){

			$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_object_table` (`objectId`, `formatedEvent`) VALUES('$id', '$msg');");

		}

		if($result){

			for($v=0; $v < sizeof($issids); $v++){

				if($issids[$v][0]!=session_id()){

					$tosid=$issids[$v][0];

					$wid=$this->getWorldId($world, $this->hostId);

					$issid=session_id();

					$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_stack_table` (`sid`, `objectId`, `wid`, `iterator`, `toSid`, `flag`) VALUES('$issid', '$id', '$wid', '', '$tosid', '0');");

					if($result){

						;

					}

				}

			}

		}

	}

	function getConxCount($worldname){

		$wid=$this->getWorldId($worldname, $this->hostId);

		$result=$this->doTransactionQuery("SELECT * FROM `$this->conx` WHERE `wid`='$wid';");

		return $result->num_rows;

	}

	function getMaxParteners($worldname){

		$wid=$this->getWorldId($worldname, $this->hostId);

		$result=$this->doTransactionQuery("SELECT `maxParteners` FROM `$this->perlmut_world_table` WHERE `worldId`='$wid';");

		$row=mysqli_fetch_array($result, MYSQLI_NUM);

		return $row[0];

	}

	function establishWorld($worldname, $welcomemsg, $description, $maxParteners, $list){

		if($this->getWorldId($worldname, $this->hostId)==null){

			if($list){

				$id="";

			}else{

				$id=-1;

			}

			$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_world_table` (`worldId`, `hostId`, `name`, `maxParteners`, `description`, `welcomeMessage`) VALUES('$id', '$this->hostId', '$worldname', '$maxParteners', '$description', '$welcomemsg');");

			if($result){

				return 31;

			}

		}

		return 30;

	}

	function getWelcomeMessage($invokeId){//no argument in sense to be connected and only then being greeted

		$worldId=$this->getCurrentWorldId($invokeId);

		$result=$this->doTransactionQuery("SELECT `welcomeMessage` FROM `{$this->perlmut_world_table}` WHERE `worldId` = '$worldId';");

		if($result){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			return $enrow[0];

		}

		return null;

	}

	function getDescription($worldname){//in sense to q before logon

		$worldId=$this->getWorldId($worldname, $this->hostId); //discussable for customers

		$result=$this->doTransactionQuery("SELECT 'description' FROM `{$this->perlmut_world_table}` WHERE `worldId` = '$worldId';");

		if($result){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			return $enrow[0];

		}

		return null;

	}

	function getWorldList(){

		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_world_table` WHERE `hostId`='$this->hostId' AND `worldId` >= -1;");

		$v=0;

		$tupelIs=null;

		while($tupel[$v]=mysqli_fetch_array($result, MYSQLI_ASSOC)){

			$tupelIs[$v]=$tupel[$v];

			$v++;

		}

		return $tupelIs;

	}

	function getUsersNickNames(){

		$user_name=$this->getCurrentUserName();

		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_nick_table` WHERE (`userId` IN (SELECT `userId` FROM `$this->perlmut_user_table` WHERE `name` = '$user_name'));");

		if($result){

			$tupel=null;

			$tupelIs=null;

			$v=0;

			while($tupel[$v]=mysqli_fetch_array($result, MYSQLI_ASSOC)){

				$tupelIs[$v]=$tupel[$v];

				$v++;

			}

			
			return $tupelIs;

		}

		return null;

	}

	function getWorldId($name, $hostId){//</BETA>

		$result=$this->doTransactionQuery("SELECT DISTINCT `worldId` FROM `$this->perlmut_world_table` WHERE `name` = '$name' AND `hostId` = '$hostId';");

		if($result->num_rows>0){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			return $enrow[0];

		}

		return null;

	}

	function connect($nickname, $userPassword, $world, $invokeId){

		if(!$this->isAuthenticated()){

			if($userPassword!=null&&$userPassword!=""){

				$errorlevel=$this->logon($this->user_name, $userPassword);

				if($errorlevel!=14){

					return $errorlevel;

				}

			}else{

				return 18;

			}

		}else{

			$userId=$this->getCurrentUserId();

			$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_nick_table` WHERE `userId` = '$userId'");

			if($result->num_rows>0){

				$issid=session_id();;

				$worldId=$this->getWorldId($world, $this->hostId);

				$result=$this->doTransactionQuery("SELECT DISTINCT `entryId` FROM `$this->perlmut_nick_table` WHERE `nickname` = '$nickname';");

				$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

				$nickId=$enrow[0];

				$result2=$this->doTransactionQuery("SELECT * FROM `$this->conx` WHERE `nickId`='$nickId' AND `wid`='$worldId';");

				if($result2) if($result2->num_rows>0){

					return 24;

				}else{

					if($this->getConxCount($world)<$this->getMaxParteners($world)||$this->getMaxParteners($world)==-1){

						$login=$this->doTransactionQuery("INSERT INTO `$this->conx` (`invokeId`, `sid`, `wid`, `nickId`) values('$invokeId', '$issid', '$worldId', '$nickId');");

						if($login){

							$this->worldId=$worldId;

							$nickname=$this->getCurrentNickname($invokeId);

							$this->pushOnStackByServer($invokeId, $issid, "$nickname hat sich angemeldet.", "");

							return 26;

						}

						else{

							return 25;

						}

					}else{

						return 32;

					}

				}

			}else{

				return 23;

			}

		}

	}

	function aquireNick($nickname, $greeting){

		if($this->isAuthenticated()){

			;

		}else{

			return 19;

		}

		$result=$this->doTransactionQuery("SELECT * FROM `$this->perlmut_nick_table` WHERE `nickname`='$nickname';");
		if($result->num_rows>0){

			return 20;

		}else{

			$userName=$this->getCurrentUserName();

			$result=$this->doTransactionQuery("SELECT DISTINCT `userId` FROM `$this->perlmut_user_table` WHERE `name` = '$userName' AND `hostId` = '$this->hostId';");

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			$userId=$enrow[0];

			$result=$this->doTransactionQuery("INSERT INTO `$this->perlmut_nick_table` (`nickname`, `greeting` , `userId`) VALUES('$nickname', '$greeting', '$userId');");

			if($result){

				return 21;

			}else{

			return 22;

			}

		}

	}

	function disconnect($invokeId){

		$issid=session_id();

		$nickname=$this->getCurrentNickname($invokeId);

		$this->doTransactionQuery("DELETE FROM `{$this->perlmut_stack_table}` WHERE `toInvokeId` = '$invokeId';");

		$this->pushOnStackByServer($invokeId, $issid, "$nickname hat sich abgemeldet.", "");

		$this->doTransactionQuery("DELETE FROM `{$this->conx}` WHERE `sid` = '$issid' AND `invokeId`='$invokeId';");

	}



	function clearExpired($issid){

		$retval=parent::clearExpired($issid);

		$retval=true;

		$query=0;

		$sqls[$query++]="DELETE FROM `{$this->perlmut_stack_table}` WHERE `sid` = '#id';";  //well done

		$sqls[$query++]="DELETE FROM `{$this->conx}` WHERE `sid` = '#id';";

		$sqls[$query++]="DELETE FROM `{$this->perlmut_session_table}` WHERE `sid`='#id';";

		$sqls[$query++]="UPDATE `{$this->perlmut_user_table}` SET `status` = 4  WHERE `userId`='#user';";

		$sqls[$query++]="DELETE FROM `{$this->perlmut_authenticated_sessions_table}` WHERE `sid` = '#id';";

		//autologout will be flaged procedure

		return $retval&&$this->_clearExpired($issid, $sqls, 2, $this->sessionExpire);



	}



	function pushOnStackPrivate($invokeId, $issid, $messageText, $messageStyle, $to){

			//<BETA>

				$sql="SELECT `wid` FROM `{$this->conx}` WHERE `sid`='$issid' AND `invokeId`='$invokeId';";

				$result=$this->doTransactionQuery($sql);

				$row=mysqli_fetch_array($result, MYSQLI_ASSOC);

				$wid=$row["wid"];

			//</BETA>

			$iterator=microtime();

			$id=uniqid("", false);


			$sql="INSERT INTO `$this->perlmut_object_table` (`objectId`, `messageText`, `messageStyle`, `fileDelivery`, `fileUrl`) VALUES('$id', '$messageText', '$messageStyle', 'false', '');";$result=$this->doTransactionQuery($sql);

			$sql="SELECT * FROM `$this->conx` WHERE `wid` = '$wid';";


			$result=$this->doTransactionQuery($sql);

			$toNick=$to;

			$result=$this->doTransactionQuery("SELECT `entryId` FROM `$this->perlmut_nick_table` WHERE `nickname` = '$toNick';");

			$isrow=mysqli_fetch_array($result, MYSQLI_NUM);

			$toNickId=$isrow[0];

			$result=$this->doTransactionQuery("SELECT `sid`, `invokeId`, `nickId` FROM `$this->conx` WHERE `nickId` = '$toNickId' && `wid` = '$wid';");

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			$curSid=$enrow[0];

			$masterInvokeId=$enrow[1];

			$toNickId=$enrow[2];

			if($this->getCurrentNickId($invokeId)==$toNickId){
				$type="self";
			}else{
				$type="user";
			}

			$sql="INSERT INTO `{$this->perlmut_stack_table}` (`sid`, `fromInvokeId`, `objectId`, `wid`, `iterator`, `toInvokeId`, `flag`, `type`) VALUES('$issid', '$invokeId', '$id', '$wid', '$iterator', '$masterInvokeId', '0', '$type');";

			$result2=$this->doTransactionQuery($sql);

			//***fix: see own message in p1 chat
			//***fix: updated
			//***ready
			if($this->getCurrentNickId($invokeId)!=$toNickId){//+1 self

				$sql="INSERT INTO `{$this->perlmut_stack_table}` (`sid`, `fromInvokeId`, `objectId`, `wid`, `iterator`, `toInvokeId`, `flag`, `type`) VALUES('$issid', '$invokeId', '$id', '$wid', '$iterator', '$invokeId', '0', 'self');";


				$result2=$this->doTransactionQuery($sql);

			}

			//***

	}

	function pushOnStack($invokeId, $issid, $messageText, $messageStyle){



		$sql="SELECT `wid` FROM `{$this->conx}` WHERE `sid`='$issid' AND `invokeId`='$invokeId';";

		$result=$this->doTransactionQuery($sql);

		$row=mysqli_fetch_array($result, MYSQLI_ASSOC);

		$wid=$row["wid"];



		$iterator=microtime();

		$id=uniqid("", false);

		$sql="INSERT INTO `$this->perlmut_object_table` (`messageText`, `messageStyle`, `fileDelivery`, `fileUrl`) VALUES('$messageText', '$messageStyle', 'false', '');";

		$result=$this->doTransactionQuery($sql);

		$sql="SELECT * FROM `$this->conx` WHERE `wid` = '$wid';";

		$result=$this->doTransactionQuery($sql);

		$n_users="";

		while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){

			$masterInvokeId=$row["invokeId"];

			if($this->getCurrentNickId($invokeId)==$row["nickId"]){

				$type="self";

			}else{

				$type="user";

			}

			$sql="INSERT INTO `$this->perlmut_stack_table` (`sid`, `fromInvokeId`, `objectId`, `wid`, `iterator`, `toInvokeId`, `flag`, `type`) VALUES('$issid', '$invokeId', '$id', '$wid', '$iterator', '$masterInvokeId', '0', '$type');";

			$result2=$this->doTransactionQuery($sql);

		}

	}

	function pushFileOnStack($invokeId, $issid, $fileUrl){

		//<BETA>

			$sql="SELECT `wid` FROM `{$this->conx}` WHERE `sid`='$issid' AND `invokeId`='$invokeId';";

			$result=$this->doTransactionQuery($sql);

			$row=mysqli_fetch_array($result, MYSQLI_ASSOC);

			$wid=$row["wid"];

		//</BETA>

		$iterator=microtime();

		$id=uniqid("", false);

		$sql="INSERT INTO `$this->perlmut_object_table` (`messageText`, `messageStyle`, `fileDelivery`, `fileUrl`) VALUES('', '', true, '$fileUrl');";

		$result=$this->doTransactionQuery($sql);

		$sql="SELECT * FROM `$this->conx` WHERE `wid` = '$wid';";

		$result=$this->doTransactionQuery($sql);

		$n_users="";

		while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){

			$masterInvokeId=$row["invokeId"];

			$sql="INSERT INTO `$this->perlmut_stack_table` (`sid`, `fromInvokeId`, `objectId`, `wid`, `iterator`, `toInvokeId`, `flag`, `type`) VALUES('$issid', '$invokeId', '$id', '$wid', '$iterator', '$masterInvokeId', '0', 'server');";

			$result2=$this->doTransactionQuery($sql);

		}

	}

	function pushOnStackByServer($invokeId, $issid, $messageText, $messageStyle){

		//<BETA>

			$sql="SELECT `wid` FROM `{$this->conx}` WHERE `sid`='$issid' AND `invokeId`='$invokeId';";

			$result=$this->doTransactionQuery($sql);

			$row=mysqli_fetch_array($result, MYSQLI_ASSOC);

			$wid=$row["wid"];

		//</BETA>

		$iterator=microtime();

		$id=uniqid("", false);

		$sql="INSERT INTO `$this->perlmut_object_table` (`objectId`, `messageText`, `messageStyle`, `fileDelivery`, `fileUrl`) VALUES('$id', '$messageText', '$messageStyle', 'false', '');";

		$result=$this->doTransactionQuery($sql);


		$sql="SELECT * FROM `$this->conx` WHERE `wid` = '$wid';";

		$result=$this->doTransactionQuery($sql);

		$n_users="";

		while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){

			$masterInvokeId=$row["invokeId"];

			$sql="INSERT INTO `$this->perlmut_stack_table` (`sid`, `fromInvokeId`, `objectId`, `wid`, `iterator`, `toInvokeId`, `flag`, `type`) VALUES('$issid', '$invokeId', '$id', '$wid', '$iterator', '$masterInvokeId', '0', 'server');";

			$result2=$this->doTransactionQuery($sql);

		}

	}

	function getXMLresponseStack($issid, $invokeId){//stepped performance to ping ready data exchange

		echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";

		echo "<response>";

		global $toBase;

		$users="";

		$messageText="";

		$messageStyle="";

		$fileUrl="";

		$n_users="";

		$listUpdate="";

		$type="";

		//<BETA>

			$sql="SELECT `wid` FROM `{$this->conx}` WHERE `sid`='$issid' AND `invokeId`='$invokeId';";

			$result=$this->doTransactionQuery($sql);

			if($result){

				$row=mysqli_fetch_array($result, MYSQLI_ASSOC);

				$wid=$row["wid"];

			}

		//</BETA>

		$this->updateSession();

		$this->clearExpired(session_id());

		if(true){

//security related

			//<update>

			$n_users="";

			//<user List s being delivered>

			$sql="SELECT * FROM `$this->conx` WHERE `wid` = '$wid';";

			$result=$this->doTransactionQuery($sql);

			//***delivers current users in room list

			if($result) while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){

				$n_users=$n_users . $row["nickId"] . ";";

			}

			//***

			//</user List s being delivered>

			//<fetch>

			/* $prevIterator=$_POST["iterator"]; */ //client side relevant information and severlogic for first number index!!!

		//preselect messages means not the ones from ignored users

			$sql="SELECT * FROM `$this->perlmut_stack_table` WHERE ((`wid` = '$wid') AND (`flag` <= 0) AND (`toInvokeId` = '$invokeId') AND (`fromInvokeId` NOT IN (SELECT `wantedInvokeId` FROM `{$this->perlmut_igno_table}` WHERE ((`invokeId`='$invokeId')  AND (`wantedInvokeId` IN (SELECT `fromInvokeId` FROM `$this->perlmut_stack_table` WHERE ((`wid` = '$wid') AND (`flag` <= 0) AND (`toInvokeId` = '$invokeId'))))))));";

			$result=$this->doTransactionQuery($sql);



			$result2=$this->doTransactionQuery("SELECT `wantedInvokeId` FROM `{$this->perlmut_igno_table}` WHERE ((`worldId`='$wid') AND (`invokeId`='$invokeId'));");

			if($result2){

				while($arow=mysqli_fetch_array($result2, MYSQLI_NUM)){

					$masterInvokeId=$arow[0];

					$result3=$this->doTransactionQuery("DELETE FROM `{$this->perlmut_stack_table}` WHERE ((`wid` = '$wid') AND (`flag` <= 0) AND (`toInvokeId` = '$invokeId') AND (`fromInvokeId` = '$masterInvokeId'));");

				}

			}

			//***delete ignored Messages from stack object table is cleared later

			if($result) if($result->num_rows>0){

				$f=0;

			}else{//nothing on stack 2 carry

				$type="";

				$status="update";

				$senderSid="";

				$nickname="";

				$toNickname="";

				$theWhole="";

				$iterator=microtime();

			}

			if($result) if($result->num_rows>0){
				while($row=mysqli_fetch_array($result, MYSQLI_ASSOC)){

					$type=$row["type"];

					$objectId=$row["objectId"];

					$iterator=$row["iterator"];

					$stackEntryId=$row["id"];

					$masterInvokeId=$row["fromInvokeId"];

					$sql="SELECT `nickId` FROM `$this->conx` WHERE (`invokeId` = '$masterInvokeId') AND (`wid` = '$wid')";

					$result2=$this->doTransactionQuery($sql);

					$row=mysqli_fetch_array($result2, MYSQLI_NUM);

					$nickId=$row[0];

					$sql="SELECT `nickname` FROM `$this->perlmut_nick_table` WHERE `entryId` = '$nickId';";

					$result2=$this->doTransactionQuery($sql);

					$row=mysqli_fetch_array($result2, MYSQLI_NUM);

					$nickname=$row[0];

					$sql="SELECT * FROM `$this->perlmut_object_table` WHERE `objectId` = '$objectId';";

					$result2=$this->doTransactionQuery($sql);

					if($result2) if($result2->num_rows>0){

						$row=mysqli_fetch_array($result2, MYSQLI_ASSOC);

						$messageText=$row["messageText"];

						$messageStyle=$row["messageStyle"];

						$fileDelivery=$row["fileDelivery"];

						$fileUrl="";

						if($fileDelivery){

							$fileUrl=$row["fileUrl"];

						}

						$status="carries";

					}else{

						$status="error"; //seems to be legal to have it in scope function wise not block sensed

					}

					$sql="DELETE FROM `$this->perlmut_stack_table` WHERE (`toInvokeId`='$invokeId') AND (`objectId` = '$objectId');";

					$result2=$this->doTransactionQuery($sql);

					//all current data on stack manytime data

					include("$toBase/forms/XMLSyncFormTemplate.php");

					$f++;

				}

			}else{

				include_once("$toBase/forms/XMLSyncFormTemplate.php");

			}
		}

		//<Keeps Stack clear> seems to be solved

		$this->doTransactionQuery("DELETE FROM `$this->perlmut_stack_table` WHERE (`toInvokeId` NOT IN (SELECT `invokeId` FROM `$this->conx` WHERE 1));");

		$this->doTransactionQuery("DELETE FROM `$this->perlmut_object_table` WHERE (`objectId` NOT IN (SELECT `objectId` FROM `$this->perlmut_stack_table` WHERE 1));");

		//</Keeps Stack clear>

		echo "</response>";

	}

//<ZETA why="sid once per active room">

	function getCurrentWorldId($invokeId){

		if($this->worldId!=null){

				return $this->worldId;

		}

		else{

			$issid=session_id();

			$result=$this->doTransactionQuery("SELECT `wid` FROM `{$this->conx}` WHERE `sid`='$issid' AND `invokeId`='$invokeId';");

			$temp=mysqli_fetch_array($result, MYSQLI_NUM);

			$this->worldId=$temp[0];

			return $temp[0];

		}

	}

//</ZETA>

	function setIgnore($nickId, $invokeId){

		$issid=session_id();

		$wid=$this->getCurrentWorldId($invokeId);

		$result=$this->doTransactionQuery("SELECT `invokeId` FROM `{$this->conx}` WHERE `wid`='$wid' AND `nickId`='$nickId';");

		if($result){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			$masterInvokeId=$enrow[0];

			$result=$this->doTransactionQuery("INSERT INTO `{$this->perlmut_igno_table}` (`worldId`, `invokeId`, `wantedInvokeId`) VALUES('$wid', '$invokeId', '$masterInvokeId');");

			if($result){

				return true;

			}

			return false;

		}

		return false;

	}



	function unsetIgnore($nickId, $invokeId){

		$issid=session_id();

		$wid=$this->getCurrentWorldId($invokeId);

		$result=$this->doTransactionQuery("SELECT `invokeId` FROM `{$this->conx}` WHERE `wid`='$wid' AND `nickId`='$nickId';");

		if($result){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			$masterInvokeId=$enrow[0];

			$result=$this->doTransactionQuery("DELETE FROM `{$this->perlmut_igno_table}` WHERE `worldId`='$wid' AND `invokeId`='$invokeId' AND `wantedInvokeId`='$masterInvokeId';");

			if($result){

				return true;

			}

			return false;

		}

		return false;

	}

//</2BC>

	function getIgnoreFor($nickId, $invokeId){

		$issid=session_id();

		$wid=$this->getCurrentWorldId($invokeId);

		$result=$this->doTransactionQuery("SELECT `invokeId` FROM `{$this->conx}` WHERE `wid`='$wid' AND `nickId`='$nickId';");

		if($result){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			$masterInvokeId=$enrow[0];

			$result=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_igno_table}` WHERE `invokeId` = '$invokeId' AND `wantedInvokeId`='$masterInvokeId';");

			if($result){

				if($result->num_rows>0){

					return true;

				}

				return false;

			}

			return null;

		}

		return null;

	}

	function getWorldName($worldId){

		$result=$this->doTransactionQuery("SELECT `name` FROM `{$this->perlmut_world_table}` WHERE `worldId`='$worldId';");

		if($result){

			$enrow=mysqli_fetch_array($result, MYSQLI_NUM);

			return $enrow[0];

		}

		return null;

	}

	function getUserList($world){//</ZETA>

		$wid=$this->getWorldId($world, $this->hostId);

		$result=$this->doTransactionQuery("SELECT `nickId` FROM `{$this->conx}` WHERE `wid` = '$wid';");

		$tupel=null;

		$a=0;

		while($enrow=mysqli_fetch_array($result, MYSQLI_NUM)){

			$nickId=$enrow[0];

			$result2=$this->doTransactionQuery("SELECT * FROM `{$this->perlmut_nick_table}` WHERE `entryId` = '$nickId';");

			$tupel[$a++]=mysqli_fetch_array($result2, MYSQLI_ASSOC);

		}

		return $tupel;
	}

}