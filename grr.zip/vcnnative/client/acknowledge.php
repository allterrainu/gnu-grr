<?php
global ${$conf["APP.SESSION.sign"]};
if(${$conf["APP.SESSION.sign"]}->validSession(!isSet($_SESSION[$itsWinId])&&$sid!=""?$sid:$_SESSION[$itsWinId])&&($sid!=""||$sid!=${$conf["APP.SESSION.sign"]}->EXPIRED)&&!$supercide){ 
		require("./base/site/main.php");
		require("./lib/app/assemble_trail.php"); 
	}else{ 
		require("./vcnnative/client/foot.php"); 
	} 
		if($supercide){ 
			require("./vcnnative/client/override.php"); 
		}else if(!$already){ 
			require("./vcnnative/client/botlike.php"); 
		} 
	//*** 
?>