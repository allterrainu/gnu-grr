document.writeln("<IMG src=\"./res/gfx/console/cursor.png\" width=\"300\" height=\"300\">");

var currentPos=0;
var delay=155;

function _simpleCursorAni(){
	_startCursorAni();
	var dc=seq1_ani_cursor.substr(currentPos++, 1);
	dc=="\\"?dc:dc.substr(0,1);
	document.getElementById(id).value=dc;
	currentPos=currentPos==seq1_ani_cursor.length?0:currentPos;
}

function _startCursorAni(){
	setTimeout("_simpleCursorAni();", delay);
}
