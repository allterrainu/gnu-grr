<?php

	global ${$conf["APP.SESSION.sign"]}, $sid;

	$sid="";
	
	$conf["relativeroot"]=strlen($conf["relativeroot"])==0?"/":$conf["relativeroot"];	
	
	$csssourcename="/pagehub/solid/domain/bitsession.us/HANGAR/base/res/styles/default.css";
	//^^^^BETA 2BC
		
	${$conf["APP.SESSION.sign"]}=new AuthSession($conf, $dbm);


	$gateway_pipe=$lang["session_service"]["scan_sys_service"]["lock"][${$conf["APP.SESSION.sign"]}->lang];

	$lang["first_clause"]["scan_sys_service"]["register"]=strcount($lang["greetings"]["scan_sys_reset"][${$conf["APP.SESSION.sign"]}->lang], $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["session"], $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]])==$lang["first_clause"]["scan_sys_service"][${$conf["APP.SESSION.sign"]}->lang]?1:0;
	
	$newinit=false;

	$pastCheck=true;

	$nocase=true;
	
	$normalinit=false;
	
	$supercide=false;
	
	$already=false;
	
	if(isSet($_POST)) if(isSet($_POST["scaledInstance"])) if($_POST["scaledInstance"]=="DROPED") $supercide=true;

	$arbiter=true;

	if(isSet($_GET["dsab"])){	

		$arbiter=true;
		if($_GET["dsab"]=="DRAW"){

			//$_SESSION = array();

			$cookies=getCookieStorage($_COOKIE);

			$v=0;
			
			if(sizeof($cookies)!=0){
				for($v=0; $v<sizeof($cookies); $v++){
					if(((substr_count($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"], "localhost") == 1)||(isIPV4ADR($_SERVER["HTTP_HOST"])||isIPV4ADR($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["security"])))||isIPV4ADR($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"])){
						if(strcount($conf["relativeroot"], "/", false)>1) session_set_cookie_params(-1, $conf["relativeroot"], $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"]);
						setcookie($cookies[0]["hash"], $cookies[0]["time"], $cookies[0]["time"]-7200*60, false, (strcount($conf["relativeroot"], "/", false)>1?$conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"] . $conf["relativeroot"]:""), (isSet($_SERVER["HTTPS"])?($_SERVER["HTTPS"]?true:false):false), false);
					}else if(isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"])){
						if(strcount($conf["relativeroot"], "/", false)>1) session_set_cookie_params(-1, $conf["relativeroot"], $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"]);
						setcookie($cookies[0]["hash"], $cookies[0]["time"], $cookies[0]["time"]-7200*60, false, $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"], (isSet($_SERVER["HTTPS"])?($_SERVER["HTTPS"]?true:false):false), false);
					}else{
						if(strcount($conf["relativeroot"], "/", false)>1) session_set_cookie_params(-1, $conf["relativeroot"], (isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"])||isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"])?"":".") .  $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"]);
						setcookie($cookies[0]["hash"], $cookies[0]["time"], $cookies[0]["time"]-7200*60, false, (isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"])||isSubDomainCarry($conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"])?"":".") . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["domain"], (isSet($_SERVER["HTTPS"])?($_SERVER["HTTPS"]?true:false):false), false);
					}
				}
				
				$newinit=true;

				$pastCheck=true;

			}else{
			
				$normalinit=true;
			
				$pastCheck=false;

			}

		}

	}else{
		$arbiter=false;
	}

	

	if($pastCheck){

		if(isSet($_GET["dscd"])){

			if($_GET["dscd"]=="YES"){

				$newinit=false;

			}

		}else{

			;

		}

	}else{

		;

	}
	if((!$newinit&&!$normalinit&&!$arbiter)){
		$nocase=false;
		$sid=session_enable(${$conf["APP.SESSION.sign"]});
		if(!$sid) session_initialize(${$conf["APP.SESSION.sign"]});
	}else{
		//
		;
	}
	session_name($gateway_pipe);
	$itsWinId=uniqId();
	$itsGateId=md5(uniqId());
	if(!isSet($_SESSION["window_mount"][0])) $_SESSION[$itsWinId]=session_name();
	
	  //2BC check uplink was formated like this
	if(!isSet($_SESSION["window_mount"][0])) if($_SESSION[$itsWinId]==session_name()){
		$_SESSION["window_mount"]=null;
		$d=sizeof($_SESSION["window_mount"]);
		$_SESSION["window_mount"][$d]["id"]=$itsWinId;
		$_SESSION["window_mount"][$d]["gate"]=$itsGateId;
		$_SESSION["window_mount"][$d]["update"]=false;
		
		if(${$conf["APP.SESSION.sign"]}->validSession($sid)){
		//***
			$_SESSION[$itsWinId]=$sid;
			$_SESSION["gate_ini"]=$sid;
			$_SESSION[session_name()]=$sid;
	
		}
	}
?>
<SCRIPT language="JavaScript" type="text/JavaScript">
var <?php $d=sizeof($_SESSION["window_mount"])-1; echo $conf["APP.VARS.main"] . $conf["APP.VARS.index"] . $conf["APP.VARS.register"] . md5($_SESSION["window_mount"][$d]["id"]) . $conf["APP.VARS.register"]  . $conf["APP.VARS.index"] . $conf["APP.VARS.main"] . "=\"" . $_SESSION["window_mount"][$d]["gate"] . "\""; ?>;
</SCRIPT>
