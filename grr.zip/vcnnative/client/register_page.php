<?php
error_reporting(E_ERROR);
ini_set('display_errors', FALSE);
//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);
ini_set('session.use_cookies', 0);
ini_set('session.use_only_cookies', 0);
ini_set('session.use_trans_sid', 0);
global $terransUniteSession, $conf, $sid;
include_once("./../../base/conf/db.conf.php");
include_once("./../../base/conf/app_silent.inc.php");
include_once("./../../base/conf/perlmut.conf.php");
include_once("./../lib/functions/perlmut.functions.php");
include_once("./../lib/classes/perlmut.classes.php");
include_once("./../../base/lang/perlmut.lang.php");
require("./../../base/conf/reqVars.php");
${$conf["APP.SESSION.sign"]}=new AuthSession($conf, $dbm);
$sid=session_continue(${$conf["APP.SESSION.sign"]});
$clamb=true;

class Entry{
	var $type="";
	var $url="";
	var $src="";

	function _init(){
		global $TYPE_URL, $TYPE_HASHTAG, $TYPE_IMAGE, $DEFAULT_URL;
		$this->type=$TYPE_URL;
		$this->url=$DEFAULT_URL;
	}
	
	function setItsType($typeAttribute){
		$this->type=$typeAttribute;
	}
	
	function setItsUrl($urlAttribute){
		$this->type=$urlAttribute;
	}
	
	function setItsSrc($srcAttribute){
		$this->type=$srcAttribute;
	}
	
	function read($attribute){
		switch($attribute){
			case "type":
			$retval=$this->type;
			break;
			case "url":
			$retval=$this->url;
			break;
			case "src":
			$retval=$this->src;
			break;			
			default:
		}
		return $retval;
	}
}

if($clamb){
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");
?>
<script language="JavaScript" type="text/JavaScript">
	function isGate(d){
		var retval;
		retval=true;		
		<?php 

		if(isSet($_SESSION["window_mount"])) if(sizeof($_SESSION["window_mount"])!=0) if(isSet($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) if($_SESSION[$_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]]==$sid){ ?> retval=<?php echo "\"" . md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]) . "\"==d?true:false;"; }else{ ?>retval=false;<?php }?>
		if(<?php $d=sizeof($_SESSION["window_mount"])-1; echo $conf["APP.VARS.main"] . $conf["APP.VARS.index"] . $conf["APP.VARS.register"] . md5($_SESSION["window_mount"][$d]["id"]) . $conf["APP.VARS.register"]  . $conf["APP.VARS.index"] . $conf["APP.VARS.main"] . "==\"" . $_SESSION["window_mount"][$d]["gate"] . "\""; ?>){
			;
		}else if(window.parent!=null) return window.parent.isGate(d);
		return retval;	
	}	
	function isGatx(){
		try{
			var retval=isGate(<?php echo "" . "\"" . md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]) . "\""; ?>)?true:false;
		}catch(e){
			retval=false;
		}
		return retval;
	}
		
	function getParentWindow(){
		return window.parent;
	}
	</script>
<?php
$reconnect=false;
if(isSet($_SESSION["gate_ini"])){
	if($_SESSION["gate_ini"]==$sid){
		;
	}else{
		$reconnect=true;
	}
}else{
	$reconnect=true;
}
if($reconnect){
?>
<script language="JavaScript" type="text/JavaScript">
	
	
	function reloadContainer(){
		var windawr=window;	
		var estimatedDone=false;
		var count=0;
		while(!estimatedDone){
			if(windawr.isGatx()){
				estimatedDone=true;
				if(!windawr.parent.ondraw){
					windawr.parent.link();
					windawr.parent.channelUpdate();
				}
			}
			if(!estimatedDone){
				try{
					count++;
					windawr=windawr.getParentWindow();
				}catch(e){
					estimatedDone=true;
				}
			}
		}		
	}
	
	document.onload=reloadContainer();
	</script>
<?php
	}else{
	require("./r_node.php");
	?>
	<script language="JavaScript" type="text/JavaScript">
	function getParentWindow(){
		return window.parent;
	}
	</script>
	<?php
	session_write_close();
	}
}
exit();
?>