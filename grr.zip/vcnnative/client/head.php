<META http-equiv="Content-Type" content="text/html;charset=utf8">
<META name="language" content=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>>
	<?php

	if(isset($_SERVER["HTTP_CF_IPCOUNTRY"])){
	    //If it is exists, use it.
	    $userCountry = $_SERVER["HTTP_CF_IPCOUNTRY"];
	}
	   $countryCode=$userCountry!=""?strtoupper($userCountry):$countryCode;

		echo "<TITLE>" . $conf["siteTitle"] . "</TITLE>";

		echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";
	?>

	<?php

echo "<meta name=\"description\" content=\"" . $conf["description"] . "\">";

echo "<meta name=\"keywords\" content=\"" . $conf["keywords"] . "\">";

echo "<meta name=\"author\" content=\"" . $conf["contentManager"] . "\">";

echo "<meta name=\"contact_addr\" content=\"" . $conf["webmasterEmail"] . "\">";

?>
<meta name="distribution" content="Global">

<meta name="resource-type" content="document">

<meta name="robots" content="index, follow">

<link rel="styleSheet" href=<?php echo "\"" . $csssourcename . "\""; ?> type="text/css">
<META name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<?php
								$plant=false;

								if($newinit){
  ?>
  <HTML>
  <BODY style="background-color:23DEFF;">
  <?php
									echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang];

									if($pastCheck){
										//echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"]  . "?lang=" . ${$conf["APP.SESSION.sign"]}->lang . "_" . $countryCode . "&dscd=YES\">";

									}else{?>
<script language="JavaScript" type="text/JavaScript">
<?php
//block hostid
?>
</script>

<?php
							}?>
  </BODY>
  </HTML>
  <?php

							?>

							<?php

								$plant=true;
								}else{
								/*
									echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] .  "?lang=" . ${$conf["APP.SESSION.sign"]}->lang . "_" . $countryCode . "&dscd=YES&dsab=\">";
								*/
									$url=$conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] .  "?lang=" . ${$conf["APP.SESSION.sign"]}->lang . "_" . $countryCode . "&dscd=YES";

									$token=isSet($_GET["lang"])?$_GET["lang"]:false;

									$overrideIts=$token==false?true:false;

									if(!$overrideIts){
									$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT `url` FROM `{${$conf["APP.SESSION.sign"]}->tokens_to_url_table}` WHERE `token` = '$token';");

									$tupel=mysqli_fetch_array($result, MYSQLI_ASSOC);

									$url=$tupel["url"];

									}
									//echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $url . "\">";
								}  								//if(!$plant&&isSet($_GET["dscd"])) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . "\">";
/*
									php-dyncup dynamic APP.SERVER.ACCBIND[].->add(CALL.UNIT_PAGE);
									*/

								if(!$plant&&isSet($_GET["dscd"])) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] . "\">";
							?>

							<?php
  								if(isSet($_GET)) if(isSet($_GET["dsab"])) if($_GET["dsab"]=="#filtered"){

									echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang];

									echo "<META http-equiv=\"refresh\" content=\"0; URL=\"" . "./index.php" . "?check=YES\">";

								}

if(isSet($_POST["content"])) ${$conf["APP.SESSION.sign"]}->doQuery("INSERT INTO `" . $conf["f14TOMCAT"] . "` (`estimatedId`, `hashtag`, `date`) VALUES('', '" . stripQueryChars($_POST["content"]) . "', '" . ${$conf["APP.SESSION.sign"]}->formatDate(${$conf["APP.SESSION.sign"]}->getDate(getDate(), false), "WD MON D HH:MM:SS YYYY", false) . "');");

?>
<script language="JavaScript" type="text/JavaScript">
	setTimeout("document.body.style.backgroundColor='#000000';", 1000);

	function gambleCheck(){
		document.body.style.backgroundColor="#000000";
		if((document.location.href.indexOf("#")!=-1)){
					var entry=document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#"));
					document.forms["hashtag"].content.value=stripHTMLSpecialChars(isNum(entry)?"[[_vCn_]]<tt>firebat: </tt><b>hint </b><i>aproach </i>[[_vCn_]]":entry);
					document.forms["hashtag"].submit();
		}else{
			;
		}
	}

	function isGate(d){
		var d=d?d:false;
  if(d==false) return d;
		var retval;
		retval=false;
		<?php

		if(isSet($_SESSION["window_mount"])) if(sizeof($_SESSION["window_mount"])!=0) if(isSet($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) if($_SESSION[$_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]]==$sid){ ?> retval=<?php echo "\"" . md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]) . "\"==d?true:false;"; }else{ ?>retval=false;<?php }?>
		<?php if(isSet($_SESSION)) {//2BC
		?> if(<?php $d=sizeof($_SESSION["window_mount"])-1; echo $conf["APP.VARS.main"] . $conf["APP.VARS.index"] . $conf["APP.VARS.register"] . (md5($_SESSION["window_mount"][$d]["id"])) . $conf["APP.VARS.register"]  . $conf["APP.VARS.index"] . $conf["APP.VARS.main"] . "==\"" . $_SESSION["window_mount"][$d]["gate"] . "\""; ?>){
			retval=true;
		}else if(window.parent!=null) return window.parent.isGate(d);
		<?php
		}
		?>
		return retval;
	}
//
//*** figured out
//
	function isGatx(){
var retval=false;
		try{
			var retval=isGate(<?php if(isSet($_SESSION["window_mount"])) if(sizeof($_SESSION["window_mount"])!=0) if(isSet($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) echo "" . "\"" . (md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) . "\""; ?>)?true:false;
		}catch(e){
			retval=false;
		}finally{
		return retval;
}
}
//
//*** ^^^^unchecked behaviour lists code fragement }catch(e){ and make interpreter break
//

function dismiss(){
		var entry=document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#"));
		document.forms["hashtag"].content.value=stripHTMLSpecialChars(isNum(entry)?"[[_vCn_]]<tt>firebat: </tt><b>hint </b><i>aproach </i>[[_vCn_]]":entry);
	}

	var ondraw=false;

	<?php

		if($newinit){

		?>

			;

		<?php

			}

		?>

	function reloadSite(){

		ondraw=true;

		<?php
		if(!$arbiter){

		?>

			if((document.location.href.indexOf("dscd=YES")==-1)&&(document.location.href.indexOf("dsab")==-1)){
				var ctr=document.location.href.substr(0, document.location.href.indexOf("#")==-1?document.location.href.length:document.location.href.indexOf("#"));
				document.location.href=ctr + (ctr.indexOf("?")!=-1?"&":"?") + "dsab=DRAW" + (document.location.href.indexOf("#")==-1?"&itsServ=none":"&itsServ=" + document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#")));


			}else {

		<?php

			echo "document.location.href=\"" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] .  $conf["relativeroot"] . "\";";

		?>

		}

		<?php

		}

		?>

	}


	function reloadSiteFar(){

		var ddr=false

		<?php

		$draft=false;

		if(isSet($_POST)){

			if(isSet($_POST["check"])){

				echo "ddr=true;";

			}else{

				$draft=true;

			}

		}else{

			$draft=true;

		}

		if($draft){

			echo "ddr=urlGet(\"check\")!=-1?true:ddr;";

		}

		?>

		if(ddr) document.forms.reload.submit();

	}


	//document.onload=function(){__loadRescueOperator="";};
</script>
<?php

?>
<?php

if(!$newinit&&$arbiter) if($nocase){
	//include("./jsmassive.inc.php");
}
?>
<?php
	if(!$newinit&&!$arbiter) if(!$nocase){
		require("./base/res/includes/jsimports.inc.php");

	}
?>
</HEAD>
