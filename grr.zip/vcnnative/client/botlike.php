<?php
//search engine optimization below
//entrance level detection
//for indexed search engines
//req.php?tsa=#filename&dsc=#dataSegmentControl&sid=#DOL#poolIndexedSid&further_values=...
//#hashtag_topic
//req.php?acc=#launch&sid=#DOL#poolIndexedSid&further_values=...

/*
by visit of search machines done by robots,crawler,bots etc.

site returns data with follow telemetrics which may be recognized on later visit that user does by entering site through search engine
*/

/*
not user is tracked

search machine visit was logged

and may be referenced for customized entrance levels due to date since new infos and search hit relevant content
*/

$exitcode=-1;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">  
<html lang=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>>  
<HEAD>
<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1">
<META name="language" content=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>>
<?php
	//***
	//2BC
	//may be added to linkmenu and or relay browse beside delivery stunt in the tables
?>
<?php  
	echo "<TITLE>" . $conf["siteTitle"] . "</TITLE>";  
	  
	echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";  
?>  
  
<?php  
  
echo "<meta name=\"description\" content=\"" . $conf["description"] . "\">";  
  
echo "<meta name=\"keywords\" content=\"" . $conf["keywords"] . "\">";  
  
echo "<meta name=\"author\" content=\"" . $conf["contentManager"] . "\">";  
  
echo "<meta name=\"contact_addr\" content=\"" . $conf["webmasterEmail"] . "\">";
 
?>
<meta name="distribution" content="Global">  
  
<meta name="resource-type" content="document">
 
<meta name="robots" content="index, follow">  
 
<?php
	//***
?>
<link rel="styleSheet" href=<?php echo "\"" . $csssourcename . "\""; ?> type="text/css">  
<META name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">  
<?php
						if(isSet($_GET)) if(isSet($_GET["check"])) if($_GET["check"]=="YES"){
						
?>
<!--last plot-->
<?php
						$exitcode=${$conf["APP.SESSION.sign"]}->getSessionExitCode();
						$arbiter=false;
						
						}else{
?>
<!--no last plot-->			
<?php
								$plant=false;

								if($newinit){

									//echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang];
									//start indexing
									
									//2BC
									if($pastCheck&&!$arbiter) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] . "?dscd=YES&dsab=#filtered\">";
							
									//done onload=func();
							?>
							<?php
									$plant=true;

								}else{
									//next entry 
									//ROBOT or AGENT with cookies [enabled]
									//echo "<meta http-equiv=\"refresh\" content=\"0; URL=\"" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] . "?dsab=DRAW\">";
								}
								//next entry 
								//ROBOT or AGENT with cookies [disabled]
								if(!$plant&&isSet($_GET["dscd"])) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["security"] . $conf["relativeroot"] . "\">";
							?>
							<?php
								if(isSet($_POST)) if(isSet($_POST["confirmed"])) if($_POST["confirmed"]=="CHECK"&&!isSet($_GET["check"])){
									//exit score
									
									//echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang];

									echo "<META http-equiv=\"refresh\" content=\"0; URL=\"" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] . "?check=YES\">";
								}
							?>

							<script language="JavaScript" type="text/JavaScript">

									function isGate(){

										var retval=true;

										return retval;

									}

									var ondraw=false;

									<?php

										if($newinit){

										?>

											;

										<?php

											}

										?>

	function reloadSite(){ 
 
		ondraw=true; 
		 
		<?php
		if(!$arbiter){
			
		?>

			if((document.location.href.indexOf("dscd=YES")==-1)&&(document.location.href.indexOf("dsab")==-1)){
				var ctr=document.location.href.substr(0, document.location.href.indexOf("#")==-1?document.location.href.length:document.location.href.indexOf("#"));
				document.location.href=ctr + (ctr.indexOf("?")!=-1?"&":"?") + "dsab=DRAW" + (document.location.href.indexOf("#")==-1?"&itsServ=none":"&itsServ=" + document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#")));  
			 
			 
			}else { 

		<?php
 
			//echo "document.location.href=\"" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . "\";"; 
 
		?> 
 
		} 
 
		<?php 
 
		} 
 
		?> 
 
	} 
							</SCRIPT>
							</HEAD>
<?php
}
?>
							<BODY onload="reloadSite();">
<?php
							
							if($exitcode>=0){
?>
<!-- example plot result for exitlevel-->
<?php		
							}else{
?>
<!-- example plot result but minimum-->
<?php
echo "<H1>" . $conf["siteTitle"] ."</H1>";
?>
<P>
<?php
echo $conf["description"] . "<BR>";
?>
</P>
<?php
echo "<TT>" . $conf["keywords"] . "</TT><BR>";
?>

<?php
							}
?>
							</BODY>
						</HTML>