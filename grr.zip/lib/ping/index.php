<?php 
	error_reporting(E_ERROR); 
 
	ini_set('display_errors', FALSE); 
 
	//error_reporting(E_ALL); 
 
 
	ini_set('session.use_cookies', 0); 
 
	ini_set('session.use_only_cookies', 0); 
 
	ini_set('session.use_trans_sid', 0); 

	global $sid, $conf;

	require("./../../base/conf/db.conf.php");

	require("./../../base/conf/app_silent.inc.php");
	
	global ${$conf["APP.SESSION.sign"]};	 

	require("./../../base/lang/perlmut.lang.php"); 
 
	require("./../../base/conf/perlmut.conf.php"); 
 
	require("./../../vcnnative/lib/functions/perlmut.functions.php"); 
 
	require("./../../vcnnative/lib/classes/perlmut.classes.php"); 
 
	//braintex lay a hash no fly lie ?itsServ=default&nonamesession=001#noCenterPortACC1))CTRL3156699910005551_0x00》》¡¡||TRY//*** blockTrail&&sessionStore..GsixStreamDream//fuelwaysZZ))x50gogogo
 
	${$conf["APP.SESSION.sign"]}=new AuthSession($conf, $dbm);

	$sid=session_continue(${$conf["APP.SESSION.sign"]}); 
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
	header("Pragma: no-cache");
	header('Content-Type: text/xml');$iniReq=true;
	if(!isSet($_SESSION)){
		$iniReq=false;
	}

	if($iniReq) if(isSet($_SESSION["gate_ini"])){

		if($sid!=$_SESSION["gate_ini"]){
			$iniReq=false;
		}
	}else $iniReq=false;
	if(!$iniReq){
?>
<response>
<request status="exit">
no session binded
</request>
</response>
<?php
	}else {
${$conf["APP.SESSION.sign"]}->setCookieToWindowLifetime();
?>

<response>
<request status="done">
ready. ok.
</request>
</response>
<?php
}
?>
