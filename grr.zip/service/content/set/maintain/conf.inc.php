<?php
	$conf["secses"]["scripts"]="./base/conf/content/maintain/scripts.txt";
	$conf["secses"]["pages"]="./base/conf/content/maintain/pages.txt";
	$conf["secses"]["logintra"]="./service/switch.log";
?>