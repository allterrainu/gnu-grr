<?php
	$conf["secses"]["scripts"]="./base/conf/content/offline/scripts.txt";
	$conf["secses"]["pages"]="./base/conf/content/offline/pages.txt";
	$conf["secses"]["logintra"]="./service/switch.log";
?>