<?php
require("./../base/conf/db.conf.php");
require("./../base/conf/perlmut.conf.php");
$sessionCookies=$conf["sessionCookies"];
$sessionVars=$conf["sessionVariables"];
$security_hash=$conf["SecSesHash2SID"];
$sessions=$conf["sessions"];
//***
	$what_dbhost=$dbm["what_dbhost"];
	$what_dblogin=$dbm["what_dblogin"];
	$what_dbpwd=$dbm["what_dbpass"];
	$what_dbname=$dbm["what_dbname"];
//***
$a=0;
//$sql[$a++]="TRUNCATE TABLE `" . $sessionCookies . "`;";
$sql[$a++]="TRUNCATE TABLE `" . $sessionVars . "`;";
//$sql[$a++]="TRUNCATE TABLE `" . $security_hash . "`;";
$sql[$a++]="TRUNCATE TABLE `" . $sessions . "`;";

	$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname);

if ($what_db->connect_error) {
    die('Connect Error (' . $what_db->connect_errno . ') '
            . $what_db->connect_error);
}else $error=false;

 	for($i=0; $i < sizeof($sql); $i++){

	
		$override=false;
	
		if(!$override){
			$result=mysqli_query($what_db, $sql[$i]);

			if(!$result){


				echo mysqli_error($result);

				$error=true;

			}else{
				?>
				
				<?php
			}
		}
	}

		mysqli_close($what_db);
	if(!$error){
	?>
	<TT>Session Management was deflated clear.</TT>
	<?php
	}
	?>
</BODY>
</HTML>