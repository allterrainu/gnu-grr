<?php
$entries="./content/set";
error_reporting(E_ERROR);
ini_set('display_errors', false);
//error_reporting(E_ALL);
//ini_set('display_errors', true);
global $terransUniteSession;
global $sid;
include_once("./../base/conf/app_silent.inc.php");
include_once("./../base/conf/db.conf.php");
include_once("./../base/conf/perlmut.conf.php");
include_once("./../base/lang/perlmut.lang.php");
include_once("./../vcnnative/lib/functions/perlmut.functions.php");
include_once("./../vcnnative/lib/classes/perlmut.classes.php");

$homedir=$entries;
$pparts=pathinfo($homedir);
$path=is_dir($homedir)?$homedir:$pparts["dirname"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 5 Transitional//EN">
<HEAD>
<TITLE> <?php echo $conf["productName"]; ?> - Server[<?php echo $conf["hostname"]; ?>]&gt;&gt;content-switcher for[<?php echo $conf["siteTitle"]; ?>]</TITLE>

<SCRIPT language="JavaScript" type="text/JavaScript">

function apply(){
	document.forms.contentSwitchSelector.submit();
}
</SCRIPT>
</HEAD>
<BODY onload="" class="contentSwitch">
<FORM name="contentSwitchSelector" action="./content/set/index.php" method="POST">
<SELECT name="switch" onchange="apply();">

<OPTION value="undefined">
</OPTION>
<?php
$d=dir($homedir);
while(false!==($entry=$d->read())){


if(is_dir($homedir . "/" . $entry)){
switch($entry){
case ".":
?>
<OPTION value="undefined">
<?php
echo "none";
break;
case "..":
?>
<OPTION value="<?php echo $homedir; ?>/default">
<?php
echo "default";
break;
case "default":
break;
default:
?>
<OPTION value="<?php echo $homedir . "/" . $entry; ?>">
<?php
echo $entry;
}
?>
</OPTION>
<?php
}
}
?>
</SELECT>
<?php
?>
</FORM>
</BODY>
</HTML>