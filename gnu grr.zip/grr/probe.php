<?php
error_reporting(E_ERROR);
ini_set('display_errors', FALSE);
//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);
ini_set('session.use_cookies', 0);
ini_set('session.use_only_cookies', 0);
ini_set('session.use_trans_sid', 0);
global $terransUniteSession, $conf, $sid;
include_once("./base/conf/db.conf.php");
include_once("./base/conf/app_silent.inc.php");
include_once("./base/conf/perlmut.conf.php");
include_once("./vcnnative/lib/functions/perlmut.functions.php");
include_once("./vcnnative/lib/classes/perlmut.classes.php");
include_once("./base/lang/perlmut.lang.php");
require("./base/conf/reqVars.php");
${$conf["APP.SESSION.sign"]}=new AuthSession($conf, $dbm);
$sid=session_continue(${$conf["APP.SESSION.sign"]});
$found=false;
$acc=isSet($_GET["acc"])?$_GET["acc"]:(isSet($_POST["acc"])?$_POST["acc"]:-1);
$dsc=$conf["dataSegmentControl"];
if(!isSet($_GET["acc"])){
	$tsa=(isSet($_GET["tsa"])?urldecode($_GET["tsa"]):".");
	$dsc=$dsc;
}else for($f=0; $f < sizeof($REQUESTVAR)&&!$found; $f++){
	$found=$REQUESTVAR[$f][$ACTION_REQUEST_INI]==$acc?true:$found;
	$tsa=$found?$REQUESTVAR[$f][$TILE_SEGMENT_ACCESS]:(isSet($_GET["tsa"])?urldecode($_GET["tsa"]):"notFound.php");
	$dsc=$found?$REQUESTVAR[$f][$DATA_SEGMENT_CONTROL]:$dsc;
}
$clamb=true;
if(!$found){
	//AUTH for older versions
	$clamb=true;
}

if($clamb){
$reclaimFile=pathinfo($tsa);
$filename=$reclaimFile["basename"];
$reclaimPath=pathinfo($dsc);
$path=isSet($reclaimPath["dirname"])?$reclaimPath["dirname"]:"";
$path=$dsc;
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");
include("./base/res/includes/jsimports.inc.php");
?>
<SCRIPT language="JavaScript" type="text/JavaScript">
<?php
echo "//alert(\"" . $sid . "\");";
?>
</SCRIPT>
<?php

require($reclaimPath . "/" . $reclaimFile);
}
?>