<?php
	$conf["secses"]["scripts"]="./base/conf/content/online/scripts.txt";
	$conf["secses"]["pages"]="./base/conf/content/online/pages.txt";
	$conf["secses"]["logintra"]="./service/switch.log";
?>