<?php

error_reporting(E_ERROR);
ini_set('display_errors', false);
//error_reporting(E_ALL);
//ini_set('display_errors', true);
/*
	Copyright (C)2015 Daniel Wiesenaecker

    
    This file is part of CupCake.

    CupCake is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CupCake is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CupCake. If not, see <http://www.gnu.org/licenses/>.


*/

	global $terransUniteSession;

	require("./../../../base/conf/db.conf.php");

	require("./../../../base/lang/perlmut.lang.php");

	require("./../../../base/conf/perlmut.conf.php");

	require("./../../../vcnnative/lib/functions/perlmut.functions.php");
	
	require("./../../../vcnnative/lib/classes/perlmut.classes.php");

	require("./../../" . $_POST["switch"] . "/conf.inc.php");

	${$conf["APP.SESSION.sign"]}=new Session($conf, $dbm);
	
header('Content-Type: text/html');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" >
<HTML>
<HEAD>
<TITLE>
	SecSesServerSwitch - version 0.3.505.34562.1a
</TITLE>
</HEAD>
<BODY>
<?php

	//connect
	$dumpTo=$conf["securityStunt"];
	$what_dbhost=$dbm["what_dbhost"];
	$what_dblogin=$dbm["what_dblogin"];
	$what_dbpwd=$dbm["what_dbpass"];
	$what_dbname=$dbm["what_dbname"];
	//***
	$dumpTo=$conf["securityStunt"];
	$scriptlist=$conf["secses"]["scripts"];
	$contentlist=$conf["secses"]["pages"];
	$loglist=$conf["secses"]["logintra"];
	$dsc=$conf["dataSegmentControl"];
	$ready=false;
	$scripts=true;
	
	
	/*BETA*/
	$rootpath=$conf["relativeroot"];
	chdir("./../../../");
	/*further conf var improove forced later*/
	$count=0;
	$a=0;
	$sql=null;
	if(!isSet($_GET["replaceStats"])) $sql[$a++]="TRUNCATE TABLE `$dumpTo`;"; else if($_GET["replaceStats"]=="NONE") ;
	
	$pplog=pathinfo($loglist);
	$logfilename="./" . $pplog["dirname"] . "/" . $pplog["basename"];
	
	
	$log=fopen($logfilename, "w+");
$li=0;
while(!$ready){
	if(!$scripts){
		$list=$contentlist;
		$ready=true;
		$dumpExtension=false;
		$li=0;
	}else{
		$list=$scriptlist;
		$dumpExtension="js";
		$scripts=false;
		$li=0;
	}
	$pp=pathinfo($list);
	$pplog=pathinfo($loglist);
	$filename="./" . $pp["dirname"] . "/" . $pp["basename"];
	$logfilename="./" . $pplog["dirname"] . "/" . $pplog["basename"];
	
	
	$fs=fopen($filename, "r");
	fputs($log, "task launched.\n");
	$logline="";
	while($file=fgets($fs)){
		if($file!=""){
			$li++;
			$pparts=pathinfo($file);
			$chk=$pparts["dirname"];
			$exp="";
			$ov=false;
			$isok=false;
			if(file_exists($chk)){
				chdir($chk);
				$sf=$pparts["extension"];
				$exp=substr($pparts["basename"], 0, strpos($pparts["basename"], $sf)) . (substr_count($sf, "js")!=0?"js":substr($sf,0, 3));
				if(file_exists($exp)){
					$isok=true;
				}else{
					fputs($log, "file #" . $exp . "# seems to be not there: >>check path on line: " . $li  . " of configuration list: \"" . $filename. "\"\n");
				}
			}else{
					$ov=true;
					fputs($log, "directory #" . $chk . "# not found: >>check path on line: " . $li  . " of configuration list: \"" . $filename. "\"\n");
			}
			if(!$ov) fputs($log, "directory is: <" . $chk . ">\n");
			$back="./";
			for($d=0; $d <= substr_count($chk, "/"); $d++){
				$back.="../";
			}
				$override=false;
				if(($dumpExtension?(substr_count($sf, $dumpExtension)==0):false)||$sf=="htaccess"){
					$override=true;
				}
				$hd=($sf=="htm"||$sf=="html"||$sf=="php"?"content-Type: text/html":($sf=="js"||$sf=="js"||$sf=="js"?"content-type: text/JavaScript":""));
				$ph=$sf=="php"?true:false;
			?>
			<?php
			if($isok){
				$count++;
				$fileHandler=fopen($exp, "r");
				$dump="";
				$l="";
				while($l=fgets($fileHandler)){
					$dump.=$l;
				}

				$dump=str_ireplace("$", "#DOL#", $dump);
				$dump=str_ireplace("\\\\\\\"", "#BOUNDEDESCAPEDQUOTE#", $dump);
				$dump=str_ireplace("\\\"", "#ESCAPEDQUOTE#", $dump);
				$dump=str_ireplace("\"", "#QUOTE#", $dump);
				$dump=str_ireplace("\'", "#ESCAPEDSINGLEQUOTE#", $dump);
				$dump=str_ireplace("'", "#SINGLEQUOTE#", $dump);
				$dump=str_ireplace(";", "#SEMICOLON#", $dump);
				$dump=str_ireplace("<?php", "#PREPROCIN#", $dump);
				$dump=str_ireplace("?>", "#PREPROCOUT#", $dump);
				$dump=str_ireplace("/*", "#CMTIN#", $dump);
				$dump=str_ireplace("*/", "#CMTOUT#", $dump);
				$dump=str_ireplace("//", "#COMMENT#", $dump);
				$dump=str_ireplace("\n", "#NL#", $dump);
				$dump=str_ireplace("\t", "#TAB#", $dump);
				$dump=str_ireplace("\\\\", "#ESCPRESET#", $dump);
				$dump=str_ireplace("\\", "#PRESET#", $dump);

				if(!$override){
					$sql[$a++]="INSERT INTO `$dumpTo` (`fileName`, `path`, `header`, `deliveryStunt`, `ph`) VALUES('" . $exp . "', '" . $dsc . "', '" . $hd . "', '" . $dump . "', " . ($ph?"1":"0") . ");";
					$logline="adding file: \""  . $exp . "\" " . $hd . " in dataSegmentControl: dsc=[ " . $dsc . "] to DataBase-TABLE " .  $dumpTo . "\n";
					if($isok) fputs($log, $logline);
				}
			}
			
			if(!$ov) chdir($back);
		}
	}
}
	$logline="\ntotal added " . $count . " files to DataBase-TABLE " .  $dumpTo . "\n";
	fputs($log, $logline);
	$itf=${$conf["APP.SESSION.sign"]}->getDate(false, false);
	$itf=${$conf["APP.SESSION.sign"]}->formatDate($itf, "WD MON D HH:MM:SS YYYY", false);
	fputs($log, "process by: <" . $_SERVER["REMOTE_ADDR"] . ">\n");
	fputs($log, "agent done: <" . $_SERVER["HTTP_USER_AGENT"] . ">\n");
	fputs($log, "reqtime is: <" . $itf . ">\n");
	
	//***simply in
	
	//***BETA -> going to be replaced
	$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname);

if ($what_db->connect_error) {
    die('Connect Error (' . $what_db->connect_errno . ') '
            . $what_db->connect_error);
}else $error=false;

 	for($i=0; $i < sizeof($sql); $i++){

	
		$override=false;
	
		if(!$override){
			$result=mysqli_query($what_db, $sql[$i]);

			if(!$result){


				echo mysqli_error();

				$error=true;

			}else{
				?>
				
				<?php
			}
		}
	}

		mysqli_close($what_db);
	if(!$error){
	?>
		<P><BIG><TT>featured SecSes Relay ServerSwitch succesful.</BIG></TT></P>
	<?php
	}
	?>
</BODY>
</HTML>
