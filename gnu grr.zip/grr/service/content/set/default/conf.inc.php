<?php
	$conf["secses"]["scripts"]="./base/conf/scripts.txt";
	$conf["secses"]["pages"]="./base/conf/pages.txt";
	$conf["secses"]["logintra"]="./service/switch.log";
?>
