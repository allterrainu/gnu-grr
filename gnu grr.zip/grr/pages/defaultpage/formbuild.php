<?php 
 
	error_reporting(E_ERROR); 
 
	ini_set('display_errors', FALSE); 
 
	//error_reporting(E_ALL); 
 
	//ini_set('display_errors', TRUE); 
 
	require("./base/conf/app_silent.inc.php"); 
 
	require_once("./base/lang/perlmut.lang.php"); 
 
	require("./base/conf/perlmut.conf.php"); 
 
	 
	global ${$conf["APP.SESSION.sign"]}, $conf; 
	 
	require("./base/lang/perlmut.lang.php");
 
global $lang_set, $formDeclare, $lang, $errCodes, $sid, $formWidth, $formMaxRequest, ${$conf["APP.SESSION.sign"]}, $contact_addi, $blancLineFontSizePT, $inputFieldFontSizePT, $optionField;  
$formWidth=isSet($_GET["formWidth"])?$_GET["formWidth"]:540; 
$classnameInputFlow="flowBackgroundContactForm"; 
$optionField="selectOptionFormat"; 
require("./base/res/includes/formdeclare.php");  
$errCodes=null; 
 
function blancLine(){  
	global $blancLineFontSizePT;  
	echo "<SPAN style=\"font-family: monotype, universal, verdana; font-size: " . ($blancLineFontSizePT*$_GET["scrRatio"]) . "pt; \"><BR class=\"blancLine\"></SPAN>";  
} 
 
function noDispatch(){  
	global $errCodes;  
	if(isSet($errCodes)){  
		if(sizeof($errCodes)==0) return true;  
	}else{  
		return true;  
	}  
	return false;  
}  
  
  
  
function getFieldByCaption($caption, $withPrompt, $classnameCaption, $classnameField, $classnameError, $classnameImage, $classnameInputCharge, $inputFormatClass, $promptImage, $inputFormatAreaClass){  
 
	global $conf;	 
 
	global $lang_set, $formDeclare, $lang, $errCodes, $formWidth, $inputFieldFontSizePT, $optionField, ${$conf["APP.SESSION.sign"]};  
	  
	$s=getOrderNrByCaption($caption);  
	$v=($caption=="submit"?-1:($s!=-1?$s:-2)); 
 
?> 
	<SPAN <?php echo "style=\"background-color: #DF67A0; width: " . $formWidth*$_GET["scrRatio"] . "px; \"" ;?>> 
	<?php 
	 
	if($v>=-1){  
		if($v==-1){  
		?>  
<TABLE cellspacing="0" cellpadding="0" style="width: 100%; ">  
<TR>  
<TD class=<?php echo "\"" . $classnameInputCharge . "\""; ?>> 
<?php ?> 
<?php			  
			if($promptImage) { 
?> 
<SPAN <?php echo "class=\"" . $classnameInputCharge . "\" style=\"\"" ;?>><?php echo "<A href=\"javascript: document.forms['secSesForm'].submit(); \"><IMG class=\"" . $classnameImage . "\" src=\"" . $formDeclare[sizeof($formDeclare)-1]["prompt"]["imgsrc"] . "\" alt=\"" . $formDeclare[sizeof($formDeclare)-1]["prompt"][$lang_set] . "\" title=\"" . $formDeclare[sizeof($formDeclare)-1]["prompt"][$lang_set] . "\" style=\"width: " . ($formDeclare[sizeof($formDeclare)-1]["prompt"]["imagewidth"]*$_GET["scrRatio"]) . "; \"></A>";  
?> 
</SPAN> 
<?php			 
			}else{ 
?> 
<SPAN <?php echo "classname=\"". $classnameInputCharge . "\" style=\"background-color: #DF67A0; \"";?>> 
<?php 
			echo "<INPUT class=\"" . $classnameField . "\" style=\"text-aling: right; font-size: " . ($inputFieldFontSizePT*$_GET["scrRatio"]) . "pt; \" type=\"submit\" value=\"" . $lang["buttons"]["send"]["caption"][$lang_set] . "\">";  
?> 
</SPAN> 
<?php 
			} 
 ?> 
 </TD> 
 </TR> 
 </TABLE> 
<?php 
}else{  
			$_SESSION[$formDeclare[$v]["caption"]]=isSet($_POST[$formDeclare[$v]["caption"]])?$_POST[$formDeclare[$v]["caption"]]:"";  
			switch($caption){  
				case "email":  
?>  
<TABLE cellspacing="0" cellpadding="0" style="width: 100%; ">  
<TR>  
<TD class=<?php echo "\"" . $classnameCaption . "\""; ?>> 
<?php 
					if(isSet($errCodes)) if(sizeof($errCodes)>0) if(isSet($errCodes["email"])){ 
?>					 
<SPAN <?php echo "class=\"" . $classnameError . "\" style=\"font-size: " . ($formDeclare[$v]["prompt"]["fontSize"]*$_GET["scrRatio"]) . "; \"";?>><?php echo $lang["errors"][$errCodes["email"]]["msg"][$lang_set] . "<br>";  
?> 
</SPAN> 
<?php					 
}else{  
					blancLine();  
					}  
					if($withPrompt&&$promptImage){  
?>					 
<SPAN <?php echo "class=\"" . $classnameField . "\"";?>><?php echo "<IMG class=\"" . $classnameImage . "\" src=\"" . $formDeclare[$v]["prompt"]["imgsrc"] . "\" alt=\"" . $formDeclare[$v]["prompt"][$lang_set] . "\" title=\"" . $formDeclare[$v]["prompt"][$lang_set] . "\" style=\"width: " . ($formDeclare[$v]["prompt"]["imagewidth"]*$_GET["scrRatio"]) . "; \">";  
					 
?> 
</SPAN> 
<?php		 
					}else if($withPrompt){ 
?>					 
<SPAN <?php echo "class class=\"" . $classnameField . "\">" . $lang["prompts"][0]["msg"][$lang_set] . ""; 
?> 
</SPAN> 
<?php 
					} 
?> 
					</TD>  
					<TD class=<?php echo "\"" . $classnameField . "\""; ?>> 
 
<SPAN <?php echo "class=\"" . $classnameInputCharge . "\" style=\"background-color: #DF67A0; \"";?>><?php echo "<INPUT class=\"" . $inputFormatClass . "\" style=\"font-size: " . ($inputFieldFontSizePT*$_GET["scrRatio"]) . "pt; \" value=\"" . (isSet($_SESSION[$formDeclare[$v]["caption"]])?$_SESSION[$formDeclare[$v]["caption"]]:"") . "\" name=\"email\" type=\"text\" size=\"" . $formDeclare[$v]["size"] . "\" maxlength=\"" . $formDeclare[$v]["maxlength"] . "\">";  
?> 
</SPAN> 
</TD>  
</TR>  
</TABLE> 
<?php  
						if(noDispatch()) blancLine();  
				break;  
				case "emailRetype":  
					?>  
<TABLE cellspacing="0" cellpadding="0" style="width: 100%; ">  
<TR>  
<TD class=<?php echo "\"" . $classnameCaption . "\""; ?>> 
 
<?php 
					if(isSet($errCodes)) if(sizeof($errCodes)>0) if(isSet($errCodes["emailRetype"])){ 
?> 
<SPAN <?php echo "class=\"" . $classnameError . "\" style=\"font-size: " . ($formDeclare[$v]["prompt"]["fontSize"]*$_GET["scrRatio"]) . "; \"";?>><?php echo $lang["errors"][$errCodes["emailRetype"]]["msg"][$lang_set] . ""; 
?> 
 
</SPAN><br> 
<?php 
					}else{  
					  
					blancLine();  
					  
					}  
					if($withPrompt&&$promptImage){ 
?> 
<SPAN <?php echo "class=\"" . $classnameField . "\"";?>><?php echo "<IMG class=\"" . $classnameImage . "\" src=\"" . $formDeclare[$v]["prompt"]["imgsrc"] . "\" alt=\"" . $formDeclare[$v]["prompt"][$lang_set] . "\" title=\"" . $formDeclare[$v]["prompt"][$lang_set] . "\" style=\"width: " . ($formDeclare[$v]["prompt"]["imagewidth"]*$_GET["scrRatio"]) . "; \">";  
?> 
</SPAN>					 
<?php				 
					}else if($withPrompt){ 
?> 
<SPAN <?php echo "class=\"" . $classnameField . "\"";?>><?php echo $lang["prompts"][5]["msg"][$lang_set]; 
?> 
</SPAN> 
<?php 
					}  
?> 
					</TD>  
					<TD class=<?php echo "\"" . $classnameField . "\""; ?>>  
<SPAN <?php echo "classclass=\"" . $classnameInputCharge . "\" style=\"background-color: #DF67A0; \"";?>><?php echo "<INPUT class=\"" . $inputFormatClass . "\" style=\"font-size: " . ($inputFieldFontSizePT*$_GET["scrRatio"]) . "pt; \" value=\"" . (isSet($_SESSION[$formDeclare[$v]["caption"]])?$_SESSION[$formDeclare[$v]["caption"]]:"") . "\" name=\"emailRetype\" type=\"text\" size=\"" . $formDeclare[$v]["size"] . "\" maxlength=\"" . $formDeclare[$v]["maxlength"] . "\">";  
?> 
</SPAN> 
</TD>  
</TR>  
</TABLE>  
<?php  
						if(noDispatch()) blancLine();  
				break;  
				default:  
?>  
<TABLE cellspacing="0" cellpadding="0" style="width: 100%; ">  
<TR>  
<TD class=<?php echo "\"" . $classnameCaption . "\""; ?>>  
<?php  
					if(isSet($errCodes)) if(sizeof($errCodes)>0) if(isSet($errCodes[$formDeclare[$v]["caption"]])){ 
?> 
<SPAN <?php echo "class=\"" . $classnameError . "\" style=\"font-size: " . ($formDeclare[$v]["prompt"]["fontSize"]*$_GET["scrRatio"]) . "; \"";?>><?php echo $lang["errors"][$errCodes[$formDeclare[$v]["caption"]]]["msg"][$lang_set] . "<br>";  
?> 
</SPAN> 
<?php		 
					}else{  
					blancLine();  
					}  
					if($withPrompt&&$promptImage){ 
?> 
<SPAN <?php echo "class=\"" . $classnameField . "\"";?>><?php echo "<IMG class=\"" . $classnameImage . "\" src=\"" . $formDeclare[$v]["prompt"]["imgsrc"] . "\" alt=\"" . $formDeclare[$v]["prompt"][$lang_set] . "\" title=\"" . $formDeclare[$v]["prompt"][$lang_set] . "\" style=\"width: " . ($formDeclare[$v]["prompt"]["imagewidth"]*$_GET["scrRatio"]) . "; \">";  
?> 
</SPAN> 
<?php 
					 
					}else if($withPrompt){ 
?>		 
<SPAN <?php echo "class=\"" . $classnameField . "\"";?>><?php echo $formDeclare[$v]["prompt"][$lang_set];  
?> 
</SPAN> 
<?php				 
					} 
?> 
					</TD>  
					<TD class=<?php echo "\"" . $classnameInputCharge . "\""; ?>> 
					<?php /* 
 
					sincerly break out! <BEGIN> 
 
					*/?> 
 
					<SPAN <?php echo "class=\"" . $classnameField . "\"";?>> 
 
					<?php 
					if($formDeclare[$v]["formElement"]=="area"){  
						//TEXTAREA  
						$val="";  
						if(sizeof($_POST)>0) if(isSet($_POST["sent"])){  
							$val=isSet($_SESSION[$formDeclare[$v]["caption"]])?$_SESSION[$formDeclare[$v]["caption"]]:"";  
						}  
						echo "<TEXTAREA class=\"" . $inputFormatAreaClass . "\" style=\"font-size: " . ($inputFieldFontSizePT*$_GET["scrRatio"]) . "pt; \" cols=\"" . $formDeclare[$v]["cols"] . "\" rows=\"" . $formDeclare[$v]["rows"] . "\" maxlength=\"" . $formDeclare[$v]["maxlength"] . "\" name=\"" . $formDeclare[$v]["caption"] .  "\">";  
						echo $_SESSION["request"];  
						echo "</TEXTAREA>";  
					}else if($formDeclare[$v]["formElement"]=="text"){  
						//TEXT  
						$val="";  
						if(sizeof($_POST)>0) if(isSet($_POST["sent"])){  
							$val=isSet($_SESSION[$formDeclare[$v]["caption"]])?$_SESSION[$formDeclare[$v]["caption"]]:"";  
						}  
						echo "<INPUT" . (isSet($formDeclare[$v]["onchange"])?" onchange=\"" . $formDeclare[$v]["onchange"]  . "(value);\"":"") . " class=\"" . $inputFormatClass . "\" style=\"font-size: " . ($inputFieldFontSizePT*$_GET["scrRatio"]) . "pt; \" type=\"text\" size=\"" . $formDeclare[$v]["size"] . "\" maxlength=\"" . $formDeclare[$v]["maxlength"] . "\" name=\"" . $formDeclare[$v]["caption"] .  "\" value=\"$val\">";  
					}else if($formDeclare[$v]["formElement"]=="select"){  
						//SELECT  
						echo "<SELECT" . (isSet($formDeclare[$v]["onchange"])?" onchange=\"" . $formDeclare[$v]["onchange"]  . "(value);\"":"") . " class=\"" . $classnameField . "\" name=\"". $formDeclare[$v]["caption"] ."\">\n";  
							$list=false;  
							if(isSet($formDeclare[$v]["options"])){  
								if(sizeof($formDeclare[$v]["options"])>0){  
									for($s=0; $s < sizeof($formDeclare[$v]["options"]); $s++){  
										$sel=$formDeclare[$v]["options"][$s]["value"]==$_SESSION[$formDeclare[$v]["caption"]]?" selected":"";  
										echo "<OPTION class=\"" . $optionField . "\" value=\"" . $formDeclare[$v]["options"][$s]["value"] . "\"$sel>" . $formDeclare[$v]["options"][$s]["caption"] . "</OPTION>\n";  
									}  
								}else $list=true;  
							}else $list=true;  
							if($list){  
								$result=${$conf["APP.SESSION.sign"]}->doQuery($formDeclare[$v]["selection"]["query"]);  
								if($result){  
									$ov=true;  
									$sel="";  
									while($arow=mysqli_fetch_array($result, MYSQLI_ASSOC)){  
										$sel=($sel==" selected"&&!$ov?$sel:($arow[$formDeclare[$v]["selection"]["valueField"]]==$_SESSION[$formDeclare[$v]["caption"]]?" selected":($arow[$formDeclare[$v]["selection"]["valueField"]]==$formDeclare[$v]["selection"]["standardValue"]?" selected":"")));  
										$ov=$arow[$formDeclare[$v]["selection"]["valueField"]]==$formDeclare[$v]["selection"]["standardValue"]?true:false;  
										echo "\n<OPTION class=\"" . $optionField . "\" value=\"" . $arow[$formDeclare[$v]["selection"]["valueField"]] . "\"$sel>". $arow[$formDeclare[$v]["selection"]["captionField"]] . "</OPTION>";  
									}  
								}  
							}  
						echo "</SELECT>";  
					} 
				?> 
				<?php /* 
 
				sincerly break out! </BEGIN> 
 
				*/?> 
 
				<SPAN <?php echo "class=\"" . $classnameField . "\"";?>> 
 
				<?php 
				//**** 
				?> 
				</TD>  
				</TR>  
				</TABLE> 
				  
			<?php 
					if(noDispatch()) blancLine();  
			}  
			  
		}		  
	} 
	?> 
	</SPAN> 
<?php 
}  
  
  
function getOrderNrByCaption($caption){  
	global $lang_set, $formDeclare, $lang, $errCodes;  
	$found=false;  
	$v=0;  
	for(; $v < sizeof($formDeclare)&&!$found; $v++){  
		$found=$formDeclare[$v]["caption"]==$caption?true:false;  
	}  
	return ($found?--$v:-1);  
}  
function getFieldByOrderNr($nr, $withPrompt, $classnameCaption, $classnameField, $classnameError, $classnameImage, $classnameInputCharge, $inputFormatClass, $promtImage, $inputFormatAreaClass){  
	global $lang_set, $formDeclare, $lang, $errCodes;  
	return getFieldByCaption($formDeclare[$nr]["caption"], $withPrompt, $classnameCaption, $classnameField, $classnameError, $classnameImage, $classnameInputCharge, $inputFormatClass, $promtImage, $inputFormatAreaClass);  
}  
?>  
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">  
<HTML>  
<HEAD>  
<link rel="styleSheet" href="./base/res/styles/showcase.css" type="text/css">  
<STYLE type="text/StyleSheet">  
<?php  
	echo ".selectOptionFormat {font-size: " . ($inputFieldFontSizePT*$_GET["scrRatio"]) . "pt; }";  
?>  
</STYLE>  
<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1">  
<TITLE>  
<?php  
	echo $conf["siteTitle"] . " - Kontakt";  
?>  
</TITLE>  
<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=isNum.js">  
</SCRIPT>  
<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=tokenize.js">  
</SCRIPT>  
<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=urlGet.js">  
</SCRIPT> 
<SCRIPT language="JavaScript">  
	var countrySet=<?php echo "\"" . $formDeclare[9]["selection"]["standardValue"] . "\";";?>  
	  
	function setCityname(val){  
		document.forms[0].location.value=val;  
	}  
	  
	function getCityname(){  
		window.parent.makeSearchReq(document.forms[0].plz.value, countrySet);  
	}  
	  
	function setCountry(country){  
		countrySet=country;  
		window.parent.updateSearchReq(country);  
	}  
</SCRIPT>  
<?php  
  
?>  
<SCRIPT language="JavaScript" type="text/JavaScript">  
function getIniVars(){  
<?php	  
		//echo "return '" . $sid . "';";	  
?>  
}  
//alert("!!!" + getIniVars());  
</SCRIPT>  
<?php  
  
?>  
</HEAD>  
<BODY onload="/*prepare();*/" style="margin-bottom: 90px; background-color: transparent; ">  
<?php  
if($sid==$_SESSION["gate_ini"]){  
	if(isSet($_POST)) if(isSet($_POST["sent"])){  
		for($v=0; $v < sizeof($formDeclare); $v++){  
			$_SESSION[$formDeclare[$v]["caption"]]=isSet($_POST[$formDeclare[$v]["caption"]])?$_POST[$formDeclare[$v]["caption"]]:"";  
		}  
	}  
	$errCodes=null;  
	$pattern="_\A[\w!#$%&'*+/=?`{|}~^-]+(?:\.[\w!#$%&'*+/=?`{|}~^-]+)*@?(?:[A-Z0-9-]+\.)+[A-Z]{2,99}\Z_";  
				  
	if(isSet($_POST)) if(sizeof($_POST)>0){  
		if($_SESSION["email"]==""){  
			$errCodes["email"]=2;  
		}else if(!preg_match($pattern, strtoupper($_POST["email"]))){  
			$errCodes["email"]=3;  
		}  
		if($_SESSION["emailRetype"]==""){  
			$errCodes["emailRetype"]=38;  
		}else if(!preg_match($pattern, strtoupper($_POST["emailRetype"]))){  
			$errCodes["emailRetype"]=3;  
		}else if($_POST["emailRetype"]!=$_SESSION["email"]){  
			$errCodes["emailRetype"]=37;  
		}  
?> 
 
<?php		 
		for($v=0; $v< sizeof($formDeclare); $v++){  
			if($formDeclare[$v]["dutyfield"]){  
				if($_SESSION[$formDeclare[$v]["caption"]]==""&&$formDeclare[$v]["caption"]!="submit"){  
					$errCodes[$formDeclare[$v]["caption"]]=36;  
				}else{  
					//deprecated  
					//echo "<INPUT classname=\"" . $classname . "\" type=\"hidden\" value=\"" . $_POST[$formDeclare[$v]["caption"]] . "\" name=\"" . $formDeclare[$v]["caption"] . "\">";  
				}  
			}  
		} 
		 
 
		if(noDispatch()){  
			if(!isSet($_SESSION["crtl"])){  
				$_SESSION["crtl"]=1;  
			}  
			$ovd=true;  
			$suc=false;  
			if($_SESSION["aquired"]==$_SESSION["clearancy"]) if($_SESSION["crtl"]<=$formMaxRequest){  
					$replyAddi=$_SESSION["email"];  
					$itf=${$conf["APP.SESSION.sign"]}->formatDate(${$conf["APP.SESSION.sign"]}->getDate(false, false), "WD MON D HH:MM:SS YYYY", false);  
					global $contact_addi;  
					$message = "Die IP-Adresse " . $_SERVER["REMOTE_ADDR"] . "\n\n hat ueber: " . (isSet($_SERVER["HTTPS"])?"https":"http") . " Protoll ueber unseren Host " . $_SERVER["HTTP_HOST"] . "\n\nmit dem Skript: " . (isSet($_SERVER["HTTP_REFERER"])?$_SERVER["HTTP_REFERER"]:"") . "\n\nund dem Useragent:\n" . $_SERVER["HTTP_USER_AGENT"] . "\nmit der SessionID:" .  $sid . "\n\tEine Nachricht am " . $itf . " an uns geschickt: ";  
					$message.="folgende Nachricht >>";  
					$message.="wurde von der email-adresse: "  . $_SESSION["email"];  
					$message.="\n an " . $contact_addi . " geschickt\n\n\n" . $_SESSION["request"];  
					$message.="\nAbsender der Nachricht: " . $_SESSION["salutation"] . " " . $_SESSION["firstname"] . " " . $_SESSION["lastname"] . " aus " . $_SESSION["plz"] . " " . $_SESSION["location"] . "\n- " . $_SESSION["country"] . " - ";  
					$header="FROM: " . $fromAddi . "\n";  
					$header .= "Reply-To: " . $replyAddi . "\n";  
					$header .= "Bcc:\n";  
					$header .= "X-Mailer: PHP/" . phpversion(). "\n";  
					$header .= "X-Sender-IP: " . (isSet($_SERVER["REMOTE_ADDRESS"])?$_SERVER["REMOTE_ADDRESS"]:"") . "\n";  
					$header .= "Content-Type: text/plain; charset=iso-8859-1\n";  
					if (@mail($contact_addi,"incoming message: '" . $_SESSION["topic"] . "'",$message, $header)){  
						//sending ok.  
						$suc=true;  
						if(isSet($_SESSION["crtl"])) $_SESSION["crtl"]++;  
					}else{  
						//sending failed  
						//routine  
						  
					}  
			}else{  
				$ovd=true;  
				?>  
					<SPAN <?php echo "class=\"" . $classnameInputFlow . "\" style=\"background-color: #DF67A0; width: " . $formWidth*$_GET["scrRatio"] . "px; \"" ;?>>Leider konnte Deine Nachricht an <?php echo $conf["siteTitle"]; ?> nicht gesendet werden. <I>Es wurden <B>zu viele Nachrichten</B> gesendet.</I> Bitte sp&auml;ter nochmal probieren.</SPAN>  
				<?php  
			}  
		}  
	}  
	  
if(!noDispatch()||!isSet($_POST["sent"])){  
?> 
<SPAN <?php echo "class=\"" . $classnameInputFlow . "\" style=\"background-color: #DF67A0; width: " . $formWidth*$_GET["scrRatio"] . "px; \"" ;?>> 
	<FORM name="secSesForm" action="./req.php?tsa=formbuild.php&scrRatio=<?php echo $_GET["scrRatio"];?>" method="POST">  
		<INPUT type="hidden" name="sent" value="">  
		<?php  
		//actual contact form		  
		for($v=0; $v < sizeof($formDeclare); $v++){ 
		?> 
		<SPAN <?php echo "class=\"" . $classnameInputFlow . "\" style=\"background-color: #DF67A0; width: " . $formWidth*$_GET["scrRatio"] . "px; \"" ;?>> 
		<?php 
			getFieldByOrderNr($v, true, "captionContactForm", "fieldContactForm", "errorContactForm", "imageContactForm", "inputCharge", "inputField", true, "inputArea");  
		?> 
		</SPAN> 
		<?php 
		}  
		?>  
	</FORM>  
		<?php 
?> 
</SPAN> 
<?php 
	}else if(isSet($_POST)) if(isSet($_POST["sent"])){  
?> 
<SPAN <?php $ovd=false; echo "class=\"" . $classnameInputFlow . "\" style=\"background-color: #DF67A0; width: " . $formWidth*$_GET["scrRatio"] . "px; \"" ;?>> 
	<?php 
	if($suc){ 
			?>  
			<SPAN>Deine Nachricht an <?php echo $conf["siteTitle"]; ?> wurde gesendet.</SPAN>  
			<?php  
	}else if(!$ovd){ 
			?>  
			<SPAN>Leider konnte Deine Nachricht an <?php echo $conf["siteTitle"]; ?> nicht gesendet werden. Bitte sp&auml;ter nochmal probieren.</SPAN>  
			<?php  
	}  
	?> 
</SPAN> 
<?php	  
	}  
}  
?>  
</BODY>  
</HTML>  
<?php  
?> 
