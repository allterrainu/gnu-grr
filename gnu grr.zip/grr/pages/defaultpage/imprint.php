<?php 
 
	//error_reporting(E_ERROR); 
 
	//ini_set('display_errors', FALSE); 
 
	error_reporting(E_ALL); 
 
	ini_set('display_errors', TRUE); 
 
	require("./base/conf/app_silent.inc.php"); 
 
	require_once("./base/lang/perlmut.lang.php"); 
 
	require("./base/conf/perlmut.conf.php"); 
 
	 
	global ${$conf["APP.SESSION.sign"]}, $conf; 
	 
	require("./base/lang/perlmut.lang.php"); 
$baseVarsTable=$conf["baseVars"];
$baseProduct=$conf["productName"];

	header('Content-Type: text/html');
	
	$resT=$terransUniteSession->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'adress';");
if($resT){
	$row=mysqli_fetch_array($resT, MYSQLI_ASSOC);
	$mokTitleName=$row["caption"];
	$mokTitleSlogan=$row["description"];

}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<HEAD>
<TITLE><?php echo $mokTitleName; ?></TITLE>
<link rel="styleSheet" href="./base/res/styles/default.css" type="text/css">
<?php
include("./base/res/includes/jsimports.inc.php");
?>
</HEAD>
<BODY onload="" style="background-color: transparent; margin: 0 0 0 0; color: #FFFFFF; ">
<?php
	$dateFrozen=isSet($_SESSION["viewDate"])?$_SESSION["viewDate"]:getDate();
	$gts=$terransUniteSession->formatDate($dateFrozen , "DD. MN YYYY", false);
	$dateFrozenh=$terransUniteSession->getDate($dateFrozen, true);
	$hts=$terransUniteSession->formatDate($dateFrozenh , "DD. MN YYYY", true);

//relevant comment seek implementation

$res1=$terransUniteSession->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyname';");
if($res1){
	$row=mysqli_fetch_array($res1, MYSQLI_ASSOC);
	$mokCompanyName=$row["value"];
	$mokCompanySlogan=$row["description"];
}

$res2=$terransUniteSession->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'phone';");
if($res2){
	$row=mysqli_fetch_array($res2, MYSQLI_ASSOC);
	$mokPhoneNumber=$row["value"];
	$mokPhoneEntry=$row["caption"];
	$mokPhoneText=$row["description"];
}

$res3=$terransUniteSession->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'adress';");
if($res3){
	$row=mysqli_fetch_array($res3, MYSQLI_ASSOC);-
	$mokAdress=$row["value"];
}

$res4=$terransUniteSession->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyId';");
if($res4){
	$row=mysqli_fetch_array($res4, MYSQLI_ASSOC);
	$mokVAT=$row["caption"];
	$mokId=$row["value"];
	$mokImprint=$row["description"];
}


$res5=$terransUniteSession->doQuery("SELECT DISTINCT `value`, `description`, `caption` FROM `$baseVarsTable` WHERE `varname` = 'companyLocals';");
if($res5){
	$row=mysqli_fetch_array($res5, MYSQLI_ASSOC);
	$mokCourt=$row["value"];
	$mokLaw=$row["caption"];
}

?>
<DIV style="margin: 60px; vertical-align: middle; text-align: center; ">
<DIV><IFRAME src="req.php?tsa=index2.htm"></IFRAME>
<DIV class="companyNamePlain"><H1><?php echo $mokCompanyName; ?></H1></DIV>
<?php
?>
<DIV class="companySlogan"><H2><?php echo $mokCompanySlogan; ?></H2></DIV>
<?php
?>
<DIV class="subtext"><?php echo $mokPhoneEntry; ?>
<?php
?>
<DIV class="subtext"><?php echo $mokPhoneNumber; ?></DIV>
<?php
?>
<DIV class="subtext"><?php echo $mokPhoneText; ?></DIV>
<?php
?>
<DIV class="companySlogan"><H2><?php echo $mokTitleSlogan; ?></H2></DIV>
</DIV>
	<DIV style="margin: 60px;">
		<DIV class="subtext"><?php echo $mokImprint; ?></DIV><BR>
		<DIV class="subtext"><?php echo $mokVAT; ?></DIV>
		<DIV class="subtext"><?php echo $mokId; ?></DIV>
		<SPAN class="subtext"><?php echo $mokLaw; ?></SPAN>
		<SPAN class="subtext"><?php echo $mokCourt; ?></SPAN>
		<DIV class="subtext"><?php echo $mokCompanyName; ?></DIV>
		<DIV class="subtext"><?php echo $mokAdress; ?></DIV>
	</DIV>
</DIV>
</BODY>
</HTML>