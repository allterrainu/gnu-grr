<?php 

	require("./base/conf/app_silent.inc.php");

	global $worlds;

	require("./base/conf/perlmut.conf.php");
	
	require_once("./base/lang/perlmut.lang.php");

	global ${$conf["APP.SESSION.sign"]};

	header('Content-Type: text/html');

?> 

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 

<html lang="<?php echo "" . ${$conf["APP.SESSION.sign"]}->lang . ""; ?>">

<HEAD> 

<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1"> 

<META name="language" content="<?php echo "" . ${$conf["APP.SESSION.sign"]}->lang . ""; ?>">

<?php   

echo "<TITLE>" . $conf["siteTitle"] . "</TITLE>";   

echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";   

?>   

<link rel="styleSheet" href="./base/res/styles/default.css" type="text/css">

<?php   

echo "<meta name=\"description\" content=\"" . $conf["description"] . "\">";   

echo "<meta name=\"keywords\" content=\"" . $conf["keywords"] . "\">";   

echo "<meta name=\"author\" content=\"" . $conf["contentManager"] . "\">";   

echo "<meta name=\"contact_addr\" content=\"" . $conf["webmasterEmail"] . "\">"; 

?> 

	<SCRIPT language="JavaScript" type="text/Javascript"> 

	function enableLinkAble(){ 

		 

	} 

</SCRIPT> 

<SCRIPT language="JavaScript" type="text/Javascript" src="./loadScript.php?tsa=spoolLetter.js"> 

</SCRIPT> 

</HEAD> 

<BODY style="background-color: transparent; overflow: hidden; " onload=""> 


<?php

  include("./base/res/includes/jsimports.inc.php"); 

?>

<SCRIPT language="JavaScript" type="text/Javascript"> 

	var isTouch = (('ontouchstart' in window) || (navigator.msMaxTouchPoints > 0)); 

	try{ 

 

		if(isTouch){ 

			// 

		} 

	}catch(e){ 

 

	}finally{ 

		if(true){ 

			document.addEventListener("mousemove", slapO_MM, false); 

		} 

	} 

 

	function slapO_MM(e){ 

		e=e?e:event; 

		 

		var x=e.clientX-parseInt(window.parent.clientFrame.getLayer().style.left); 

		var y=e.clientY-parseInt(window.parent.clientFrame.getLayer().style.top); 

		window.parent.myIco_4_Frame.getWindow().MousePositionSet(new Point(x, y)); 

	} 

	 

	function MouseCapturePump(e){ 

		e=e?e:event; 

		var x=e.clientX-parseInt(window.parent.myIco_4_Frame.getLayer().style.left); 

		var y=e.clientY-parseInt(window.parent.myIco_4_Frame.getLayer().style.top); 

		window.parent.myIco_4_Frame.getWindow().MousePositionSet(new Point(x, y)); 

	} 

</SCRIPT> 

<SCRIPT language="JavaScript" type="text/JavaScript"> 

	var clientFrame = null; 

</SCRIPT> 
<?php

${$conf["APP.SESSION.sign"]}->virtualcookie_write(uniqid());
?>
</BODY>
</HTML>
