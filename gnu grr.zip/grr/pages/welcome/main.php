<?php 

	require("./base/conf/app_silent.inc.php");

	global $worlds;

	require("./base/conf/perlmut.conf.php");
	
	require_once("./base/lang/perlmut.lang.php");

	global ${$conf["APP.SESSION.sign"]};

	header('Content-Type: text/html');

?> 

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 

<html lang="<?php echo "" . ${$conf["APP.SESSION.sign"]}->lang . ""; ?>">

<HEAD> 

<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1"> 

<META name="language" content="<?php echo "" . ${$conf["APP.SESSION.sign"]}->lang . ""; ?>">

<?php   

echo "<TITLE>" . $conf["siteTitle"] . "</TITLE>";   

echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";   

?>   

<link rel="styleSheet" href="./base/res/styles/default.css" type="text/css">

<?php   

echo "<meta name=\"description\" content=\"" . $conf["description"] . "\">";   

echo "<meta name=\"keywords\" content=\"" . $conf["keywords"] . "\">";   

echo "<meta name=\"author\" content=\"" . $conf["contentManager"] . "\">";   

echo "<meta name=\"contact_addr\" content=\"" . $conf["webmasterEmail"] . "\">"; 

?> 

<?php

  include("./base/res/includes/jsimports.inc.php"); 

?>

<SCRIPT language="JavaScript" type="text/JavaScript"> 

 

 

document.ondragstart=function(){ return false; }; 

document.ondrop=function(){ return false; }; 

					 

 

function getBorderByEventTarget(e){ 

	var found=-1; 

	for(var v=0; (v < itsTunedBorders.length)&&found<0; v++){ 

		found=itsTunedBorders[v].isEventCaller(e)?v:found; 

	} 

	return found; 

} 

 

var isTouch = (('ontouchstart' in window) || (navigator.msMaxTouchPoints > 0)); 

try{ 

 

	if(isTouch){ 

		document.addEventListener("touchmove", slapO_TM, false); 

		document.addEventListener("touchstart", slapO_TS, false); 

		document.addEventListener("touchend", slapO_NO, false); 

	} 

}catch(e){ 

 

}finally{ 

	if(true){ 

		document.addEventListener("mousemove", slapO_MM, false); 

		document.addEventListener("mousedown", slapO_MD, false); 

		document.addEventListener("mouseup", slapO_MU, false); 

	} 

} 

 

function slapO_MM(e){ 

	e=e?e:event; 

	 

	var x=e.clientX-parseInt(window.parent.myIco_4_Frame.getLayer().style.left); 

	var y=e.clientY-parseInt(window.parent.myIco_4_Frame.getLayer().style.top); 

	window.parent.myIco_4_Frame.getWindow().MousePositionSet(new Point(x, y)); 

 

	var relH1=0; 

	var relH2=0; 

	var relV1=0; 

	var relV2=0; 

		for(found=0; found<itsTunedBorders.length; found++){ 

			if(itsTunedBorders[found].drag){ 

				if(itsTunedBorders[found].itsAlign==AlignSet.LEFT) relH1=e.clientX-itsTunedBorders[found].touchStart; 

				if(itsTunedBorders[found].itsAlign==AlignSet.RIGHT) relH2=itsTunedBorders[found].touchStart-e.clientX; 

				if(itsTunedBorders[found].itsAlign==AlignSet.TOP) relV1=e.clientY-itsTunedBorders[found].touchStart; 

				if(itsTunedBorders[found].itsAlign==AlignSet.BOTTOM) relV2=itsTunedBorders[found].touchStart-e.clientY; 

			} 

		} 

		 

		var hori=(relH1>0?((relH1>relV1)?true:false):((relH2>relV2)?true:false)); 

		var hasAgile=false; 

		for(found=0; found<itsTunedBorders.length; found++){ 

			hasAgile=itsTunedBorders[found].agile?true:hasAgile; 

		} 

		for(found=0; found<itsTunedBorders.length; found++){ 

			if(itsTunedBorders[found].drag){ 

				 

				if((itsTunedBorders[found].itsAlign==AlignSet.LEFT||itsTunedBorders[found].itsAlign==AlignSet.RIGHT)&&hori){ 

					var rel=e.clientX-itsTunedBorders[found].touchStart; 

					var pos=relH1>0?true:false; 

					rel=pos?relH1:relH2; 

					for(var v=0; v<rel&&v<itsTunedBorders[found].itsPlayerIn.to; v++){ 

						if(pos&&itsTunedBorders[found].itsAlign==AlignSet.LEFT){ 

							if(!hasAgile) itsTunedBorders[found].agile=true; 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

						if(!pos&&itsTunedBorders[found].itsAlign==AlignSet.RIGHT){ 

							if(!hasAgile) itsTunedBorders[found].agile=true; 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

						itsTunedBorders[found].frameNr=v; 

					} 

				}else if(itsTunedBorders[found].itsAlign==AlignSet.TOP||itsTunedBorders[found].itsAlign==AlignSet.BOTTOM&&!hori){ 

					var rel=e.clientY-itsTunedBorders[found].touchStart; 

					var pos=relV1>0?true:false; 

					rel=pos?relV1:relV2; 

					for(var v=0; v<rel&&v<itsTunedBorders[found].itsPlayerIn.to; v++){ 

						if(pos&&itsTunedBorders[found].itsAlign==AlignSet.TOP){ 

							if(!hasAgile) itsTunedBorders[found].agile=true; 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

						if(!pos&&itsTunedBorders[found].itsAlign==AlignSet.BOTTOM){ 

							if(!hasAgile) itsTunedBorders[found].agile=true; 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

						itsTunedBorders[found].frameNr=v; 

					} 

				} 

			} 

		} 

} 

 

function slapO_MD(e){ 

	e=e?e:event; 

		for(found=0; found<itsTunedBorders.length; found++){ 

			itsTunedBorders[found].drag=true; 

			if(itsTunedBorders[found].itsAlign==AlignSet.LEFT||itsTunedBorders[found].itsAlign==AlignSet.RIGHT){ 

				itsTunedBorders[found].touchStart=e.clientX; 

			}else if(itsTunedBorders[found].itsAlign==AlignSet.TOP||itsTunedBorders[found].itsAlign==AlignSet.BOTTOM){ 

					itsTunedBorders[found].touchStart=e.clientY; 

			} 

		} 

} 

 

function slapO_MU(e){ 

	e=e?e:event; 

	for(found=0; found<itsTunedBorders.length; found++){ 

		if(itsTunedBorders[found].drag){ 

			if(itsTunedBorders[found].itsAlign==AlignSet.LEFT||itsTunedBorders[found].itsAlign==AlignSet.RIGHT){ 

				if(itsTunedBorders[found].agile){ 

					launchByVarname("itsTunedBorders[" + found + "].itsPlayerOut", 1, false, itsTunedBorders[found].itsAnimation[1].length-itsTunedBorders[found].frameNr, false, false); 

					itsTunedBorders[found].agile=false; 

				} 

			}else if(itsTunedBorders[found].itsAlign==AlignSet.TOP||itsTunedBorders[found].itsAlign==AlignSet.BOTTOM){ 

				if(itsTunedBorders[found].agile){ 

					launchByVarname("itsTunedBorders[" + found + "].itsPlayerOut", 1, false, itsTunedBorders[found].itsAnimation[1].length-itsTunedBorders[found].frameNr, false, false); 

					itsTunedBorders[found].agile=false; 

				} 

			} 

		} 

	} 

	for(found=0; found<itsTunedBorders.length; found++){ 

		itsTunedBorders[found].agile=false; 

		itsTunedBorders[found].drag=false; 

		itsTunedBorders[found].frameNr=0; 

	} 

}	 

	 

function slapO_TM(e){ 

	e=e?e:event; 

	for(var d=0; d < e.touches.length; d++){ 

		var relH1=0; 

	var relH2=0; 

	var relV1=0; 

	var relV2=0; 

		for(found=0; found<itsTunedBorders.length; found++){ 

			if(itsTunedBorders[found].drag){ 

				if(itsTunedBorders[found].itsAlign==AlignSet.LEFT) relH1=e.touches[d].clientX-itsTunedBorders[found].touchStart; 

				if(itsTunedBorders[found].itsAlign==AlignSet.RIGHT) relH2=itsTunedBorders[found].touchStart-e.touches[d].clientX; 

				if(itsTunedBorders[found].itsAlign==AlignSet.TOP) relV1=e.touches[d].clientY-itsTunedBorders[found].touchStart; 

				if(itsTunedBorders[found].itsAlign==AlignSet.BOTTOM) relV2=itsTunedBorders[found].touchStart-e.touches[d].clientY; 

			} 

		} 

		 

		var hori=(relH1>0?((relH1>relV1)?true:false):((relH2>relV2)?true:false)); 

		var hasAgile=false; 

		for(found=0; found<itsTunedBorders.length; found++){ 

			hasAgile=itsTunedBorders[found].agile?true:hasAgile; 

		} 

		for(found=0; found<itsTunedBorders.length; found++){ 

			if(itsTunedBorders[found].drag){ 

				 

				if((itsTunedBorders[found].itsAlign==AlignSet.LEFT||itsTunedBorders[found].itsAlign==AlignSet.RIGHT)&&hori){ 

					var rel=e.touches[d].clientX-itsTunedBorders[found].touchStart; 

					var pos=relH1>0?true:false; 

					rel=pos?relH1:relH2; 

					for(var v=0; v<rel&&v<itsTunedBorders[found].itsPlayerIn.to; v++){ 

						if(pos&&itsTunedBorders[found].itsAlign==AlignSet.LEFT){ 

							if(!hasAgile){ 

								itsTunedBorders[found].agile=true; 

							} 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

						if(!pos&&itsTunedBorders[found].itsAlign==AlignSet.RIGHT){ 

							if(!hasAgile){ 

								itsTunedBorders[found].agile=true; 

							} 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

					} 

					itsTunedBorders[found].frameNr=v; 

				}else if(itsTunedBorders[found].itsAlign==AlignSet.TOP||itsTunedBorders[found].itsAlign==AlignSet.BOTTOM&&!hori){ 

					var rel=e.touches[d].clientY-itsTunedBorders[found].touchStart; 

					var pos=relV1>0?true:false; 

					rel=pos?relV1:relV2; 

					for(var v=0; v<rel&&v<itsTunedBorders[found].itsPlayerIn.to; v++){ 

						if(pos&&itsTunedBorders[found].itsAlign==AlignSet.TOP){ 

							if(!hasAgile){ 

								itsTunedBorders[found].agile=true; 

							} 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

						if(!pos&&itsTunedBorders[found].itsAlign==AlignSet.BOTTOM){ 

							if(!hasAgile){ 

								itsTunedBorders[found].agile=true; 

							} 

							if(itsTunedBorders[found].agile) setDownByVarName("itsTunedBorders[" + found + "].itsPlayerIn", v); 

						} 

					} 

					itsTunedBorders[found].frameNr=v; 

				} 

			} 

		} 

	} 

} 

 

function slapO_TS(e){ 

	e=e?e:event;	 

	for(var d=0; d < e.touches.length; d++){ 

		for(found=0; found<itsTunedBorders.length; found++){ 

			itsTunedBorders[found].drag=true; 

			if(itsTunedBorders[found].itsAlign==AlignSet.LEFT||itsTunedBorders[found].itsAlign==AlignSet.RIGHT){ 

				itsTunedBorders[found].touchStart=e.touches[d].clientX; 

			}else if(itsTunedBorders[found].itsAlign==AlignSet.TOP||itsTunedBorders[found].itsAlign==AlignSet.BOTTOM){ 

					itsTunedBorders[found].touchStart=e.touches[d].clientY; 

			} 

		} 

	} 

} 

 

function slapO_NO(e){ 

	e=e?e:event; 

	for(found=0; found<itsTunedBorders.length; found++){ 

		if(itsTunedBorders[found].drag){ 

			if(itsTunedBorders[found].itsAlign==AlignSet.LEFT||itsTunedBorders[found].itsAlign==AlignSet.RIGHT){ 

				if(itsTunedBorders[found].agile){ 

					launchByVarname("itsTunedBorders[" + found + "].itsPlayerOut", 1, false, itsTunedBorders[found].itsAnimation[1].length-itsTunedBorders[found].frameNr, false, false); 

					itsTunedBorders[found].agile=false; 

				} 

			}else if(itsTunedBorders[found].itsAlign==AlignSet.TOP||itsTunedBorders[found].itsAlign==AlignSet.BOTTOM){ 

				if(itsTunedBorders[found].agile){ 

					launchByVarname("itsTunedBorders[" + found + "].itsPlayerOut", 1, false, itsTunedBorders[found].itsAnimation[1].length-itsTunedBorders[found].frameNr, false, false); 

					itsTunedBorders[found].agile=false; 

				} 

			} 

		} 

	} 

	for(found=0; found<itsTunedBorders.length; found++){ 

		itsTunedBorders[found].agile=false; 

		itsTunedBorders[found].drag=false; 

		itsTunedBorders[found].frameNr=0; 

	} 

} 

 

 

	 

	function _init(){

		createTunedBorder("#DF67A0", AlignSet.BOTTOM, 80, 1000, 60, 1, window, 120, false, false, false); 

		createTunedBorder("#DF67A0", AlignSet.TOP, 80, 1000, 60, 1, window, 120, false, false, false); 

		createTunedBorder("#DF67A0", AlignSet.LEFT, 80, 1000, 60, 1, window, 120, false, false, false); 

		createTunedBorder("#DF67A0", AlignSet.RIGHT, 80, 1000, 60, 1, window, 120, false, false, false); 

	} 

	 

	function getParentWindow(){ 

		return window.parent; 

	} 

 

	function _init2(){ 

		try{ 

			document.addEventListener("mousemove", MouseCapturePump, false); 

		}catch(e){ 

		document.onmousemove=MouseCapturePump; 

		} 

	} 

	 

	function MouseCapturePump(e){ 

		e=e?e:event; 

		var x=e.clientX-parseInt(window.parent.myIco_4_Frame.getLayer().style.left); 

		var y=e.clientY-parseInt(window.parent.myIco_4_Frame.getLayer().style.top); 

		window.parent.myIco_4_Frame.getWindow().MousePositionSet(new Point(x, y)); 

	}



function pasteNode(){



itsDotMatrixPlace=new FrameInfo();

itsDotMatrixPlace.init(true);





	itsDotMatrixPlace.setSize(getScreenWidth(), (urlGet("height")!=-1?urlGet("height"):400)); 

	itsDotMatrixPlace.setMinimumSize(getScreenWidth(), (urlGet("height")!=-1?urlGet("height"):400)); 

	itsDotMatrixPlace.setPreferedSize(getScreenWidth(), (urlGet("height")!=-1?urlGet("height"):400)); 

	document.body.appendChild(itsDotMatrixPlace.getIFrameNode("./rc/PaceDotMatrix/main.htm?dotSize=" + (urlGet("dotSize")!=-1?urlGet("dotSize"):11), false)); 

	

}

</SCRIPT>

</HEAD>



<BODY onload="pasteNode(); _init2(); _init(); itsDotMatrixPlace.makeVisible(true);" style="background-color: transparent; overflow: hidden; margin: 0 0 0 0; color: #FFFFFF; "> 

<SCRIPT language="JavaScript" type="text/JavaScript">

var itsDotMatrixPlace=null;

var ids="ids";

</SCRIPT>

<div id="ids" style="position: absolute; left: 0px; top: 0px;"></div>

<?php



	$date=isSet($_SESSION["viewDate"])?$_SESSION["viewDate"]:getDate(); 

	$gts=${$conf["APP.SESSION.sign"]}->formatDate($date , "DD. MN YYYY", false); 

	$dateh=${$conf["APP.SESSION.sign"]}->getDate($date, true); 

	$hts=${$conf["APP.SESSION.sign"]}->formatDate($dateh , "DD. MN YYYY", true); 

	echo "<TT style=\"color: #FFFFFF; \">" . "@" . $gts . "</TT><BR>"; 

	echo "<TT style=\"color: #FFFFFF; \">" . "@" . $hts . "</TT><BR>"; 

	$nrt=getMoonPhase($date, 180)-1; 

	$nrt=$nrt==0?180:$nrt; 

	$imgsrc="mooncan " . fillFrontEndZeros($nrt, 3) . ".png"; 

	$imgpath="./base/res/gfx/"; 

	$tagsrc="" . $imgpath . "" . $imgsrc; 

	

echo "<IMG class=\"moonIMG\" src=\"" . $tagsrc . "\" title=\"\" alt=\"\"></IMG>";



?>



<?php 

?>

</BODY> 

</HTML>


