<?php
header("Content-type: text/xml");
require("./base/conf/app_silent.inc.php");
require("./base/conf/db.conf.php");
require("./base/lang/perlmut.lang.php");
require("./base/conf/perlmut.conf.php");
require("./vcnnative/lib/classes/perlmut.classes.php");
require("./vcnnative/lib/functions/perlmut.functions.php");
${$conf["APP.SESSION.sign"]}=new DateDB($conf, $dbm);
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
 <url>
	<loc><?php echo $conf["domain"][$conf["countryString"]]["url"]; ?></loc>
	<lastmod>
			<?php
				$paste=${$conf["APP.SESSION.sign"]}->getDate(false, false);
				echo ${$conf["APP.SESSION.sign"]}->formatDate($paste, "YYYYMMDD", false);
			?>
	</lastmod>
  <changefreq>daily</changefreq>
  <priority>0.8</priority>
 </url>
 <url>
 <loc><?php echo $conf["domain"][$conf["countryString"]]["url"] . "/" . $conf["relativeroot"]; ?>showcase.php</loc>
  <lastmod>
			<?php
				$paste=${$conf["APP.SESSION.sign"]}->getDate(false, false);
				echo ${$conf["APP.SESSION.sign"]}->formatDate($paste, "YYYYMMDD", false);
			?>
	</lastmod>
  <changefreq>daily</changefreq>
  <priority>0.2</priority>
 </url>
</urlset>