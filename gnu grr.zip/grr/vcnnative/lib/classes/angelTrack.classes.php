<?php

class Dimension{

	var $width=-1;
	var $height=-1;
	
	
	function Dimension($width, $height){
		$this->width=$width;
		$this->height=$height;
	}
	
	function setSize($width, $height){
		$this->width=$width;
		$this->height=$height;
	}
	
	function getWidth(){
		return $this->width;
	}

	function getHeight(){
		return $this->height;
	}
}

class RequestCallBinder{
	var $sid="";
	var $acc="";
	var $dsc="";
	//***
	//deprecated in php7
	function RequestCallBinder($conf, $acc){
		$this->init($conf, $acc);
	}
	//constructor by patch
	function init($conf, $acc){
		global ${$conf["APP.SESSION.sign"]}, $ACTION_REQUEST_INI, $DATA_SEGMENT_CONTROL, $TILE_SEGMENT_ACCESS, $REQUESTVAR;
		$this->sid=session_continue(${$conf["APP.SESSION.sign"]}); 
		$found=false; 
		$this->acc=$acc;
		$this->dsc=$conf["dataSegmentControl"]; 
	}
	
	function plot(){
		global ${$conf["APP.SESSION.sign"]};
		for($f=0; $f < sizeof($REQUESTVAR)&&!$found; $f++){ 
			$found=$REQUESTVAR[$f][$ACTION_REQUEST_INI]==$this->acc?true:$found; 
			$tsa=$found?$REQUESTVAR[$f][$TILE_SEGMENT_ACCESS]:"notFound.php"; 
			$dsc=$found?$REQUESTVAR[$f][$DATA_SEGMENT_CONTROL]:$this->dsc; 
		}	
		$clamb=true; 
		if(!$found){ 
			//AUTH for older versions 
			$clamb=false; 
		}
		
		//$path=
		//***
		//in future major versions of request-synth there will be path respictivly tolerated differenced 
		
		if($clamb){ 
			$reclaimFile=pathinfo($tsa); 
			$filename=$reclaimFile["basename"]; 
			header("Cache-Control: no-store, no-cache, must-revalidate"); 
			header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
			header("Pragma: no-cache"); 
			if($reclaimFile["extension"]=="php") ${$conf["APP.SESSION.sign"]}->getMirror($filename, $dsc, true); 
			if($reclaimFile["extension"]=="htm") ${$conf["APP.SESSION.sign"]}->getMirror($filename, $dsc, false); 
		}
	}
}		
?>
