<?php

global $TYPE_URL, $TYPE_HASHTAG, $TYPE_IMAGE, $DEFAULT_URL;

$TYPE_URL="url";
$TYPE_HASHTAG="hashtag";
$TYPE_IMAGE="image";

$DEFAULT_URL="./../../blanc.png";

$r=10;
$linkRefLeft=-32;



$relationFix="";
$expressionIconUrl="./../../res/gfx/root.png";

		
//dummy ready

$eff=new Entry();
$eff->_init();

switch(strtolower($eff->read("type"))){
			case "mp3" :
			case "url" :
				echo "dummy root is working";
			case "hashtag" :
			case "image" :
			default:
			//border-radius: " . $r . ";
			echo "<P style=\"background-color: #FFFFFF; \"><A target=\"_self\" href=\"\" title=\"\" alt=\"\"><DIV style=\"width: 64px; height: 64px; text-align: center; vertical-align: middle; background-color: #EEEEEEy; background-repeat: norepeat; background-attachement: fixed; background-image: url(" . $expressionIconUrl . "); \"><SPAN name=\"blendArrays\"><!--<IMG src=\"./../../res/gfx/bulb_tile_1.png\" style=\"border-style: none; border-width: 0px;\"><IMG src=\"./../../res/gfx/bulb_tile_2.png\" style=\"border-style: none; border-width: 0px;\"><IMG src=\"./../../res/gfx/bulb_tile_3.png\" style=\"border-style: none; border-width: 0px;\">--></SPAN><DIV style=\"position: relative; left: " . $linkRefLeft . "px; top: 0px;\"><IMG ondrag=\"false\" src=\"" . $relationFix . "\"></DIV></DIV></A></P>";
		}
session_write_close();
exit();
?>