<?php
//load retry below
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<?php
echo "<TITLE>" . $conf["siteTitle"] . "</TITLE>";
echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";

							$plant=false;

								if($newinit){
  ?>
  <HTML>
  <BODY style="background-color:23DEFF;">
  <?php
									echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang];  
  
									if($pastCheck) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"]  . "?lang=" . ${$conf["APP.SESSION.sign"]}->lang . "_" . $countryCode . "&dscd=YES\">";  
  
							
							?>
  </BODY>
  </HTML>
  
								<?php  
  
$plant=true;  
  
								}else{
								/*
									echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] .  "?lang=" . ${$conf["APP.SESSION.sign"]}->lang . "_" . $countryCode . "&dscd=YES&dsab=\">";
								*/
									$url=$conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . $conf["relativeroot"] .  "?lang=" . ${$conf["APP.SESSION.sign"]}->lang . "_" . $countryCode . "&dscd=YES";
									
									$token=isSet($_GET["lang"])?$_GET["lang"]:false;

									$overrideIts=$token==false?true:false;
									
									if(!$overrideIts){
									$result=${$conf["APP.SESSION.sign"]}->doQuery("SELECT `url` FROM `{${$conf["APP.SESSION.sign"]}->tokens_to_url_table}` WHERE `token` = '$token';");

									$tupel=mysqli_fetch_array($result, MYSQLI_ASSOC);
									
									$url=$tupel["url"];
									  ?>
<?php
									}
									//echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $url . "\">";
								}  								//if(!$plant&&isSet($_GET["dscd"])) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . "\">";  
							?> 
							
							<?php  
  
								if(isSet($_POST)) if(isSet($_POST["confirmed"])) if($_POST["confirmed"]=="CHECK"&&!isSet($_GET["check"])){
  
									//echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang];  
  
									//echo "<META http-equiv=\"refresh\" content=\"0; URL=" . "./index.php" . "?check=YES\">";  
  
								}
							?>


<script language="JavaScript" type="text/JavaScript">

	function gambleCheck(){
		document.body.style.backgroundColor="#000000"; 
		if((document.location.href.indexOf("#")!=-1)){
					var entry=document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#"));
					document.forms["hashtag"].content.value=stripHTMLSpecialChars(isNum(entry)?"[[_vCn_]]<tt>firebat: </tt><b>hint </b><i>aproach </i>[[_vCn_]]":entry); 
					document.forms["hashtag"].submit(); 
		}else{ 
			; 
		} 
	}
	
	function isGate(d){
		var <?php if($sid==$_SESSION["gate_ini"]){ ?> retval=<?php echo "\"" . md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]) . "\"==d?true:false;"; }else{ ?>retval=false;<?php }?>
		return retval;
	}
 
	function dismiss(){
		var entry=document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#"));
		document.forms["hashtag"].content.value=stripHTMLSpecialChars(isNum(entry)?"[[_vCn_]]<tt>firebat: </tt><b>hint </b><i>aproach </i>[[_vCn_]]":entry);
	}
	
	var ondraw=false;

	<?php

		if($newinit){

		?>

			;

		<?php

			}

		?>

	function reloadSite(){ 
 
		ondraw=true; 
		 
		<?php
		if(!$arbiter){
			
		?>

			if((document.location.href.indexOf("dscd=YES")==-1)&&(document.location.href.indexOf("dsab")==-1)){
				var ctr=document.location.href.substr(0, document.location.href.indexOf("#")==-1?document.location.href.length:document.location.href.indexOf("#"));
				document.location.href=ctr + (ctr.indexOf("?")!=-1?"&":"?") + "dsab=DRAW" + (document.location.href.indexOf("#")==-1?"&itsServ=none":"&itsServ=" + document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#")));  
			 
			 
			}else { 

		<?php
 
			//echo "document.location.href=\"" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . "\";"; 
 
		?> 
 
		} 
 
		<?php 
 
		} 
 
		?> 
 
	} 

	

	function reloadSiteFar(){

		var ddr=false

		<?php

		$draft=false;

		if(isSet($_POST)){

			if(isSet($_POST["check"])){

				echo "ddr=true;";

			}else{

				$draft=true;

			}

		}else{

			$draft=true;

		}

		if($draft){

			echo "ddr=urlGet(\"check\")!=-1?true:ddr;";

		}

		?>

		//if(ddr) document.forms.reload.submit();

	}
			

</script>
<?php

?>
<?php

if(!$newinit&&$arbiter) if($nocase){
	//include("./jsmassive.inc.php");
}



?>

<?php

	if(!$newinit&&!$arbiter) if(!$nocase){
		//require("./base/res/includes/jsimports.inc.php");
	
	}

?>
</HEAD>
<BODY onload="" style="background-color: #FE05AA; ">
</BODY>
</HTML>
<?php
$already=true;
?>
