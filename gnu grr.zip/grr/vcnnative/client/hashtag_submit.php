<FORM name="hashtag" method="POST" onsubmit="dismiss();" action="index.php">
	<INPUT type="hidden" value="" name="content">
</FORM>
