<?php 
/* 
 
*********************************************************************************************************************************************************E_I 
 
 
*/ 
 
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
//user with check or hashtag sign in 
?> 
<?php 
	 
	if(isSet($_POST["content"])) ${$conf["APP.SESSION.sign"]}->doQuery("INSERT INTO `" . $conf["f14TOMCAT"] . "` (`estimatedId`, `hashtag`, `date`) VALUES('', '" . stripQueryChars($_POST["content"]) . "', '" . ${$conf["APP.SESSION.sign"]}->formatDate(${$conf["APP.SESSION.sign"]}->getDate(getDate(), false), "WD MON D HH:MM:SS YYYY", false) . "');"); 
	//relevant implementation for datasubmittion e.G. $_SESSION["collect"]["data_store"][$a]=$_POST["data_in"][$a]; 
 
 
/* 
 
*********************************************************************************************************************************************************A_O 
 
 
*/ 
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">   
<html lang=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>>   
<HEAD> 
<META http-equiv="Content-Type" content="text/html;charset=ISO-8859-1"> 
<META name="language" content=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>> 
<?php 
	//*** 
	//2BC 
	//may be added to linkmenu and or relay browse beside delivery stunt in the tables 
?> 
<?php   
	echo "<TITLE>" . $conf["siteTitle"] . "</TITLE>";   
	   
	echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";   
?>   
   
<?php   
   
echo "<meta name=\"description\" content=\"" . $conf["description"] . "\">";   
   
echo "<meta name=\"keywords\" content=\"" . $conf["keywords"] . "\">";   
   
echo "<meta name=\"author\" content=\"" . $conf["contentManager"] . "\">";   
   
echo "<meta name=\"contact_addr\" content=\"" . $conf["webmasterEmail"] . "\">"; 
  
?> 
<meta name="distribution" content="Global">   
   
<meta name="resource-type" content="document"> 
  
<meta name="robots" content="index, follow">   
  
<?php 
	//*** 
?> 
<link rel="styleSheet" href=<?php echo "\"" . $csssourcename . "\""; ?> type="text/css">   
<META name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">   
<?php 
 
								$plant=false; 
 
								if($newinit){ 
 
									echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang]; 
									if($pastCheck&&!$arbiter) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["trn_agent_hashtag"] . "?dscd=YES&dsab=DRAW\">"; 
							?> 
							<?php 
									$plant=true; 
 
								}else{ 
									//echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . "?dsab=DRAW\">"; 
								} 
 
								if(!$plant&&isSet($_GET["dscd"])) echo "<meta http-equiv=\"refresh\" content=\"0; URL=" . $conf["trn_agent_hashtag"] . "\">"; 
							?> 
							<?php 
								if(isSet($_POST)) if(isSet($_POST["confirmed"])) if($_POST["confirmed"]=="CHECK"&&!isSet($_GET["check"])){ 
 
									echo $lang["greetings"]["loadscreen"][${$conf["APP.SESSION.sign"]}->lang]; 
 
									echo "<META http-equiv=\"refresh\" content=\"0; URL=" . "./index.php" . "?check=YES\">"; 
 
								} 
							?> 
 
							<script language="JavaScript" type="text/JavaScript"> 
 
									function isGate(){ 
 
										var retval=true; 
 
										return retval; 
 
									} 
 
									var ondraw=false; 
 
									<?php 
 
										if($newinit){ 
 
										?> 
 
											; 
 
										<?php 
 
											} 
 
										?> 
 
										function reloadSite(){  
								  
										ondraw=true;  
										  
										<?php 
										if(!$arbiter){ 
											 
										?> 
 
											if((document.location.href.indexOf("dscd=YES")==-1)&&(document.location.href.indexOf("dsab")==-1)){ 
												var ctr=document.location.href.substr(0, document.location.href.indexOf("#")==-1?document.location.href.length:document.location.href.indexOf("#")); 
												document.location.href=ctr + (ctr.indexOf("?")!=-1?"&":"?") + "dsab=DRAW" + (document.location.href.indexOf("#")==-1?"&itsServ=none":"&itsServ=" + document.location.href.substr(document.location.href.indexOf("#"), document.location.href.length-document.location.href.indexOf("#")));   
											  
											  
											}else {  
 
										<?php 
								  
											//echo "document.location.href=\"" . $conf["domain"][${$conf["APP.SESSION.sign"]}->lang]["url"] . "\";";  
								  
										?>  
								  
										}  
								  
										<?php  
								  
										}  
								  
										?>  
								  
									}  
 
							</SCRIPT> 
 
							</HEAD> 
 
							<BODY onload=""> 
 
							</BODY> 
 
						</HTML> 
