<?php

	error_reporting(E_ERROR);

	ini_set('display_errors', FALSE);

	//error_reporting(E_ALL);

	//ini_set('display_errors', TRUE);

	ini_set('session.use_cookies', 0);

	ini_set('session.use_only_cookies', 0);

	ini_set('session.use_trans_sid', 0);

	global $terransUniteSession, $searchPair, $conf, $country;	

	require("./../../base/conf/db.conf.php");
	
	require("./../../base/conf/perlmut.conf.php");

	require("./../../base/lang/perlmut.lang.php");

	require("./../../vcnnative/lib/functions/perlmut.functions.php");

	require("./../../vcnnative/lib/classes/perlmut.classes.php");

	//wertet $sid in POST oder GET aus schreibt in $asid

	ini_set('session.use_cookies', 0);

	ini_set('session.use_only_cookies', 0);

	ini_set('session.use_trans_sid', 0);

	$terransUniteSession=new AuthSession($conf, $dbm);
	
	$country=isSet($_GET["country"])?urldecode($_GET["country"]):"Deutschland";
	
	$searchPair=null;
	
	$searchPair["cityname"]="";
	$searchPair["zipcode"]="";
	$sid=session_continue($terransUniteSession);
	
	function initSearch($city, $zipcode){
		global $terransUniteSession, $conf, $country;
		$city=$city?$city:false;
		$zipcode=$zipcode?$zipcode:false;
		
		if(!$zipcode){
			$result=$terransUniteSession->doQuery("SELECT `zipcode`, `cityname` FROM `{$conf["zipCodes"]}` WHERE (`countryId` IN (SELECT `countryId` FROM `{$conf["deliverCountries"]}` WHERE `countryName` LIKE '$country')) AND (`cityname` = '$city');");
		}else{
			$result=$terransUniteSession->doQuery("SELECT DISTINCT `zipcode`, `cityname` FROM `{$conf["zipCodes"]}` WHERE (`countryId` IN (SELECT `countryId` FROM `{$conf["deliverCountries"]}` WHERE `countryName` LIKE '$country')) AND (`zipcode` = '$zipcode');");
		}
		$enrow=null;
		if($result){
			if($result->num_rows>=1){
				$enrow=mysqli_fetch_array($result, MYSQLI_ASSOC);
			}else{
				return false;
			}
		}else{
			return false;
		}
		
		if(sizeof($enrow)>=2) return $enrow;
		return false;
	}
	
	$cityname=isSet($_GET["cityname"])?$_GET["cityname"]:false;
	$zipcode=isSet($_GET["zipcode"])?$_GET["zipcode"]:false;
	
	$searchPair=initSearch($cityname, $zipcode);
	
if(isSet($_SESSION["gate_ini"])) if($_SESSION["gate_ini"]==$sid){
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
	header("Pragma: no-cache");
	header('Content-Type: text/xml');
?>
<response>
	<location>
		<result>
			<cityname><?php
echo $searchPair["cityname"];?></cityname>
				<zipcode><?php
echo $searchPair["zipcode"];?></zipcode>
		</result>
	</location>
</response>
<?php
?>
<!--
This request was done on
<?php
$itf=$terransUniteSession->formatDate($terransUniteSession->getDate(false, false), "WD MON D HH:MM:SS YYYY", false);
echo $itf . "\n";
?>
<?php
}else{

?>
<!--
This request was denied due to insufficient session binding
<?php
$itf=$terransUniteSession->formatDate($terransUniteSession->getDate(false, false), "WD MON D HH:MM:SS YYYY", false);
echo $itf . "\n";
}
?>
-->