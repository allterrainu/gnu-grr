<?php	
	$ico1="./component/ico_ani_1/main.htm";
	$ico2="./component/ico_ani_2/main.htm";	
	$ico3="./component/ico_ani_3/index.htm";
	$ico4="./component/ico_ani_4/main.htm";
	$ico5="./component/ico_ani_5/index.htm";
?>
<SCRIPT language="JavaScript" type="text/JavaScript">
	var myIco_1_Frame=null;
	var myIco_2_Frame=null;
	var myIco_3_Frame=null;
	var myIco_4_Frame=null;
	var myIco_5_Frame=null;

	function _init(){
		//****
		clientFrame = new FrameInfo();
		clientFrame.init(true);
		//***
		myIco_1_Frame = new FrameInfo();
		var dlr=clientFrame.getSize().height / 16;
		myIco_1_Frame.init();
		myIco_1_Frame.setSize(dlr, dlr);
		myIco_1_Frame.setPreferedSize(dlr, dlr);
		myIco_1_Frame.setMinimumSize(dlr, dlr);
		document.body.appendChild(myIco_1_Frame.getIFrameNode("<?php echo $ico1;?>?colorA=FA4488&colorB=57FDAA&stainWidth=" + Math.round(dlr/1.7) + "&stainHeight=" + Math.round(dlr/1.7) + "&fps=40&duration=800&perspective=" + Math.round(dlr/1.7)*2 + "&href=http://glslsandbox.com/", false, 12, -1*parseInt(document.body.clientWidth)/2 +dlr/2, parseInt(document.body.clientHeight)/2-dlr));
		myIco_1_Frame.makeVisible(true);
		//**
		myIco_2_Frame = new FrameInfo();
		var dlr2=clientFrame.getSize().height / 16;
		myIco_2_Frame.init();
		myIco_2_Frame.setSize(dlr2, dlr2);
		myIco_2_Frame.setPreferedSize(dlr2, dlr2);
		myIco_2_Frame.setMinimumSize(dlr2, dlr2);
		document.body.appendChild(myIco_2_Frame.getIFrameNode("<?php echo $ico2;?>?style=./style/default.css&comp_left=0&comp_top=0&comp_width=" + (Math.floor(dlr2)-1) + "&comp_height=" + (Math.floor(dlr2)-1) + "&comp_spacer=" + Math.round(((dlr2)/310)*40) + "&comp_ani_duration=900&comp_ani_fps=120&comp_ani_delay=3000&comp_lineWidth=" + Math.round(((dlr2)/310)*20) + "&comp_color=#4433BB&href=./../../arcadeMenu/index.php&caption=Enter%20Menu", false, 5, -1*parseInt(document.body.clientWidth)/2 +dlr +dlr2/2, parseInt(document.body.clientHeight)/2-dlr2));
		myIco_2_Frame.makeVisible(true);
		//**
		myIco_3_Frame = new FrameInfo();
		var dlr3=clientFrame.getSize().height / 11;
		myIco_3_Frame.init();
		myIco_3_Frame.setSize(dlr3, dlr3);
		myIco_3_Frame.setPreferedSize(dlr3, dlr3);
		myIco_3_Frame.setMinimumSize(dlr3, dlr3);
		document.body.appendChild(myIco_3_Frame.getIFrameNode("<?php echo $ico3;?>?height=" + Math.round(dlr3) + "&href=http://get.webgl.org", false, 5, -1*parseInt(document.body.clientWidth)/2 +dlr +dlr2 +dlr3/2, parseInt(document.body.clientHeight)/2-dlr3/1.5));
		myIco_3_Frame.makeVisible(true);
		//**
		myIco_4_Frame = new FrameInfo();
		var dlr4=clientFrame.getSize().height / 12;
		myIco_4_Frame.init();
		myIco_4_Frame.setSize(dlr4, dlr4);
		myIco_4_Frame.setPreferedSize(dlr4, dlr4);
		myIco_4_Frame.setMinimumSize(dlr4, dlr4);
		document.body.appendChild(myIco_4_Frame.getIFrameNode("<?php echo $ico4;?>?width=" + Math.round(dlr4) + "&height=" + Math.round(dlr4) + "&spacerw=" + Math.round(dlr4/45) + "&spacerh=1&leo=./../gfx/singleEye_left_outer.png&reo=./../gfx/singleEye_right_outer.png&lei=./../gfx/singleEye_pair_inner.png&rei=./../gfx/singleEye_pair_inner.png", false, 5, -1*parseInt(document.body.clientWidth)/2 +dlr +dlr2 +dlr3 +dlr4/2, parseInt(document.body.clientHeight)/2-dlr4/1.5));
		myIco_4_Frame.makeVisible(true);
		//**
		myIco_5_Frame = new FrameInfo();
		var dlr5=clientFrame.getSize().height / 12;
		myIco_5_Frame.init();
		myIco_5_Frame.setSize(dlr5, dlr5);
		myIco_5_Frame.setPreferedSize(dlr5, dlr5);
		myIco_5_Frame.setMinimumSize(dlr5, dlr5);
		document.body.appendChild(myIco_5_Frame.getIFrameNode("<?php echo $ico5;?>", false, 5, -1*parseInt(document.body.clientWidth)/2 +dlr +dlr2 +dlr3 +dlr4 + +dlr5/2, parseInt(document.body.clientHeight)/2-dlr5/1.5));
		myIco_5_Frame.makeVisible(true);
		//**
		document.body.appendChild(clientFrame.getIFrameNode("./req.php?tsa=main.php&like=default", false, 1, 0, 0));
		//***
		try{
			document.addEventListener("mousemove", MouseCapturePump, false);
		}catch(e){
		document.onmousemove=MouseCapturePump;
		}
		clientFrame.makeVisible(true);
	}
	
	function MouseCapturePump(e){
		e=e?e:event;
		var x=e.clientX-parseInt(myIco_4_Frame.getLayer().style.left);
		var y=e.clientY-parseInt(myIco_4_Frame.getLayer().style.top);
		myIco_4_Frame.getWindow().MousePositionSet(new Point(x, y));
		//2BC
	}

</SCRIPT>
