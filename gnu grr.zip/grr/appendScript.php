<?php
	$finishAttachScriptsFunction="";
	
	error_reporting(E_ERROR);

	ini_set('display_errors', FALSE);

	//error_reporting(E_ALL);
	//ini_set('display_errors', TRUE);

	ini_set('session.use_cookies', 0);

	ini_set('session.use_only_cookies', 0);

	ini_set('session.use_trans_sid', 0);

	global $worlds, $conf;
	
	require("./base/conf/db.conf.php");
	
	require("./base/conf/app_silent.inc.php");
	global ${$conf["APP.SESSION.sign"]};
	require("./base/lang/perlmut.lang.php");
	
	require("./base/conf/perlmut.conf.php");
	
	require("./vcnnative/lib/functions/perlmut.functions.php");

	require("./vcnnative/lib/classes/perlmut.classes.php");

	${$conf["APP.SESSION.sign"]}=new AuthSession($conf, $dbm);
	$sid=session_continue(${$conf["APP.SESSION.sign"]}); //may be obsolente
	$reclaimFile=pathinfo(urldecode($_GET["tsa"]));
	$filename=$reclaimFile["basename"];
	$reclaimPath=isSet($_GET["dsc"])?pathinfo(urldecode($_GET["dsc"])):pathinfo(".");
	$path=$conf["dataSegmentControl"];
	header("content-type: text/JavaScript");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
	header("Pragma: no-cache");
?>	
	function isGate(d){
		var d=d?d:false;
  if(d==false) return false;
		var retval;
		retval=false;		
		<?php 

		if(isSet($_SESSION["window_mount"])) if(sizeof($_SESSION["window_mount"])!=0) if(isSet($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) if($_SESSION[$_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]]==$sid){ ?> retval=<?php echo "\"" . md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"]) . "\"==d?true:false;"; }else{ ?>retval=false;<?php }?>
		<?php if(isSet($_SESSION)) {//2BC
		?> if(<?php $d=sizeof($_SESSION["window_mount"])-1; echo $conf["APP.VARS.main"] . $conf["APP.VARS.index"] . $conf["APP.VARS.register"] . (md5($_SESSION["window_mount"][$d]["id"])) . $conf["APP.VARS.register"]  . $conf["APP.VARS.index"] . $conf["APP.VARS.main"] . "==\"" . $_SESSION["window_mount"][$d]["gate"] . "\""; ?>){
			retval=true;
		}else if(window.parent!=null) return window.parent.isGate(d);
		<?php
		}
		?>
		return retval;	
	}
	
	function isGatx(){
var retval=false;
		try{
			var retval=isGate(<?php if(isSet($_SESSION["window_mount"])) if(sizeof($_SESSION["window_mount"])!=0) if(isSet($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) echo "" . "\"" . (md5($_SESSION["window_mount"][sizeof($_SESSION["window_mount"])-1]["id"])) . "\""; ?>)?true:false;
		}catch(e){
			retval=false;
		}finally{
		return retval;
}
}
	function getParentWindow(){
		return window.parent;
	}
<?php
//if(strlen($path)==0) $path=$conf["dataSegmentControl"];

$reconnect=false;
if(isSet($_SESSION["gate_ini"])){
	if($_SESSION["gate_ini"]==$sid){
			;
		}else{
			$reconnect=true;
		}
}else{
	$reconnect=true;
}
?>
<?php
if($reconnect){
		?>
	
	function reloadContainer(){
		var windawr=window;	
		var estimatedDone=false;
		var count=0;
		while(!estimatedDone){
			if(windawr.isGatx()){
				estimatedDone=true;
				if(!windawr.ondraw) windawr.channelUpdate();
			}
			if(!estimatedDone){
				try{
					count++;
					if(windawr.parent) windawr=windawr.getParentWindow(); else estimatedDone=true;
				}catch(e){
					estimatedDone=true;
				}
			}
		}		
	}
	
	document.onload=reloadContainer();
	
	<?php
}else{
$la=false;
$rol=false;
$preFixTok="_ini_";
$la=$_GET["tsa"]==$_SESSION["firstImport"]?true:false;
$func=$preFixTok . $_SESSION["importsHay"][$_GET["hCount"]][$_GET["tsa"]];
$funcNext=isSet($_GET["tsaNext"])?($preFixTok . $_SESSION["importsHay"][$_GET["hCount"]][$_GET["tsaNext"]]):null;
$launcher=$preFixTok . $_SESSION["importsHay"][$_GET["hCount"]][$_SESSION["firstImport"]];
echo "function " . $func . "()";
?>{
		var throwIt=document.createElement("script");
		throwIt.type="text/JavaScript";
		throwIt.language="JavaScript";
		throwIt.async=false;
	<?php
		if(!$la) echo "throwIt.src=\"" . "loadScript.php?tsa=" . $_GET["tsa"] . "&dsc=" . $path . "\";\n";
		else echo "throwIt.src=\"" . "loadScript.php?tsa=" . $_GET["tsa"] . "&dsc=" . $path . "\";\n";
	?>
		var header=document.getElementsByTagName("head")[0];
	<?php
		echo "" . $func . "_r=false;";
	?>
		throwIt.onload = throwIt.onreadystatechange = function() {
		<?php
			echo "if(!". $func . "_r && (!this.readyState || this.readyState == 'complete'))";
		?>
			{
				<?php
					if($funcNext!=null){
						echo "try{" . $funcNext . "();}catch(e){}finally{}";
					}else{
						$rol=true;
						echo "try{" . "" . $finishAttachScriptsFunction . "" . "}catch(e){ }finally{ }";
					}
				?>
			}
		};
		header.appendChild(throwIt);
		//header.removeChild(header.lastChild);
	}


try{
//netscape 7.x bugfix
<?php
	if($rol){
		echo "" . $launcher . "();";
		${$conf["APP.SESSION.sign"]}->setCookieToWindowLifetime(); //100% before packagedata which is exhausted by the zend-engine of the apache webserver of any request that executes this script reaches client in this session to the host on which this server sends his response with code 200
	}
?>
}catch(e){
	;
}finally{
	;
}
<?php
session_write_close();
}
exit();
?>
