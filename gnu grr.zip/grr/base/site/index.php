<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Pragma: no-cache");?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 
<HTML lang=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>>
<body style="background-color: #99FF00; ">
<link rel="styleSheet" href="./base/res/styles/default.css" type="text/css">
	<SCRIPT type="text/JavaScript">
	var id="client_" + Math.floor(Math.random()*1000000);

		function retry(nor){
			var maintain=document.getElementsByName("flapZone")[0].innerHTML;
			
			if(maintain.indexOf("<?php global $conf; echo $conf["domain"][$conf["countryString"]]["session"]; ?>")==-1&&nor) document.writeln("<INPUT readonly value=\"\" id=\"" + id + "\" type=\"text\" maxlength=\"1\" size=\"1\" class=\"dudeComply\">"); else if(maintain.indexOf("<?php echo $conf["domain"][$conf["countryString"]]["session"]; ?>")!=-1) seek(); else if(nor) channelUpdate();
			if(nor) return true; 		
		}

		function seek(){
			var cmp=document.location.href;
			var url=document.location.href + (document.location.href.indexOf("<?php echo $conf["domain"][$conf["countryString"]]["session"]; ?>")!=-1?"":"<?php echo $conf["domain"][$conf["countryString"]]["session"]; ?>");
			if(cmp==url) ; else document.location.href=url;
		}

		function channelUpdate(){
			document.location.href=document.location.href + (document.location.href.indexOf("?")!=-1?"&":"?") + "dsab=DRAW";	
		}

		function link(){
			document.getElementsByName("flapZone")[0].innerHTML+="<?php echo $conf["domain"][$conf["countryString"]]["session"]; ?>";	
		}
	</SCRIPT>
<?php
		$lane="";
		$lane.=$lang["greetings"]["scan_sys_reset"][$languageCode];
		if($lang["greetings"]["scan_sys_reset"][strtolower($countryCode)]==$lang["greetings"]["scan_sys_reset"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]) $itsServ=true;
		if($itsServ&&($lang["greetings"]["scan_sys_reset"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]!=$lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]))	$lane.=$lang["first_clause"]["scan_sys_service"]["register"]==1?$lang["combine_clause"]["scan_sys_launch"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]:$lang["greetings"]["scan_sys_delimiter"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]["html"];
		else if($lang["greetings"]["scan_sys_reset"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]==$lang["greetings"]["scan_sys_reset"][$languageCode]) $lane=$lang["first_clause"]["scan_sys_service"]["register"]==1?$lang["combine_clause"]["scan_sys_launch"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]:$lang["greetings"]["scan_sys_delimiter"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang]["html"]; else $lane.=$lang["errors"][$langmode]["msg"][${$conf["APP.SESSION.sign"]}==null?$conf["countryString"]:${$conf["APP.SESSION.sign"]}->lang];
	?>
	<?php echo $lane; ?>
	<DIV style="position: absolute; left: 0px; top: 0px; z-index: 589000000"><TEXTAREA style="visibility: hidden; " name="flapZone">
		<?php echo $lane; ?>	
	</TEXTAREA></DIV>
	<SCRIPT type="text/JavaScript">
		retry(true);
		_startCursorAni();
	</SCRIPT>
</body>
</html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 
<HTML lang=<?php echo "\"" . ${$conf["APP.SESSION.sign"]}->lang . "\""; ?>>
