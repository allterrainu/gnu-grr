<?php 
	error_reporting(E_ERROR); 
	ini_set('display_errors', FALSE); 
	//error_reporting(E_ALL); 
	//ini_set('display_errors', TRUE); 
	ini_set('session.use_cookies', 0); 
	ini_set('session.use_only_cookies', 0); 
	ini_set('session.use_trans_sid', 0); 
	global $worlds; 
	global $terransUniteSession;	
	require("./../../base/conf/db.conf.php");
	require("./../../base/conf/app_silent.inc.php");
	require("./../../base/conf/perlmut.conf.php"); 
	require("./../../base/lang/perlmut.lang.php"); 
	require("./vcnnative/lib/functions/perlmut.functions.php"); 
	require("./vcnnative/lib/classes/perlmut.classes.php"); 
	 
	$terransUniteSession=new Session($conf, $dbm); 
	 
	$sid=session_continue($terransUniteSession);
 
	 
	header("Cache-Control: no-store, no-cache, must-revalidate"); 
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
	header("Pragma: no-cache"); 
if($terransUniteSession->validSession(!isSet($_SESSION[$itsWinId])?$sid:$_SESSION[$itsWinId])&&($sid!=""||$sid!=$terransUniteSession->EXPIRED)&&!$supercide){ 
	//*** 
/* 
	Copyright (C)007-2013 Daniel Wiesenaecker 
 
     
    This file is part of AngelTrack. 
 
    AngelTrack is free software: you can redistribute it and/or modify 
    it under the terms of the GNU General Public License as published by 
    the Free Software Foundation, either version 3 of the License, or 
    (at your option) any later version. 
 
    AngelTrack is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
    GNU General Public License for more details. 
 
    You should have received a copy of the GNU General Public License 
    along with AngelTrack. If not, see <http://www.gnu.org/licenses/>. 
 
 
*/ 
 
	error_reporting(E_ERROR); 
 
	ini_set('display_errors', FALSE); 
 
	//error_reporting(E_ALL); 
 
	//ini_set('display_errors', TRUE); 
?> 
 
<html> 
 
<head> 
 
<title> 
Zip Code Import - binded <?php echo isSet($_SESSION["go"])?"finishing":"processing";?> 
</title> 
<SCRIPT language="JavaScript" type="text/JavaScript"> 
	var done=false; 
</SCRIPT> 
</head> 
 
	<body style="text-align: left;" onload="if(!done) document.location.reload(); else alert('finished import.');"> 
 
	<tt>importiere Postleitzahlen von CSV.<br> Bitte warten...<br></tt> 
<?php 
 
 
function itsIsNum($str){ 
	$retval=true; 
	$a=0; 
	if(substr($str, 0, 1)=="-"){ 
		$a=1; 
	} 
	 
	for($v=$a; $v < strlen($str); $v++){ 
		switch(substr($str, $v, 1)){ 
			case "0": 
			 
			case "1": 
			 
			case "2": 
			 
			case "3": 
			 
			case "4": 
			 
			case "5": 
			 
			case "6": 
			 
			case "7": 
			 
			case "8": 
			 
			case "9": 
			 
			case "10": 
			 
			break; 
			 
			default: 
			 
			$retval=false; 
		} 
	} 
	 
	return $retval; 
} 
 
$zipCodeFromFileCSV="./../res/includes/PLZ_DE_AU_CH.csv"; 
$zipCodes=$conf["zipCodes"]; 
$countries=$conf["deliverCountries"]; 
 
	//connect 
	$what_dbhost=$dbm["what_dbhost"]; 
	$what_dblogin=$dbm["what_dblogin"]; 
	$what_dbpwd=$dbm["what_dbpass"]; 
	$what_dbname=$dbm["what_dbname"]; 
 
 
$collectCountries=null; 
 
 
$csvFileHandle = fopen ($zipCodeFromFileCSV, "r"); 
 
while(($l=fgetcsv($csvFileHandle, "1000", ";"))){ 
	$d=$l; 
	$d[1]=str_ireplace("'", "\'", $d[1]); 
	$tok=$d[2]; 
	$found=false; 
	for($v=0; $v < sizeof($collectCountries)&&!$found; $v++){ 
		$found=$collectCountries[$v]==$tok?true:$found; 
	} 
	if(!$found){ 
		$collectCountries[sizeof($collectCountries)]=$tok; 
	} 
} 
fclose($csvFileHandle); 
 
$a=0; 
 
 
 
$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname); 
 
if ($what_db->connect_error) { 
    die('Connect Error (' . $what_db->connect_errno . ') ' 
            . $what_db->connect_error); 
}else $error=false; 
	 
 
if(!isSet($_SESSION["go"])&&!isSet($_SESSION["ready"])){
	
	$result=mysqli_query($what_db, "DROP TABLE `$zipCodes`;"); 
	if(!$result){ 
		echo mysqli_error($result); 
		$error=true; 
	} 
	$result=mysqli_query($what_db, "DROP TABLE `$countries`;"); 
	if(!$result){ 
		echo mysqli_error($result); 
		$error=true; 
	} 
	$result=mysqli_query($what_db, "CREATE Table `$countries` (`countryId` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `countryName` VARCHAR(255) NOT NULL, `currencyId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`countryId`));"); 
	if(!$result){ 
		echo mysqli_error($result); 
		$error=true; 
	} 
	$result=mysqli_query($what_db, "CREATE Table `$zipCodes` (`index` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `cityname` VARCHAR(255) NOT NULL, `zipcode` VARCHAR(10) NOT NULL, `countryId` BIGINT UNSIGNED NOT NULL, PRIMARY KEY(`index`));"); 
	if(!$result){ 
		echo mysqli_error($result); 
		$error=true; 
	} 
}
if(!isSet($_SESSION["go"])) $_SESSION["go"]="YES"; 
if(!isSet($_SESSION["ready"])){
 
echo "<TT>" . "Importiere Postleitzahlen f�r folgende L&auml;nder" . "</TT><BR>"; 
for($f=0; $f<sizeof($collectCountries); $f++){ 
			echo "<TT>" . $collectCountries[$f] . "</TT><BR>"; 
			$case_sql="SELECT * FROM `$countries` WHERE `countryName`='" . $collectCountries[$f] . "';"; 
			$qr=mysqli_query($what_db, $case_sql); 
		$override=false; 
		if($qr){ 
			if($qr->num_rows>0){ 
				$override=true; 
			} 
		} 
		if(!$override){ 
			$result=mysqli_query($what_db, "INSERT INTO `$countries` (`countryName`) VALUES('" . $collectCountries[$f] . "');"); 
 
			if(!$result){ 
 
				echo mysqli_error($result); 
 
				$error=true; 
 
			} 
		} 
} 
 
 
	mysqli_close($what_db); 
$what_db = new mysqli($what_dbhost, $what_dblogin, $what_dbpwd, $what_dbname); 
 
if ($what_db->connect_error) { 
    die('Connect Error (' . $what_db->connect_errno . ') ' 
            . $what_db->connect_error); 
}else $error=false; 
	$csvFileHandle = fopen ($zipCodeFromFileCSV, "r"); 
$lastVal=null; 
$nonum=true; 
$peng=false; 
$count=2; 
$first=true; 
$nowrite=false; 
$count=0; 
$countIts=$ddd=0; 
$sql="SELECT * FROM `$zipCodes` WHERE 1;"; 
$result=mysqli_query($what_db, $sql); 
if($result){ 
	$countIts=$result->num_rows; 
} 
echo "beginne ab Position: " . $countIts; 
$_SESSION["proc"]="YES";
while(($l=fgetcsv($csvFileHandle, "1000", ";"))){ 
	$val=""; 
	$ddd++; 
	if($ddd>$countIts){ 
		$d=$l; 
		if(itsIsNum($d[1])&&!itsIsNum($d[0])){ 
			if($first&&$nowrite) $lastVal=null; 
			$d[0]=str_ireplace("'", "\'", $d[0]); 
			$d[0]=str_ireplace("\"", "\\\"", $d[0]); 
			$val=$d[0]; 
			$lastVal[$lastVal==null?0:sizeof($lastVal)]=$val; 
			if($first) $nowrite=false; 
			if(!$nowrite) ($first=false); 
			$count=0; 
		}else if(itsIsNum($d[1])&&(itsIsNum($d[0])||(strlen($d[0])>1?itsIsNum(substr($d[0],1,strlen($d[0])-1)):itsIsNum("" . $d[0])))&&$lastVal!=null){ 
			$count++; 
			$val=$lastVal[sizeof($lastVal)==1?0:(1)]; 
			if($val==strtoupper($val)) $val=$lastVal[0]; 
			 
			$sql="INSERT INTO `$zipCodes` (`index`, `zipcode`, `cityname`, `countryId`) VALUES('', '" . $d[0] . "', '" . $val . "', (SELECT `countryId` FROM `$countries` WHERE `countryName` = '" . $d[2] . "'));"; 
				$result=mysqli_query($what_db, $sql); 
				if(!$result){ 
					echo mysqli_error($result); 
					$error=true; 
					echo $sql; 
				}else{ 
				} 
			if($first) $count5=0; 
			if(!$first) $yet=false; 
			if(!$nowrite){ 
				$first=true; 
			} 
			if($first&&$yet) ($nowrite=true); 
			$yet=true; 
		} 
	} 
}
fclose($csvFileHandle); 
$sessionCookies=$conf["sessionCookies"]; 
$sessionVars=$conf["sessionVariables"]; 
$security_hash=$conf["SecSesHash2SID"]; 
$sessions=$conf["sessions"];
$a=0;
mysqli_close($what_db);
$_SESSION["go"]=null;
$_SESSION["ready"]="YES";
}

?> 
<SCRIPT language="JavaScript" type="text/JavaScript"> 
	var done=true; 
</SCRIPT> 
 
<BR><BIG>Import vollst&auml;ndig. Danke.</BIG><BR> 
</body> 
</html> 
<?php 
}else{ 
?> 
<html> 
 
<head> 
 
<title> 
Zip Code Import - No Session binded 
</title> 
</head> 
<body style="text-align: left;"> 
<TT>You don't have any Session binded. </TT> 
<TT>Get a Session ID <A href="<?php echo $conf["domain"]["de"]["url"] . $conf["relativeroot"] . "/"; ?>">here</A></TT> 
</body> 
</html> 
<?php 
} 
?>