<html>
	<SCRIPT type="text/JavaScript">

	function progressBarSeek(){
	}
	
	function _itsInit(){
		window.frames["footer"].document.forms["toolbar"].setup_wizard.style.color="#000000";
		window.frames["footer"].document.forms["toolbar"].logon.style.color="#000000";
	}
	</SCRIPT>
<?php
	$_SESSION["status"]="bitte w&auml;hlen";
		$lane="";
		$lane.=$lang["greetings"]["scan_sys_reset"][$languageCode];
		if($lang["greetings"]["scan_sys_reset"][strtolower($countryCode)]==$lang["greetings"]["scan_sys_reset"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]) $itsServ=true;
		if($itsServ&&($lang["greetings"]["scan_sys_reset"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]!=$lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]))	$lane.=$lang["first_clause"]["scan_sys_service"]["register"]==1?$lang["combine_clause"]["scan_sys_launch"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]:$lang["greetings"]["scan_sys_delimiter"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["html"];
		else if($lang["greetings"]["scan_sys_reset"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]==$lang["greetings"]["scan_sys_reset"][$languageCode]) $lane=$lang["first_clause"]["scan_sys_service"]["register"]==1?$lang["combine_clause"]["scan_sys_launch"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]:$lang["greetings"]["scan_sys_delimiter"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["html"]; else $lane.=$lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang];
	?><DIV style="background-color: DDDDDD; ">
	<?php echo $lane; ?>
	</DIV>
