<?php
	error_reporting(E_ERROR);
	ini_set('display_errors', FALSE);
	//error_reporting(E_ALL);
	//ini_set('display_errors', TRUE);
	require("./../conf/app_silent.inc.php");
	require("./../conf/db.conf.php");
	require("./../conf/perlmut.conf.php");
	require("./../lang/perlmut.lang.php");
	ini_set('session.use_cookies', 0);
	ini_set('session.use_only_cookies', 0);
	ini_set('session.use_trans_sid', 0);
	
	global $worlds;
	global $terransUniteSession;
	global $countryCode, $languageCode;
	
	require("./vcnnative/lib/functions/perlmut.functions.php");
	require("./vcnnative/lib/classes/perlmut.classes.php");
	//forced procedure to make res avail
	include("./vcnnative/client/gateway.php");

if(isSet($_POST["loggingOut"])){
$terransUniteSession->logoff();
	if(!$terransUniteSession->isAuthenticated()){
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" >
<HTML lang=<?php echo "\"" . $terransUniteSession->lang . "\""; ?>>
<META name="language" content=<?php echo "\"" . $terransUniteSession->lang . "\""; ?>>
<META http-equiv="Content-Type" content="text/html;charset=utf-8">
<?php

		echo "<link rel=\"stylesheet\" href=\"./base/res/styles/" . $_GET["like"] . ".css\" type=\"text/css\">";

		?>
<?php echo "<META name=\"title\" content=\"" . $conf["adminModulesTitle"] . " - " . $lang["notifications"][3]["msg"][$terransUniteSession->lang] . "\">"; ?>
<TITLE>
<?php
echo $conf["siteTitle"];
?>
</TITLE>
</HEAD>
		<BODY>
			<BIG style="color: #FFFFFF;"><BIG><TT><?php echo $conf["siteTitle"] . " - host[" . $conf["hostname"] . "]"; ?> - <i><?php echo $conf["productName"]; ?></i> Setup-Routinen</TT></BIG></BIG></BODY></HTML>
	<?php
	}
}else{
$gavePass=false;
$gaveUser=false;
$triedLogon=false;
$error=null;  
if(sizeof($_POST)>0){
  $gavePass=false;
  $gaveUser=false;
  if(isSet($_POST["pass"])){
   if($_POST["pass"]!="") $gavePass=true; 
  }
  if(isSet($_POST["user"])){
   if($_POST["user"]!="") $gaveUser=true; 
  }
  if($gaveUser&&$gavePass){
    $error["logon"]=$lang["errors"][$terransUniteSession->logon($_POST["user"], $_POST["pass"])]["msg"][$terransUniteSession->lang];
    $triedLogon=true;
  }
}
  if(!$gavePass){
    $error["pass"]=$lang["errors"][18]["msg"][$terransUniteSession->lang];
  }
  if(!$gaveUser){
    $error["user"]=$lang["errors"][1]["msg"][$terransUniteSession->lang];
  }
$logedin=false;
    if($terransUniteSession->isAuthenticated()){
      $logedin=true;
      if($terransUniteSession->isSuperuser()){
      /*
        Admin Area
      */
      ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" >
<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html;charset=utf-8">
<TITLE>
<?php
echo $conf["hostname"] . " - " . $conf["productName"]  . " - Setup";
?>
</TITLE>
		<SCRIPT language="JavaScript" type="text/JavaScript">
			<?php
				/*back is intrusing error which calms to be located*/
			?>
			
			var countHistoryMoves=-1;
			function setSign(to){
				countHistoryMoves++;
				document.getElementById('sign').innerHTML=to;
			}

			function back(){
				if(countHistoryMoves>0){
					countHistoryMoves--;
					window.history.back();//here
				}
			}
		</SCRIPT>
		<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </HEAD>
	<BODY style="margin:0px; overflow: scroll;" onload="">
		<FORM name="logoutForm" action="./req.php?tsa=admin.php" method="POST">
			<INPUT type="hidden" name="loggingOut" value="byeJoe">
			<INPUT class="adminButton" type="submit" value="ausloggen">
		</FORM>
	</BODY>
</HTML>
      <?php
      }
    }else if(!$gaveUser||!$gavePass||!$logedin&&!$terransUniteSession->isAuthenticated()){
    /*
      display Logon Form
    */
    ?>
    <HTML>
    <HEAD>
		<META http-equiv="Content-Type" content="text/html;charset=utf-8">
		<?php
			echo "<TITLE>" . "Logon" . "</TITLE>";
			
			echo "<META name=\"title\" content=\"" . $conf["siteTitle"] . "\">";
		?>
		<SCRIPT language="JavaScript" type="text/JavaScript">
			function typeOfTrace(mile){
				//test
				if(mile!="logon") alert(mile);
				//test
				if(mile=="username"){
					//seek performance
					;
				}
				if(mile=="password"){
					//reminder performance
					;
				}
			}
		</SCRIPT>
    </HEAD>
    <BODY style="margin: 0px; background-color: #000000;">
	<BIG style="color: #FFFFFF;"><BIG><TT><?php echo $conf["siteTitle"] . " - host[" . $conf["hostname"] . "]"; ?> - <i><?php echo $conf["productName"]; ?></i> Setup-Routinen</TT></BIG></BIG>
	<P class="logonPromt"><?php echo $lang["prompts"][6]["msg"][$terransUniteSession->lang]; ?></P>
	<DIV style="text-align: center; vertical-align: middle; width: 100%; height: 80%; border-style:none; background-color: #CCCCCC; ">
		<FORM name="loginForm" action="./req.php?tsa=admin.php&dsc=.&like=department" method="POST" onsubmit="typeOfTrace(document.forms[0].type.value);">
			<INPUT class="adminLoginPromtInputButton" name="type" type="hidden" value="logon">
			<DIV class="logonBoxOuter" style="">
				<DIV class="logonBox" style="">
					<?php
						if($triedLogon){
							echo "<DIV class=\"adminLoginPromtSpace\" style=\"\">" .  $error["logon"] . "</DIV>";
						}
						echo "<SPAN class=\"adminLoginUsaErr\">";
						?><BR>
						<?php
						if(isSet($error["user"])&&sizeof($_POST)>0){
							echo $error["user"];
							
						}
						echo "<BR></SPAN>";
							echo "<TT class=\"adminLoginPromtText\">Superusername</TT>&nbsp;<INPUT class=\"adminLoginPromtInputUsa\" type=\"text\" name=\"user\" value=\"" . (isSet($_POST["user"])?$_POST["user"]:"") . "\">";
						?>
						<INPUT class="adminLoginPromtInputButton" type="submit" onmousedown="document.forms[0].type.value='username'" value="?"><?php echo "<SPAN class=\"adminLoginPwdErr\">";
						?><BR>
						<?php
						if(isSet($error["pass"])&&sizeof($_POST)>0){
							echo $error["pass"];
							
						}
						echo "<BR></SPAN>";
						echo "<TT class=\"adminLoginPromtText\">Superuserpass</TT>&nbsp;<INPUT class=\"adminLoginPromtInputPwd\" type=\"password\" name=\"pass\">";
						?>
						<INPUT class="adminLoginPromtInputButton" type="submit" onmousedown="document.forms[0].type.value='password'" value="?"><BR>
					
				</DIV>
				<DIV class="logonButton" style=""><INPUT class="adminLoginPromtInputButton" type="submit" value="anmelden">
				</DIV>
			</DIV>
		</FORM>
	</DIV>
    </BODY>
    </HTML>
	<?php
		}
	}
?>