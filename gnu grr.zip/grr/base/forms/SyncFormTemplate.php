<?php
	echo "<form name=\"$name\" action=\"$action\" method=\"POST\">";
	echo "<input type=\"text\" name=\"nickname\" value=\"$nickname\">";//eigentlich deutsch
	echo "<input type=\"text\" name=\"formatedEvent\" value=\"$formatedEvent\">";//that'S it
	echo "<input type=\"text\" name=\"senderSid\" value=\"$senderSid\">";//useful
	echo "<input type=\"text\" name=\"sid\" value=\"$issid\">";//not without
	echo "<input type=\"text\" name=\"status\" value=\"$status\">";//really needful
	echo "<input type=\"text\" name=\"type\" value=\"$type\">"; //defines wheter server message or sent by user
	echo "<input type=\"text\" name=\"iterator\" value=\"$iterator\">";//something but
	echo "<input type=\"text\" name=\"users\" value=\"$n_users\">";//mem in postvars for check if changes
	echo "<input type=\"submit\" value=\"manual\">";
	echo "</form>";
?>