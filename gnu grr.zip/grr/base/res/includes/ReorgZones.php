<?php



//	(o)reinforced 1427 by VCN take2reality@gmx.net || batbox@need4speed.com

$ASCE="asce";

$DESC="desc";

$order=$ASCE;

$filenameAndPath="TimeZones.inc.php";

$countryString="de";

$varname="timezone";

//locks file for write access early__

$file=@fopen($filenameAndPAth, "w");



include($filenameAndPath);

$changed=true;

$var=$$varname;

while($changed){

	$changed=false;

	$offset1=-1;

	$offset2=-1;

	for($v=0; $v < (sizeof($var)-1); $v++){

		$toChange=false;

		$equal=true;

		$i=0;

		while($equal){

			if(($i==strlen($var[$v+1]["country"][$countryString]))||($i==strlen($var[$v]["country"][$countryString]))){

				if($order==$ASCE){ 

					if(strlen($var[$v]["country"][$countryString])>strlen($var[$v+1]["country"][$countryString])){

						{

							$toChange=true;

							$offset1=0;

							$offset2=1;

							$equal=false;

						}

					}

				}

				if($order==$DESC){

					 if(strlen($var[$v]["country"][$countryString])<strlen($var[$v+1]["country"][$countryString])){

						{

							$toChange=true;

							$offset1=0;

							$offset2=1;

							$equal=false;

						}

					}

				}

			}else{

			if($order==$ASCE)

			if(ord(strtoupper(substr($var[$v]["country"][$countryString], $i, 1))) > ord(strtoupper(substr($var[$v+1]["country"][$countryString], $i, 1)))){

				$toChange=true;

				$offset1=0;

				$offset2=1;

				$equal=false;

			}

			if($order==$DESC)

			if(ord(strtoupper(substr($var[$v]["country"][$countryString], $i, 1))) < ord(strtoupper(substr($var[$v+1]["country"][$countryString], $i, 1)))){

				$toChange=true;

				$offset1=0;

				$offset2=1;

				$equal=false;

			}

		}

		$i++;

	}

	if($toChange){

		$changed=true;

		echo ".";

		$tmp=$var[$v+$offset1]["country"][$countryString];

		$var[$v+$offset1]["country"][$countryString]=$var[$v+$offset2]["country"][$countryString];

		$var[$v+$offset2]["country"][$countryString]=$tmp;

		$tmp=$var[$v+$offset1]["utc"]["w"];

		$var[$v+$offset1]["utc"]["w"]=$var[$v+$offset2]["utc"]["w"];

		$var[$v+$offset2]["utc"]["w"]=$tmp;

		$tmp=$var[$v+$offset1]["utc"]["s"];

		$var[$v+$offset1]["utc"]["s"]=$var[$v+$offset2]["utc"]["s"];

		$var[$v+$offset2]["utc"]["s"]=$tmp;

		echo $var[$v+$offset1]["country"][$countryString] . "<->" . $var[$v+$offset2]["country"][$countryString];

	}

	}

	/*for(sizeof($var)-1; $v > 0; $v--){

		$toChange=false;

		$equal=true;

		$i=0;

		while($equal){

			if(($i==strlen($var[$v-1]["country"][$countryString]))||($i==strlen($var[$v]["country"][$countryString]))){

				if($order==$ASCE) if(strlen($var[$v]["country"][$countryString])>strlen($var[$v-1]["country"][$countryString])){

					{

						$offset1=0;

						$offset2=-1;

					}

				}

				if($order==$DESC) if(strlen($var[$v]["country"][$countryString])>strlen($var[$v-1]["country"][$countryString])){

					{

						$offset1=0;

						$offset2=-1;

					}

				}

			}else{

			if($order==$ASCE)

			if(ord(strtoupper(substr($var[$v]["country"][$countryString], $i, 1))) < ord(strtoupper(substr($var[$v-1]["country"][$countryString], $i, 1)))){

				$toChange=true;

				$offset1=0;

				$offset2=-1;

				$equal=false;

			}

			if($order==$DESC)

			if(ord(strtoupper(substr($var[$v]["country"][$countryString], $i, 1))) > ord(strtoupper(substr($var[$v-1]["country"][$countryString], $i, 1)))){

				$toChange=true;

				$offset1=0;

				$offset2=-1;

				$equal=false;

			}

		}

		$i++;

	}

	if($toChange){

		$changed=true;

		echo ".";

		$tmp=$var[$v+$offset1]["country"][$countryString];

		$var[$v+$offset1]["country"][$countryString]=$var[$v+$offset2]["country"][$countryString];

		$var[$v+$offset2]["country"][$countryString]=$tmp;

		$tmp=$var[$v+$offset1]["utc"]["w"];

		$var[$v+$offset1]["utc"]["w"]=$var[$v+$offset2]["utc"]["w"];

		$var[$v+$offset2]["utc"]["w"]=$tmp;

		$tmp=$var[$v+$offset1]["utc"]["s"];

		$var[$v+$offset1]["utc"]["s"]=$var[$v+$offset2]["utc"]["s"];

		$var[$v+$offset2]["utc"]["s"]=$tmp;

		echo $var[$v+$offset1]["country"][$countryString] . "<->" . $var[$v+$offset2]["country"][$countryString];

	}

}*/

}

for($a=0; $a < sizeof($var); $a++){

	echo $varname . "[$a]" . "[\"country\"][\"de\"]=" . $timezone[$a]["country"]["de"] . ";";

	echo $varname . "[$a]" . "[\"utc\"][\"w\"]=" . $timezone[$a]["utc"]["w"] . ";";

	echo $varname . "[$a]" . "[\"utc\"][\"s\"]=" . $timezone[$a]["utc"]["s"] . ";";

}

fclose($file);

?>


