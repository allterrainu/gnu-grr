<?php

global $terransUniteSession;

global $idS;
$idS=null;

function getRandomDecimal($max){
			$microtime = microtime();

			$microtime = strtok($microtime, " ");

			srand($microtime*1000000*$max);
			
			return rand(0, $max);
}


function isIn($ary, $n){
	$found=false;
	for($v=0; ($v < sizeof($ary))&&!$found; $v++){
		$found=$n==$ary[$v]?true:$found;
	}
	return $found;
}


function getId($prefix){
	global $idS;
	$max=11365467;
	$n=-1;
	$d="";
	do{
		$n=getRandomDecimal($max);
		$d=md5($n);
	}while(isIn($idS, $d));
	$idS[sizeof($idS)]=$d;
	$retval=$n;
	return ($prefix . $retval);
}

?>

<?php

$savRel=isSet($_SESSION["stackCount"])?$_SESSION["stackCount"]:-1;

$memGrave=$_SESSION["stackCount"]=isSet($_SESSION["stackCount"])?++$_SESSION["stackCount"]:0;

if($savRel>($memGrave+1)) $memGrave+=2;

$_SESSION["firstImport"]="isNum.js";

$_SESSION["importsHay"][$memGrave]["isNum.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["stripHTMLSpecialChars.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["tokenize.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["urlGet.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["refStyle.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["compatibleSize.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["arrayFunctions.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["cssGetta.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["trunkGeom.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["showNhide.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["frameCentInfo.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["retainedZoom.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["playSome.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["nibblesNbytes.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["fadeNhide.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["tuneBorder.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["sizesOScroller.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["oscroller.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["wrapOScroller.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["advanceOScroller.js"]=getId(uniqid());

$_SESSION["importsHay"][$memGrave]["listenPageBorder.js"]=getId(uniqid());


/*
?>
<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=arrayFunctions.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=isNum.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=tokenize.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=urlGet.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=trunkGeom.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=showNhide.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=compatibleSize.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=frameCentInfo.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=arrayFunctions.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=cssGetta.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=retainedZoom.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=playSome.js">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./loadScript.php?tsa=stripHTMLSpecialChars.js">

</SCRIPT>
<?php
*/
?>
<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=isNum.js&amp;tsaNext=tokenize.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=tokenize.js&amp;tsaNext=stripHTMLSpecialChars.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=stripHTMLSpecialChars.js&amp;tsaNext=urlGet.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=urlGet.js&amp;tsaNext=refStyle.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=refStyle.js&amp;tsaNext=compatibleSize.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=compatibleSize.js&amp;tsaNext=arrayFunctions.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=arrayFunctions.js&amp;tsaNext=cssGetta.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=cssGetta.js&amp;tsaNext=trunkGeom.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=trunkGeom.js&amp;tsaNext=showNhide.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=showNhide.js&amp;tsaNext=frameCentInfo.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=frameCentInfo.js&amp;tsaNext=retainedZoom.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=retainedZoom.js&amp;tsaNext=playSome.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=playSome.js&amp;tsaNext=nibblesNbytes.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=nibblesNbytes.js&amp;tsaNext=fadeNhide.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=fadeNhide.js&amp;tsaNext=tuneBorder.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=tuneBorder.js&amp;tsaNext=sizesOScroller.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=sizesOScroller.js&amp;tsaNext=oscroller.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=oscroller.js&amp;tsaNext=advanceOScroller.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<!--<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=wrapOScroller.js&amp;tsaNext=advanceOScroller.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>-->

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=advanceOScroller.js&amp;tsaNext=listenPageBorder.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>

<SCRIPT language="JavaScript" type="text/JavaScript" src="./appendScript.php?tsa=listenPageBorder.js&amp;hCount=<?php echo $memGrave; ?>">

</SCRIPT>