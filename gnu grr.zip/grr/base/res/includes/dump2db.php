<?php

//	(o)reinforced 1427 by VCN take2reality@gmx.net || batbox@need4speed.com





global $timezonesTable;

global $terransUniteSession;

$timezonesTable=$conf["timezones"];



$timezonesRegionNamesTable=$conf["timezonesRegionNames"];



$ASCE="asce";



$DESC="desc";



$order=$ASCE;



$filenameAndPath="TimeZones.inc.php";



$countryString="de";



$varname="timezone";





include($filenameAndPath);



global $terransUniteSession;


$timez=$$varname;







function isUnusedZoneId($id){



	global $timezonesTable;



	global $terransUniteSession;



	$result=$terransUniteSession->doQuery("SELECT * FROM `$timezonesTable` WHERE `zoneId` = '$id';");



	if($result){



		if($result->num_rows==0){



			return true;



		}



	}



		return false;



}



	$zid=0;

	$result=$terransUniteSession->doQuery("TRUNCATE TABLE `$timezonesTable`;");

	$result=$terransUniteSession->doQuery("TRUNCATE TABLE `$timezonesRegionNamesTable`;");


for($v=0; $v < sizeof($timez); $v++){



	$winter=$timez[$v]["utc"]["w"];



	$summer=$timez[$v]["utc"]["s"];



	$zid++;



	while(!isUnusedZoneId($zid)){



		$zid++;



	}




	
	$result=$terransUniteSession->doQuery("INSERT INTO `$timezonesTable` (`zoneId`, `summer2utc`, `winter2utc`) VALUES('$zid', '$summer', '$winter');");

	while(list($cstring, $rname) = each($timez[$v]["country"])){



		$terransUniteSession->doQuery("INSERT INTO `$timezonesRegionNamesTable` (`zoneId`, `countryString`, `regionname`) VALUES('$zid', '$cstring', '$rname');");



	}	



}







$result=$terransUniteSession->doQuery("SELECT * FROM `$timezonesRegionNamesTable`  WHERE ((`countryString`='$countryString') AND (`zoneId` IN (SELECT `zoneId` FROM `$timezonesTable` WHERE 1)));");







while($as=mysqli_fetch_array($result, MYSQLI_ASSOC)){



	echo $as["zoneId"] . "::" . $as["regionname"] . "\n";



}