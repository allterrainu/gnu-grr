<?php
/*
	Copyright �2007-2017 Daniel Wiesen�cker

    
    This file is part of AngelTrack.

    AngelTrack is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    AngelTrack is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AngelTrack. If not, see <http://www.gnu.org/licenses/>.


*/
	//PERLMUT -> AngelTrack -> AtShop (former DINO) configutation
	global ${$conf["APP.SESSION.sign"]};
	global $langmode, $conf, $countryCode, $languageCode;
	//<hashtag_commit content="faq, rubrik, topic, sign, call, nickname, invokation, enter, event">
	//***
	//<LANGMODE>
	$langmode=26;
	$mode="am";
	$countryCode="US";
	$languageCode="de";
	$conf["countryString"]=$mode==strtoupper($mode)?strtolower($countryCode):strtolower($languageCode);
	//</LANGMODE>
	//<HOST>
	
	$conf["hostname"]="itsBox - freezar";		//prototype DESU servername
	$ZF0015244conf["relativeroot"]="/HANGAR/";					//path where dino is installed on
	$conf["webmasterEmail"]="take2reality@gmx.net";//a valid email adress u own
	//site
	$conf["domain"][$conf["countryString"]]["domain"]="localhost:8080";
	$conf["domain"][$conf["countryString"]]["url"]="http://localhost:8080/bitmycloud/";
	$conf["domain"][$conf["countryString"]]["currency"]="Euro";//should be set to whatever $baseVars[4]["value"] is set to				
	$conf["domain"][$conf["countryString"]]["security"]="127.0.0.1";
	$conf["dataSegmentControl"]="nol";
	$conf["contentManager"]="Daniel Wiesenaecker";
	$conf["keywords"]="bitsession.net, bitsession, stable, session, gamble, nowadays people, former time, ordinal power, realtime, coordinates, system leak, division by zero, infinite loop, swish, invasive platform programming, connectivity, audio html5, ecma, jscript, javascipt, time zones, availability, trusted network, sound, membrane touch, sensible works, damaged files, cute operation, fire, once fired, alerting, network interchange, auth, authentication, primitive variables, stolen images, network, handler, legalize it, ultrasound, argemage, warlock, components, etrust, com, net, de, eu, sizes, scroller, infos, info, email, jugglerbox.eu, jugglerbox.net, jugglerbox.tk, jugglerbox.org, jugglerbox.de, jugglerbox.com, blue, robot, bluerobot, bluerobot.de, blue-robot.de, de, com, blue, robot, deutschland, iterative, script, resource, make, hidden, bluerobot.com, files, visible again, reg, file, damaged, regpatch, download, components, html, nude, glasses, nude glasses, moon, mond, mondphase, moonphasis, ticker, aktuelle, farbenfader, colorfader, dhtml, animation, menus, components, webpage, website, php, java, script, js";
	$conf["description"]="Zeigt Ihnen die aktuelle Mondphase. Durch einen Klick auf das Mondbild gelangt man ins Menu.";
	$conf["siteTitle"]="bitsession.us";
	$conf["versionId"]="version 0.05.8995888b";
	//</HOST>
//<PREFERENCES>
	//</hashtag_commit>
	$conf["domain"][$conf["countryString"]]["session"]="?itsServ=#default";
	//***default:
	$lang["session_service"]["scan_sys_service"]["lock"]["de"]=$conf["domain"][$conf["countryString"]]["session"];
	$lang["session_service"]["scan_sys_service"]["lock"]["en"]=$conf["domain"][$conf["countryString"]]["session"];
	//**
	//*
	$lang["first_clause"]["scan_sys_service"]["register"]=0;
	//*
	//**
		//service invokeation instance make origin:
			
		$lang["greetings"]["scan_sys_delimiter"]["en"]["token"]="#mode_en_EN##";
		$lang["greetings"]["scan_sys_delimiter"]["de"]["token"]="#mode_de_DE##";
		
		
		$lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]=$conf["domain"][$conf["countryString"]]["session"];
		$lang["first_clause"]["scan_sys_service"]["de"]=1;
		$lang["first_clause"]["scan_sys_service"]["en"]=1;
		$lang["combine_clause"]["scan_sys_control"]["de"]=0;
		$lang["combine_clause"]["scan_sys_control"]["en"]=0;
		
		$lang["errors"][$langmode]["msg"]["de"]="<!--Server does not mention its name but says that it is a german server.-->";
		$lang["errors"][$langmode]["msg"]["en"]="<!--Server does not mention its name but says that it is an english server.-->";
		

	//***
		$lang["combine_reset"]["scan_sys_reset"]["de"]=$conf["domain"][$conf["countryString"]]["session"] . "#mode_de_DE##/#mode_de_DE##-#mode_de_DE##\\\\#mode_de_DE##|#mode_de_DE##/#mode_de_DE##-#mode_de_DE##\\\\#mode_de_DE##|#mode_de_DE###mode_en_EN##" . $conf["domain"][$conf["countryString"]]["session"];
		$lang["combine_reset"]["scan_sys_reset"]["en"]=$conf["domain"][$conf["countryString"]]["session"] . "#mode_en_EN##/#mode_en_EN##-#mode_en_EN##\\\\#mode_en_EN##|#mode_en_EN##/#mode_en_EN##-#mode_en_EN##\\\\#mode_en_EN##|#mode_en_EN###mode_en_EN##" . $conf["domain"][$conf["countryString"]]["session"];
				
		$sunrise=$lang["combine_reset"]["scan_sys_reset"][$conf["countryString"]];
		$delim=$lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]];
		$unset=false;
		$d_1=strpos($sunrise, $delim);
		if($d_1!=-1) $sunrise=substr($sunrise, $d_1+strlen($delim), strlen($sunrise)-$d_1-strlen($delim)); else $unset=true;
		$d_2=strpos($sunrise, $delim);
		if($d_2!=-1) $sunrise=substr($sunrise, 0, $d_2); else $unset=true;
		
		$dawn_compare="";
		$cr1=0;
				
		do{
			$flow=$sunrise;
			$cr2=strlen($flow)-$cr1;
			$flow=substr($sunrise, $cr1, $cr2);
			$next="";
			$delim=$lang["greetings"]["scan_sys_delimiter"][$conf["countryString"]]["token"];
			$ready=false;
			$d_1=strpos($flow, $delim);
			if($d_1!=-1) $flow=substr($flow, $d_1+strlen($delim), strlen($flow)-$d_1-strlen($delim)); else $ready=true;
			$d_2=strpos($flow, $delim);
			if($d_2!=-1) $flow=substr($flow, 0, $d_2); else $ready=true;
			if(!$ready) $next=$flow;
			$cr1=$cr1 + $d_1 + strlen($delim);
			$dawn_compare.=$next;
		}while(strlen($next)!=0);
		$dawn="/-\\\\|/-\\\\|";
		if($dawn_compare==$dawn) $value="<SCRIPT language=\"JavaScript\" type=\"text/JavaScript\">var seq1_ani_cursor=\"" . $dawn_compare . "\";</SCRIPT>";
			
		$lang["shell"]["prompt"]["de"]="";
		$lang["shell"]["prompt"]["en"]="";
		//cursor
		$conf["domain"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["cursormark"]=strcount($lang["combine_reset"]["scan_sys_reset"][$conf["countryString"]], $lang["greetings"]["scan_sys_delimiter"][$conf["countryString"]]["token"], $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]])==9?$lang["shell"]["prompt"][$terransUniteSession!=null?$terransUniteSession->lang:$conf["countryString"]]:$lang["errors"][$langmode]["msg"][$terransUniteSession!=null?$terransUniteSession->lang:$conf["countryString"]];
	
		$lang["greetings"]["scan_sys_delimiter"]["en"]["html"]="<SPAN class=\"itsAdvancePrompt\">" . $conf["domain"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["cursormark"] . "</SPAN>" . $value . "\n<SCRIPT language=\"JavaScript\" type=\"text/JavaScript\" src=\"./vcnnative/client/prefload.js\"></SCRIPT>" . "";
		$lang["greetings"]["scan_sys_delimiter"]["de"]["html"]="<SPAN class=\"itsAdvancePrompt\">" . $conf["domain"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["cursormark"] . "</SPAN>" . $value . "\n<SCRIPT language=\"JavaScript\" type=\"text/JavaScript\" src=\"./vcnnative/client/prefload.js\"></SCRIPT>" . "";
	
		$lang["greetings"]["scan_sys_reset"]["de"]=(($lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]] . ($lang["first_clause"]["scan_sys_service"]["register"]?$lang["session_service"]["scan_sys_service"]["lock"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]:$conf["domain"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["session"]))==($lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]))?$lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]:$lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang];
		$lang["greetings"]["scan_sys_reset"]["en"]=(($lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]] . ($lang["first_clause"]["scan_sys_service"]["register"]?$lang["session_service"]["scan_sys_service"]["lock"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]:$conf["domain"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang]["session"]))==($lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang] . $lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]))?$lang["greetings"]["scan_sys_delimiter"][$conf["APP.VARS.index"]]:$lang["errors"][$langmode]["msg"][$terransUniteSession==null?$conf["countryString"]:$terransUniteSession->lang];
	
	//2BC
	$lang["first_clause"]["scan_sys_service"]["cursor"]="";
	//</PREFERENCES>
//ebay gateways
	$conf["ebay"]["sellerId"]="";
	$conf["ebay"]["ebay_sandbox"]="https://api.sandbox.ebay.com/ws/api.dll";
	$conf["ebay"]["ebay_live"]="https://api.ebay.com/ws/api.dll";
	
//customized shop params
	$conf["numOfPieces"]="20";
	$conf["customerNumberConsistOf"]="0123456789";
	$conf["customerNumberLength"]=9;
	$conf["shop_image_base"]="./imagebase/";

	
/*
	shop Vars
*/
//<BASEVARS>
$baseVars=null;

$baseVars[0]["varname"]="taxDeclarations";
$baseVars[0]["caption"]="Mehrwertssteuer Einbettung";
$baseVars[0]["value"]="2";
$baseVars[0]["datatype"]="INT UNSIGNED";
$baseVars[0]["unity"]="number of";
$baseVars[0]["description"]="vorhandene Mehrwertssteuers&#228;tze";

$baseVars[1]["varname"]="tax1";
$baseVars[1]["caption"]="Mehrwertssteuer";
$baseVars[1]["value"]="19";
$baseVars[1]["datatype"]="INT UNSIGNED";
$baseVars[1]["unity"]="%";
$baseVars[1]["description"]="gesetzliche Mehrwertssteuer";

$baseVars[2]["varname"]="tax2";
$baseVars[2]["caption"]="Mehrwertssteuer";
$baseVars[2]["value"]="7";
$baseVars[2]["datatype"]="INT UNSIGNED";
$baseVars[2]["unity"]="%";
$baseVars[2]["description"]="gesetzliche Mehrwertssteuer (erm&#228;&#223;igter Mehrwertssteuersatz)";

$baseVars[3]["varname"]="taxApplicable";
$baseVars[3]["caption"]="Mehrwertssteuer Ausweis m&#246;glich";
$baseVars[3]["value"]="FALSE";
$baseVars[3]["datatype"]="BOOLEAN";
$baseVars[3]["unity"]="Mehrwertssteuer ausweisbar";
$baseVars[3]["description"]="Mehrwertssteuer ausweisbar";


$baseVars[4]["varname"]="shopCurrency";
$baseVars[4]["caption"]="W&#228;hrung";
$baseVars[4]["value"]="Euro";//should be set to whatever $conf["domain"]["de"]["currency"] is set to
$baseVars[4]["datatype"]="DOUBLE";
$baseVars[4]["unity"]="Credits";
$baseVars[4]["description"]="Standardw&auml;hrung des Shops";

$baseVars[5]["varname"]="companyname";
$baseVars[5]["caption"]="LJ ist ein Drache";
$baseVars[5]["value"]="Daniel Wiesenaecker";
$baseVars[5]["datatype"]="VARCHAR(64)";
$baseVars[5]["unity"]="H1";
$baseVars[5]["description"]="Wir legen die Leine los.";

$baseVars[6]["varname"]="adress";
$baseVars[6]["caption"]="Unsere Postanschrift";
$baseVars[6]["value"]="Einsiedlerstrasse 8 64579 Gernsheim";
$baseVars[6]["datatype"]="VARCHAR(256)";
$baseVars[6]["unity"]="TT";
$baseVars[6]["description"]="Hier k&#246;nnen Sie uns erreichen.";
//</BASEVARS>
/*
	shop tables
*/
/*
	shop tables
*/
	//<SECURESESSION>
	$conf["tokens"]="angelTrack_tokens_reload_to_urls";
	$conf["tmpSessionPath"]="./tmpSes";
	$conf["SecSesHash2SID"]="perlmut_secses_hash_2SID";
	$conf["securityStunt"]="perlmut_relay_browsing";
	$conf["baseVars"]="angeltrack_base_vars";
	$conf["splittedBackupTable"]="perlmut_splitted_backup_reregisters";
	$conf["sessionStoreData"]="perlmut_session_store";	
	//</SECURESESSION>
	//<REQUEST_API>
	$conf["stunt_request_invoke"]="angeltrack_request_actions";
	$conf["security_request_invoke"]="angeltrack_secure_request_actions";
	//</REQUEST_API>
	//<ARTICLESVIEW>
	$conf["productProperties"]="angeltrack_product_properties";//desc
	$conf["propertiesBinding"]="angeltrack_product_properties_binding";//desc
	$conf["propertiesDescriptor"]="angeltrack_product_properties_descriptors";//desc dpp
	//</ARTICLESVIEW>
	//<LOCALES>
	$conf["timezonesRegionNames"]="ndw_timezoneRegionNames";
	$conf["timezones"]="ndw_timezones";
	$conf["deliverCountries"]="angeltrack_delivery_countries";
	$conf["zipCodes"]="angeltrack_zipCodes";
	//</LOCALES>
	//<EBIZ>
	$conf["imageGallery"]="angeltrack_image_gallery";
	$conf["productStackSync"]="angeltrack_ebay_sync";
	//</EBIZ>
	//<ARTICLESDATA>
	$conf["productCategories"]="angeltrack_product_categories";
	$conf["articleTree"]="angeltrack_article_tree";
	$conf["storageLinker"]="angeltrack_storage_linker";
	$conf["storageAssignment"]="angeltrack_storage_assignment";
	//<ARTICLESDATA>
	//<SHOP PROPERTIES>
	$conf["shipmentMethods"]="angelTrack_shipment_methods";
	$conf["currencies"]="angeltrack_currencies";
	$conf["vendors"]="angeltrack_vendors_list";
	//</SHOP PROPERTIES>
	//<PROCESSING>
	$conf["adminlog"]="angeltrack_admin_log";
	$conf["orders"]="angeltrack_orders";
	$conf["pieces"]="angeltrack_ordered_pieces";
	$conf["chargens"]="angeltrack_chargens";
	$conf["supplies"]="angeltrack_supplier_info_table";
	//</PROCESSING>
	//<EMAILCUSTOMIZATION>
	$conf["emailBlockContainer"]="angeltrack_sensetive_text_block_container";
	$conf["emailSampleContainer"]="angeltrack_sensetive_text_sample_container";
	//</EMAILCUSTOMIZATION>
	//<EVENTS>
	$conf["events"]="angletrack_planned_events";
	$conf["actionSales"]="angeltrack_event_action_sales";
	//</EVENTS>
	//<HOREUR SYS>
	$conf["f14TOMCAT"]="systemtray_sekundenschlaf";
	//</HOREUR SYS>
	//<LINKMENU>
	$conf["linkmenu"]="perlmut_link_menu";
	//</LINKMENU>
/*
	end of shop tables
*/

/*defines which personal data is beign saved*/
	
	//saved in table


	$conf["personalDataStorage"]="perlmut_comprehensive_data";


//<COMPREHENSIVE_DATA>

	
	
	$conf["personalData"]["password"]["dutyfield"]=false;
	$conf["personalData"]["password"]["prompt"]["de"]="Kundenkennwort";
	$conf["personalData"]["password"]["prompt"]["en"]="Customerpassword";
	$conf["personalData"]["password"]["caption"]="password";
	$conf["personalData"]["password"]["formElement"]="password"; //2 select and text..
	$conf["personalData"]["password"]["maxlength"]=null;
	$conf["personalData"]["password"]["options"][0]["value"]="changeme";
	
	$conf["personalData"]["username"]["dutyfield"]=true;
	$conf["personalData"]["username"]["prompt"]["de"]="Kundenummer";
	$conf["personalData"]["username"]["prompt"]["en"]="Customer-ID";
	$conf["personalData"]["username"]["caption"]="username";
	$conf["personalData"]["username"]["formElement"]="text"; //2 select and text..
	$conf["personalData"]["username"]["maxlength"]=null;
	$d=sizeof($conf["personalData"]);	
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Anrede";
	$conf["personalData"][$d]["prompt"]["en"]="Salutation";
	$conf["personalData"][$d]["caption"]="salutation";
	$conf["personalData"][$d]["formElement"]="select"; //2 select and text..
	$conf["personalData"][$d]["maxlength"]=null;
	$conf["personalData"][$d]["options"][0]["value"]="f";
	$conf["personalData"][$d]["options"][0]["caption"]="Frau";
	$conf["personalData"][$d]["options"][1]["value"]="m";
	$conf["personalData"][$d]["options"][1]["caption"]="Herr";
	$conf["personalData"][$d]["binds"]=true;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Vorname";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="first name";
	$conf["personalData"][$d]["caption"]="firstname";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="80";
	$conf["personalData"][$d]["selection"]=null;
	$conf["personalData"][$d]["binds"]=true;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Nachname";
	$conf["personalData"][$d]["prompt"]["en"]="Familyname";
	$conf["personalData"][$d]["caption"]="lastname";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="80";
	$conf["personalData"][$d]["selection"]=null;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["binds"]=false;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Strasse";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="Street or Avenue";
	$conf["personalData"][$d]["caption"]="street";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="128";
	$conf["personalData"][$d]["selection"]=null;
	$conf["personalData"][$d]["binds"]=true;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Hausnummer";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="blocknumber";
	$conf["personalData"][$d]["caption"]="hnr";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="5";
	$conf["personalData"][$d]["selection"]=null;
	$conf["personalData"][$d]["binds"]=false;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Postleitzahl";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="ZIP-Code";
	$conf["personalData"][$d]["caption"]="plz";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="5";
	$conf["personalData"][$d]["selection"]=null;
	$conf["personalData"][$d]["binds"]=true;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Ort";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="location";
	$conf["personalData"][$d]["caption"]="location";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="80";
	$conf["personalData"][$d]["selection"]=null;
	$conf["personalData"][$d]["binds"]=false;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Land";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="Country";
	$conf["personalData"][$d]["caption"]="country";
	$conf["personalData"][$d]["formElement"]="select"; //2 select and text..
	$conf["personalData"][$d]["maxlength"]=null;
	$conf["personalData"][$d]["options"][0]["value"]="Deutschland";
	$conf["personalData"][$d]["options"][0]["caption"]="Deutschland";
	$conf["personalData"][$d]["binds"]=true;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=true;
	$conf["personalData"][$d]["prompt"]["de"]="Region";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="Region";
	$conf["personalData"][$d]["caption"]="state";
	$conf["personalData"][$d]["formElement"]="select"; //2 select and text..
	$conf["personalData"][$d]["maxlength"]=null;
	$c=0;
	$conf["personalData"][$d]["options"][$c]["value"]="Bayern";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Bayern";
	$conf["personalData"][$d]["options"][$c]["value"]="Baden-W&uuml;rttemberg";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Baden-W&uuml;rttemberg";
	$conf["personalData"][$d]["options"][$c]["value"]="Berlin";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Berlin";
	$conf["personalData"][$d]["options"][$c]["value"]="Brandenburg";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Brandenburg";
	$conf["personalData"][$d]["options"][$c]["value"]="Bremen";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Bremen";
	$conf["personalData"][$d]["options"][$c]["value"]="Hamburg";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Hamburg";
	$conf["personalData"][$d]["options"][$c]["value"]="Hessen";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Hessen";
	$conf["personalData"][$d]["options"][$c]["value"]="Meklenburg-Vorpommern";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Meklenburg-Vorpommern";
	$conf["personalData"][$d]["options"][$c]["value"]="Nieder-Sachsen";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Nieder-Sachsen";
	$conf["personalData"][$d]["options"][$c]["value"]="Nordrhein-Westfalen";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Nordrhein-Westfalen";
	$conf["personalData"][$d]["options"][$c]["value"]="Rheinlandpflaz";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Rheinlandpflaz";
	$conf["personalData"][$d]["options"][$c]["value"]="Saarland";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Saarland";
	$conf["personalData"][$d]["options"][$c]["value"]="Sachsen";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Sachsen";
	$conf["personalData"][$d]["options"][$c]["value"]="Sachsen-Anhalt";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Sachsen-Anhalt";
	$conf["personalData"][$d]["options"][$c]["value"]="Schleswig-Holstein";
	$conf["personalData"][$d]["options"][$c++]["caption"]="Schleswig-Holstein";
	
	$conf["personalData"][$d]["binds"]=false;
	$d++;
	$conf["personalData"][$d]["dutyfield"]=false;
	$conf["personalData"][$d]["prompt"]["de"]="Telefon";																																																																																					
	$conf["personalData"][$d]["prompt"]["en"]="phone";
	$conf["personalData"][$d]["caption"]="tele";
	$conf["personalData"][$d]["formElement"]="text";
	$conf["personalData"][$d]["maxlength"]="29";
	$conf["personalData"][$d]["selection"]=null;
	$d++;

	$conf["calendar"]["Hijri"][0]["name"]["de"]="&#77;&#117;&#7717;&#97;&#114;&#114;&#97;&#109;";
	$conf["calendar"]["Greogorian"][0]["name"]["de"]="Januar";
	$conf["calendar"]["Hijri"][0]["days"]=30;
	$conf["calendar"]["Hijri"][0]["sdays"]=30;
	$conf["calendar"]["Greogorian"][0]["days"]=31;
	$conf["calendar"]["Hijri"][1]["name"]["de"]="&#7778;&#97;&#102;&#97;&#114;";
	$conf["calendar"]["Greogorian"][1]["name"]["de"]="Februar";
	$conf["calendar"]["Hijri"][1]["days"]=29;
	$conf["calendar"]["Hijri"][1]["sdays"]=29;
	$conf["calendar"]["Greogorian"][1]["days"]=28;
	$conf["calendar"]["Hijri"][2]["name"]["de"]="&#82;&#97;&#98;&#299;&#703; &#73;";
	$conf["calendar"]["Greogorian"][2]["name"]["de"]="M&auml;rz";
	$conf["calendar"]["Hijri"][2]["days"]=30;
	$conf["calendar"]["Hijri"][2]["sdays"]=30;
	$conf["calendar"]["Greogorian"][2]["days"]=31;
	$conf["calendar"]["Hijri"][3]["name"]["de"]="&#82;&#97;&#98;&#299;&#703; &#73;&#73;";
	$conf["calendar"]["Greogorian"][3]["name"]["de"]="April";
	$conf["calendar"]["Hijri"][3]["days"]=29;
	$conf["calendar"]["Hijri"][3]["sdays"]=29;
	$conf["calendar"]["Greogorian"][3]["days"]=30;
	$conf["calendar"]["Hijri"][4]["name"]["de"]="&#74;&#117;&#109;&#257;&#100;&#257; &#73;";
	$conf["calendar"]["Greogorian"][4]["name"]["de"]="May";
	$conf["calendar"]["Hijri"][4]["days"]=30;
	$conf["calendar"]["Hijri"][4]["sdays"]=30;
	$conf["calendar"]["Greogorian"][4]["days"]=31;
	$conf["calendar"]["Hijri"][5]["name"]["de"]="&#74;&#117;&#109;&#257;&#100;&#257; &#73;&#73;";
	$conf["calendar"]["Greogorian"][5]["name"]["de"]="Juni";
	$conf["calendar"]["Hijri"][5]["days"]=29;
	$conf["calendar"]["Hijri"][5]["sdays"]=29;
	$conf["calendar"]["Greogorian"][5]["days"]=30;
	$conf["calendar"]["Hijri"][6]["name"]["de"]="&#82;&#97;&#106;&#97;&#98;";
	$conf["calendar"]["Greogorian"][6]["name"]["de"]="July";
	$conf["calendar"]["Hijri"][6]["days"]=30;
	$conf["calendar"]["Hijri"][6]["sdays"]=30;
	$conf["calendar"]["Greogorian"][6]["days"]=31;
	$conf["calendar"]["Hijri"][7]["name"]["de"]="&#83;&#104;&#97;&#703;&#98;&#257;&#110;";
	$conf["calendar"]["Greogorian"][7]["name"]["de"]="August";
	$conf["calendar"]["Hijri"][7]["days"]=29;
	$conf["calendar"]["Hijri"][7]["sdays"]=29;
	$conf["calendar"]["Greogorian"][7]["days"]=31;
	$conf["calendar"]["Hijri"][8]["name"]["de"]="&#82;&#97;&#109;&#97;&#7693;&#257;&#110;";
	$conf["calendar"]["Greogorian"][8]["name"]["de"]="September";
	$conf["calendar"]["Hijri"][8]["days"]=30;
	$conf["calendar"]["Hijri"][8]["sdays"]=30;
	$conf["calendar"]["Greogorian"][8]["days"]=30;
	$conf["calendar"]["Hijri"][9]["name"]["de"]="&#83;&#104;&#97;&#119;&#119;&#257;&#108;";
	$conf["calendar"]["Greogorian"][9]["name"]["de"]="Oktober";
	$conf["calendar"]["Hijri"][9]["days"]=29;
	$conf["calendar"]["Hijri"][9]["sdays"]=29;
	$conf["calendar"]["Greogorian"][9]["days"]=31;
	$conf["calendar"]["Hijri"][10]["name"]["de"]="&#68;&#104;&#363; &#97;&#108;&#45;&#81;&#97;&#703;&#100;&#97;";
	$conf["calendar"]["Greogorian"][10]["name"]["de"]="November";
	$conf["calendar"]["Hijri"][10]["days"]=30;
	$conf["calendar"]["Hijri"][10]["sdays"]=30;
	$conf["calendar"]["Greogorian"][10]["days"]=30;
	$conf["calendar"]["Hijri"][11]["name"]["de"]="&#68;&#104;&#363; &#97;&#108;&#45;&#7716;&#105;&#106;&#106;&#97;";
	$conf["calendar"]["Greogorian"][11]["name"]["de"]="Dezember";
	$conf["calendar"]["Hijri"][11]["days"]=29;
	$conf["calendar"]["Hijri"][11]["sdays"]=30;
	$conf["calendar"]["Greogorian"][11]["days"]=31;
	
	$i=0;
	//MOON DATE IS CALCULATED EPACT
		//*** GREETINGS TO EBAY UNIVERSE
	//*** DEDICATED TO LYN NASH
//*** AND HOPEFULLY RESTORED
	$conf["gathering"]["Greogorian"]="1900-1-1";
	$conf["gathering"]["Hijri"]="1317-8-29";
	$conf["sidsCharRange"]="0123456789ABCDEF";
	$conf["sidsLength"]=24;
	$conf["expired_value"]="expired";
	$conf["darkset"]=8000000;
	$conf["since"]["year"]=1962; //THE _=BI^GI=_ 4 EVER
	$conf["since"]["mday"]=30;
	$conf["since"]["month"]=12;
	$conf["counter"]="perlmut_counter";
	$conf["ToHostSidsLength"]="1024";//is maximum recordId length in bytes

	$conf["logs"]="perlmut_logs"; //this is our special songs for our fans on the internet: who need that /-\|/-\|
	$conf["priv"]="perlmut_privileges";

	$conf["hosts"]="perlmut_hosts";
	$conf["sessions"]="perlmut_sessions";
	$conf["sessionCookies"]="perlmut_session_cookies"; //can only be cleared carefully
	$conf["sessionsSecurity"]="perlmut_protect_hack"; //unimplemented at all yet
	$conf["sessionVariables"]="perlmut_session_variables";
	$conf["auth"]="perlmut_auth";
	$conf["authSessions"]="perlmut_authenticated_sessions";
	$conf["users"]="perlmut_users";
	
	//timeouts
	//deactivates session in db
	$conf["session_security_expiration_timeout_in_minutes"]=5;//300Sec
	//but will be restoreable by cookie
	$conf["session_expiration_timeout_in_minutes"]=60;//6000Sec
	//no logout or no activity user will be logged off only if remember login resotores not due maxCookie... vars are exceeded or even if no new request bit inner positive request due to prerelevance reporting will restore
	$conf["autoLogoutTime"]=15; // auto Logout in Minutes
	//new required var	
	$conf["maxCookieLifetimeSeconds"]=356000*60*60*24; //1000 years
	$conf["maxCookieLeaseSeconds"]=356*60*60*24; //1 year
	
	$conf["sessionExitCodeSuccess"]=0;
	$conf["sessionExitCodeFailure"]=1;
	$conf["worlds"]="perlmut_rooms";
	$conf["stack"]="perlmut_chat_stack";
	$conf["objects"]="perlmut_chat_objects";
	$conf["nicks"]="perlmut_chat_nick_names";
	$conf["conx"]="perlmut_chat_conx";
	$conf["chatIgnore"]="perlmut_chat_igno_table";
	$conf["logonRoom"]="perlmut_logon_room";
	$conf["cursorBlinkSpeedMillis"]=600;
	$conf["messageMaxLength"]="132";
?>